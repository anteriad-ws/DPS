<?php

require_once TDB_TEMPLATE_BUILDER_DIR . '/includes/admin/templates/cloud-templates-header.php';

?>
<div class="td-admin-wrap about-wrap">
	<div id="tdb-cloud-templates">
		<router-view></router-view>
	</div>
</div>