<!-- jQuery Modal -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- START Modal: modalPoll -->
<?php
global $current_user;
?>
<!--<div class="modal fade footer-modal" id="exit-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-popup-displayed="<?php echo (isset($_COOKIE['exit_popup_display']) && $_COOKIE['exit_popup_display'] == 'true') ? 'shown' : 'hidden' ?>">
    <div class="modal-dialog modal-dialog-centered modal-notify modal-info" role="document">
        <div class="modal-content">
            <!--Header-->
            <!--            <div class="modal-header" style="">
                            <p class="heading lead" style="text-align: center"></p>
            
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true" class="close-btn">x</span>
                            </button>
                        </div>-->

            <!--Body-->
            <!--<div class="modal-body" style="">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="close-btn">x</span>
                </button>
                <div class="text-center">
                    <?php
                    /*$query = new WP_Query(array('post_type' => 'resources', 'tax_query' => array(
                            array(
                                'taxonomy' => 'post_tag',
                                'field' => 'slug',
                                'terms' => 'most-viewed',
                            ),
                        'posts_per_page' => 1,
                        'order'  => 'DESC'
                    )));
                    $post = $query->posts[0];
                    ?>
                    <!--<i class="far fa-file-alt fa-4x mb-3 animated rotateIn"></i>-->
                    <!--<div style="font-size: 25px;margin-bottom: 30px;font-weight: bold;">Before you leave, check this out! </div>-->
                    <div class='modal-div-head modal-form-head'>Before you leave, check this out! <br/>This might be the thing you are looking for...</div>
                    <div class='modal-div-para'>
                        <div class='div-para-row1'><a href="<?php echo get_the_permalink($post->ID); ?>"><?php echo get_the_post_thumbnail($post->ID, 'medium'); ?></a></div>
                        <div class='div-para-row2'><a href="<?php echo get_the_permalink($post->ID); ?>"><?php echo $post->post_title; ?></a></div>
                    </div>
                </div>
                <?php if(!empty($current_user)) { ?>
                     <a href="<?php echo get_the_permalink($post->ID); ?>" class="btn">Free Download</a>
                <?php } else { ?>
                    <a href="<?php echo site_url('register'); ?>" class="btn">Register Here</a>
                <?php } ?>
            </div>
        </div>
    </div>
</div>-->
<!--<div class="modal fade right footer-modal" id="resource-modal" tabindex="-1" role="dialog" aria-labelledby="resource-modal" aria-hidden="true" data-popup-displayed="<?php echo (isset($_COOKIE['resource_popup_display']) && $_COOKIE['resource_popup_display'] == 'true') ? 'shown' : 'hidden' ?>" data-backdrop="false" style="display: none;">
    <div class="modal-dialog modal-side modal-bottom-right modal-sm" role="document">
        <div class="modal-content">-->
            <!--Body-->
           <!-- <div class="modal-body" style="">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="close-btn">x</span>
                </button>
                <div class="text-center">
                <?php
                 /* $query = new WP_Query(array('post_type' => 'resources', 'tax_query' => array(
                            array(
                                'taxonomy' => 'post_tag',
                                'field' => 'slug',
                                'terms' => 'most-downloaded',
                            ),
                            'offset'    => 5,
                            'posts_per_page' => 1,
                            'order'  => 'DESC'
                    )));
                    $post = $query->posts[0];*/
                    ?>
                    <i class="far fa-file-alt fa-4x mb-3 animated rotateIn"></i>-->
                    <!--<div class='modal-div-head'>Haven't you checked this yet? Here's something that might interest you.</div>-->
                   <!-- <div class='modal-div-head'>Here's something that might interest you.</div>
                    <div class='modal-div-para'>-->
                        <!--<div><a href="<?php //echo get_the_permalink($post->ID); ?>"><?php //echo get_the_post_thumbnail($post->ID, 'medium'); ?></a></div>
                        <div><a class="modal-post-title" href="<?php //echo get_the_permalink($post->ID); ?>"><?php //echo $post->post_title; ?></a></div>
                    </div>
                </div>
                <a href="<?php //echo get_the_permalink($post->ID); ?>" class="btn">Download it for free</a>
            </div>
        </div>
    </div>
</div>-->

<?php
do_action('tdc_footer');
if (has_action('tdc_footer')) {
    return;
}
?>
<div class="td-footer-page td-footer-container td-container-wrap">
    <div class="td-sub-footer-container td-container-wrap">
        <div class="td-container">
            <div class="td-pb-row">
                <div class="td-pb-span td-sub-footer-menu">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer-menu',
                        'menu_class' => 'td-subfooter-menu',
                        'fallback_cb' => 'tagdiv_wp_no_footer_menu',
                    ));

// if no menu
                    function tagdiv_wp_no_footer_menu() {
                        if (current_user_can('switch_themes')) {
                            echo '<ul class="td-subfooter-menu">';
                            echo '<li class="menu-item-first"><a href="' . esc_url(home_url('/')) . 'wp-admin/nav-menus.php?action=locations">Add menu</a></li>';
                            echo '</ul>';
                        }
                    }
                    ?>
                </div>

                <div class="td-pb-span td-sub-footer-copy">
                    &copy; Newspaper WordPress Theme by TagDiv
                </div>
            </div>
        </div>
    </div>
</div>

</div><!--close td-outer-wrap-->

<?php wp_footer(); ?>

</body>
</html>