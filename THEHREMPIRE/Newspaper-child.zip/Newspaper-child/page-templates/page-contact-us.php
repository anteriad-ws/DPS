<?php
/* Template Name: Contact Us   */
get_header();
global $content_width;
$content_width = 1068;
$current_user = wp_get_current_user();
?> 

<style>
    .fm-form-container.fm-theme1{
        width:100% !important;
    }
	
	.page-template-page-templates .tdi_71_a3e {
    padding-top: 245px !important;
    padding-right: 20px !important;
    padding-bottom: 200px !important;
    padding-left: 50px !important;
}

    input#wdform_2_element13 {
        border-right: 0px solid grey !important;
        border-left: 0px solid grey !important;
        border-top: 0px solid grey !important;
    }


    input#wdform_3_element13 {
        border-right: 0px solid grey !important;
        border-left: 0px solid grey !important;
        border-top: 0px solid grey !important;
    }

    textarea#wdform_4_element13 {
        border-right: 0px solid grey !important;
        border-left: 0px solid grey !important;
        border-top: 0px solid grey !important;
    }
    .contactus{padding-left: 10% !important;}

</style>


<div class="td-main-content-wrap td-container-wrap contact-us">
    <!--<div class="td-container">-->
    <!--<div class="td-crumb-container">-->
    <?php
//            echo tagdiv_page_generator::get_breadcrumbs(array(
//                'template' => 'single',
//                'title' => get_the_title(),
//            ));
    ?>
    <!--</div>-->

    <div class="td-pb-row">
        <!--<div class="tdc-row stretch_row_1200 td-stretch-content">-->
            <!--<div class="td-ss-main-content">-->
                <!-- START -  Row 2-->
                <!-- <h1 class="page-h1-head row2-head"><?php //echo get_the_title();   ?></h1> -->

                <div class="vc_column_inner tdi_66_7c2  wpb_column vc_column_container tdc-inner-column td-pb-span7 contactus" >
                    <div class="wpb_wrapper" style="margin-left: 10px;margin-top: 60px;">

                        <h3 class="tdm-title tdm-title-md" style="font-weight:700">Contact Us</h3>


                        <p style="margin-bottom: 25px;"><span style="font-weight: 400; font-size: 17px;">How can we help you?</span></p>
                        <p style="margin-bottom: 25px;"><span style="font-weight: 400; font-size: 17px;">Please fill out the form below to get in touch with our team. </span></p>
<!--                        <p style="margin-bottom: 25px;"><span style="font-weight: 400;font-size: 17px;">Drop us a line by filling out this form:</span></p>-->
                    </div>
                    <span style="display: none;" id="get_user_email"><?php echo $current_user->user_email; ?></span>
                    <span style="display: none;" id="get_user_name"><?php echo $current_user->user_login; ?></span>
                    <?php echo do_shortcode('[Form id="1"]'); ?>
                </div>

                <div class="vc_column_inner tdi_71_a3e  wpb_column vc_column_container tdc-inner-column td-pb-span5" >
                    <style scoped="">

                        /* custom css */
                        .tdi_71_a3e{
                            vertical-align: baseline;
                        }.tdi_71_a3e .wpb_wrapper,
                        .tdi_71_a3e .wpb_wrapper .tdc-elements{
                            display: block;
                        }.tdi_71_a3e .wpb_wrapper .tdc-elements{
                            width: 100%;
                        }
                        /* inline tdc_css att */

                        .tdi_71_a3e{
                            padding-top:60px !important;
                            padding-right:20px !important;
                            padding-bottom:200px !important;
                            padding-left:50px !important;
                            position:relative;
                        }

                        /* landscape */
                        @media (min-width: 1019px) and (max-width: 1140px)
                        {
                            .tdi_71_a3e{
                                padding-bottom:160px !important;
                            }
                        }

                        /* portrait */
                        @media (min-width: 768px) and (max-width: 1018px)
                        {
                            .tdi_71_a3e{
                                padding-top:30px !important;
                                padding-bottom:80px !important;
                                padding-left:20px !important;
                                width:38% !important;
                            }
                        }

                        /* phone */
                        @media (max-width: 767px)
                        {
                            .tdi_71_a3e{
                                padding-top:20px !important;
                                padding-right:20px !important;
                                padding-bottom:20px !important;
                                padding-left:20px !important;
                            }
                        }

                    </style>
                    <div class="tdi_70_7a0_rand_style td-element-style"><style>
                            .tdi_70_7a0_rand_style{
                                background-color:#4c4084 !important;
                            }
                        </style></div><div class="vc_column-inner"><div class="wpb_wrapper"><div class="tdm_block td_block_wrap tdm_block_column_title tdi_72_ce0 tdm-content-horiz-left td-pb-border-top td_block_template_1" data-td-block-uid="tdi_72_ce0">
                                <style>

                                    /* inline tdc_css att */

                                    .tdi_72_ce0{
                                        margin-bottom:-30px !important;
                                    }

                                    /* phone */
                                    @media (max-width: 767px)
                                    {
                                        .tdi_72_ce0{
                                            justify-content:center !important;
                                            text-align:center !important;
                                        }
                                    }

                                </style><div class="td-block-row"><div class="td-block-span12 tdm-col">
                                        <style>
                                            .tdi_73_03d .tdm-title{
                                                color: #ffffff;
                                            }
                                            .tdm-title-xsm{font-size:20px}
                                            .tdi_73_03d .tdm-title-line{
                                                width: 120px;

                                                height: 0px;
                                            }.tdi_73_03d .tdm-title-line:after{
                                                height: 0px;

                                                bottom: 0%;
                                            }.tdi_73_03d .tdm-title-sub{
                                                margin-bottom: 0px;
                                            }
                                        </style><div class="tds-title tds-title3 tdm-subtitle-above td-fix-index tdi_73_03d"><div class="tdm-title-sub"></div><div class="tdm-title-line"></div><h3 class="tdm-title tdm-title-xsm">Working hours:
                                            </h3></div></div></div></div><div class="tdm_block td_block_wrap tdm_block_column_title tdi_74_e8d tdm-content-horiz-left td-pb-border-top td_block_template_1" data-td-block-uid="tdi_74_e8d">
                                <style>

                                    /* inline tdc_css att */
                                    .tds-title3.tdm-subtitle-above .tdm-title{margin-bottom:0px !important}
                                    .tdi_74_e8d{
                                        margin-bottom:-20px !important;
                                    }

                                    /* portrait */
                                    @media (min-width: 768px) and (max-width: 1018px)
                                    {
                                        .tdi_74_e8d{
                                            width:auto !important;
                                        }
                                    }

                                    /* phone */
                                    @media (max-width: 767px)
                                    {
                                        .tds-title3.tdm-subtitle-above .tdm-title{margin-bottom:38px !important}
                                        .tdi_74_e8d{
                                            justify-content:center !important;
                                            text-align:center !important;
                                        }
                                    }

                                </style><div class="td-block-row"><div class="td-block-span12 tdm-col">
                                        <style>
                                            .tdi_75_636 .tdm-title{
                                                color: #ffffff;

                                                font-size:20px !important;line-height:30px !important;font-weight:400 !important;
                                            }.tdi_75_636 .tdm-title-line{
                                                width: 120px;

                                                height: 0px;
                                            }.tdi_75_636 .tdm-title-line:after{
                                                height: 0px;

                                                bottom: 0%;
                                            }.tdi_75_636 .tdm-title-sub{
                                                margin-bottom: 0px;
                                            }

                                            /* portrait */
                                            @media (min-width: 768px) and (max-width: 1018px){
                                                .tdi_75_636 .tdm-title{
                                                    font-size:16px !important;line-height:24px !important;font-weight:400 !important;
                                                }
                                            }

                                            /* phone */
                                            @media (max-width: 767px){
                                                .tdi_75_636 .tdm-title{
                                                    font-size:18px !important;line-height:26px !important;font-weight:400 !important;
                                                }
                                            }
                                        </style><div class="tds-title tds-title3 tdm-subtitle-above td-fix-index tdi_75_636"><div class="tdm-title-sub"></div><div class="tdm-title-line"></div><h3 class="tdm-title tdm-title-sm" style="font-size:16px !important">Monday - Friday: 09:00 - 17:00</h3></div></div></div></div><div class="tdm_block td_block_wrap tdm_block_column_title tdi_76_33e tdm-content-horiz-left td-pb-border-top td_block_template_1" data-td-block-uid="tdi_76_33e">
                                <style>

                                    /* inline tdc_css att */

                                    .tdi_76_33e{
                                        margin-top:40px !important;
                                        margin-bottom:-30px !important;
                                    }

                                    /* phone */
                                    @media (max-width: 767px)
                                    {
                                        .tdi_76_33e{
                                            margin-top:20px !important;
                                            justify-content:center !important;
                                            text-align:center !important;
                                        }
                                    }

                                </style><div class="td-block-row"><div class="td-block-span12 tdm-col">
                                        <style>
                                            .tdi_77_06d .tdm-title{
                                                color: #ffffff;
                                            }.tdi_77_06d .tdm-title-line{
                                                width: 120px;

                                                height: 0px;
                                            }.tdi_77_06d .tdm-title-line:after{
                                                height: 0px;

                                                bottom: 0%;
                                            }.tdi_77_06d .tdm-title-sub{
                                                margin-bottom: 0px;
                                            }
                                        </style>
                                        <div class="tds-title tds-title3 tdm-subtitle-above td-fix-index tdi_77_06d" >
                                            <div class="tdm-title-sub"></div><div class="tdm-title-line"></div>
                                        <h3 class="tdm-title tdm-title-xsm" >Social Media:</h3></div></div></div></div>
                                        <div class="tdm-social-wrapper tds-social1 tdi_68 contact_social"><div class="tdm-social-item-wrap"><a href="https://www.facebook.com/thehrempire" target="_blank" title="Facebook" class="tdm-social-item"><i class="td-icon-font td-icon-facebook"></i></a></div>
                                        <!-- <div class="tdm-social-item-wrap"><a href="https://www.instagram.com/thehr.empire/" target="_blank" title="Instagram" class="tdm-social-item"><i class="td-icon-font td-icon-instagram"></i></a></div> -->
                                        <div class="tdm-social-item-wrap"><a href="https://www.linkedin.com/company/thehrempire" target="_blank" title="Linkedin" class="tdm-social-item"><i class="td-icon-font td-icon-linkedin"></i></a></div><div class="tdm-social-item-wrap"><a href="https://twitter.com/thehrempire" target="_blank" title="Twitter" class="tdm-social-item"><i class="td-icon-font td-icon-twitter"></i></a></div></div>
                                        <div class="tdm_block td_block_wrap tdm_block_column_title tdi_78_c03 tdm-content-horiz-left td-pb-border-top td_block_template_1" data-td-block-uid="tdi_78_c03" style="display:none">
                                <style>

                                    /* inline tdc_css att */

                                    .tdi_78_c03{
                                        margin-bottom:-20px !important;
                                        padding-right:6% !important;
                                    }
                                    .tdi_68 .tdm-social-item i{font-size: 26px !important;}
                                    .tdi_68 .tdm-social-item-wrap:hover i{color:#fff !important}
                                    .tdi_68 .tdm-social-item{margin: 15px 25px 15px 0 !important;     width: auto !important;}
                                    /* phone */
                                    @media (max-width: 767px)
                                    {
                                        .tdi_78_c03{
                                            justify-content:center !important;
                                            text-align:center !important;
                                        }
                                        .contact_social{text-align:center;padding-bottom: 20px;}
                                    }

                                </style><div class="td-block-row"><div class="td-block-span12 tdm-col">
                                        <style>
                                            .tdi_79_407 .tdm-title{
                                                color: #ffffff;

                                                font-size:20px !important;line-height:30px !important;font-weight:400 !important;
                                            }.tdi_79_407 .tdm-title-line{
                                                width: 120px;

                                                height: 0px;
                                            }.tdi_79_407 .tdm-title-line:after{
                                                height: 0px;

                                                bottom: 0%;
                                            }.tdi_79_407 .tdm-title-sub{
                                                margin-bottom: 0px;
                                            }

                                            /* portrait */
                                            @media (min-width: 768px) and (max-width: 1018px){
                                                .tdi_79_407 .tdm-title{
                                                    font-size:16px !important;line-height:24px !important;font-weight:400 !important;
                                                }
                                            }

                                            /* phone */
                                            @media (max-width: 767px){
                                                .tdi_79_407 .tdm-title{
                                                    font-size:18px !important;line-height:26px !important;font-weight:400 !important;
                                                }
                                            }
                                        </style><div class="tds-title tds-title3 tdm-subtitle-above td-fix-index tdi_79_407"><div class="tdm-title-sub"></div><div class="tdm-title-line"></div><h3 class="tdm-title tdm-title-sm" style="font-size:18px !important">2 International Drive, Rye Brook, New York 10573, USA</h3></div></div></div></div></div></div></div>
                <!-- END -  Row 2-->
            <!--</div>-->

        <!--</div>-->

        <!--<div class="vc_column_inner tdi_66_7c2  wpb_column vc_column_container tdc-inner-column td-pb-span12">


            <div class="wpb_wrapper">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.892310466369!2d-73.69030728511565!3d41.049484024838016!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c297c7c4df953f%3A0xe9d1fbb99ac157ac!2s2%20International%20Dr%2C%20Port%20Chester%2C%20NY%2010573%2C%20USA!5e0!3m2!1sen!2sin!4v1663304466752!5m2!1sen!2sin" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

        </div>-->
    </div>
    <!--</div>-->
</div>

<?php
get_footer();
