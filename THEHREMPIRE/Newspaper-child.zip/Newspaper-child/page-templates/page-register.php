<?php
/*
 * Template Name: Register Page Template
 */

if (is_user_logged_in()){
    wp_redirect( home_url() );
    exit;
}
get_header('nomenu');
global $wp;
$current_url = home_url(add_query_arg(array(), $wp->request));
$link_array = explode('/', $current_url);
$currpage = end($link_array);
?>
<div class="td-main-content-wrap td-container-wrap">
    <div class=""><!--td-container-->
        <div class="td-pb-row">
            <div class="td-pb-span12 td-main-content">
                <div class="td-ss-main-content">
                    <?php
                    if (have_posts()) {
                        while (have_posts()) : the_post();
                            ?>
                            <div class=""><!--td-page-content tagdiv-type preference-block-->

                                <div class="login-form-row">
                                    <div class="login-form-col-1">
                                        <a href="<?php echo home_url(); ?>"><img src="https://thehrempire.com/wp-content/uploads/2020/08/Signin-logo.png" /></a>
                                        <h1>Welcome to The HR Empire</h1>
                                        <?php $value = get_option( 'total_followers', '' ); ?>
                                        
                                        <!--<h2>READ WHAT <?php echo number_format($value); ?> + Organizational Behavior Experts and HR Leaders READ EVERY DAY.</h2>-->
                                        <h2>SEE WHAT <?php echo number_format($value); ?> + ORGANIZATIONAL BEHAVIOR EXPERTS and HR LEADERS ARE INTERESTED IN EVERY DAY</h2>
                                    </div>
                                    <div class="login-form-col-2">
                                        <!--<div id="login-block" style="<?php echo ((isset($_GET['page']) && $_GET['page'] !== 'register') || !isset($_GET['page']) || $currpage != 'register') ? 'display:block;' : 'display:none;'; ?>">-->
                                        <div id="login-block" style="<?php echo ($currpage != 'register') ? 'display:block;' : 'display:none;'; ?>">
                                            <h1 class="text-center">SIGN IN</h1>
                                            <h4 class="text-center">Sign in to get full access to The HR Empire now!</h4>
                                            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'registered') { ?>
                                            <div class="alert alert-success">Please check your email for verification</div>
                                            <?php } 
                                            if((isset($_SESSION['registered']) && $_SESSION['registered'] == 'true')|| (isset($_GET['msg']) && $_GET['msg'] == 'verified')) { ?>
                                            <div class="alert alert-success">Your email is successfully verified. Continue to login with your chosen password to explore The HR Empire</div>
                                            <?php 
                                                unset($_SESSION['registered']);
                                            } ?>
                                            <?php echo do_shortcode('[user_registration_my_account]'); ?>
                                            
                                            <!--</div>-->

                                            <!--<p>Don't have an account? Join the hub of leading HR and Organizational Behavior Experts for free!</p>-->
                                            <p>Don't have an account? Join leading HR and Organizational Behavior Experts!</p>
                                            <?php if ($currpage != 'lost-password') { ?>
                                                <input type="button" value="Create an Account" id="create-acc" class="create-account-btn" />
                                            <?php } ?>
                                        </div>
                                        <div id="register-block" style="<?php echo ((isset($_GET['page']) && $_GET['page'] == 'register') || $currpage == 'register') ? 'display:show;' : 'display:none;'; ?>">
                                            <h1 class="text-center"><span id="go-login" title="Back to Login Screen"></span>Register</h1>
                                            <h4 class="text-center">Join <?php echo number_format($value); ?> + HR Leaders and Organizational Experts! </h4>
                                            <?php echo do_shortcode('[user_registration_form id="610"]'); ?>
                                            <!--<p>Don't have an account? Join the hub of leading HR and Organizational Behavior Experts for free!</p>-->
                                            <!--<input type="button" value="Create an Account" class="create-account-btn" />-->
                                        </div>
                                        <div style="display: flex;margin-bottom: 40px;">
                                            <?php if ($currpage === 'lost-password') { ?>
                                                <div class="back-to-home">
                                                    <a href="<?php echo home_url('sign-in'); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Login</a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="back-to-home">
                                                    <a href="<?php echo home_url(); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Home</a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
//                                the_content();
                                ?>
                                <div class="clearfix"></div>
                            </div>
                            <?php
                        endwhile; //end loop
                        comments_template('', true);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer('nomenu');
