<?php 
/*
 * Template Name: Do Not Sell My Information Template
 */
get_header(); ?>
<!-- jQuery Modal -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- START Modal: modalPoll -->
<div class="modal fade" id="consumer-request-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-notify modal-info" role="document">
        <div class="modal-content">
            <!--Header-->
            <div class="modal-header" style="background-color: #0353A3">
                <p class="heading lead"><?php echo get_the_title(); ?></p>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="white-text">x</span>
                </button>
            </div>

            <!--Body-->
            <div class="modal-body">
                <div class="text-center">
                    <!--<i class="far fa-file-alt fa-4x mb-3 animated rotateIn"></i>-->
                    <p style="font-weight: bold;" class="modal-form-head"><?php echo 'Request for access to collected data'; ?></p>

                </div>

                <hr>
                <!-- OneTrust Web Form start -->
<!--<style>
    .ot-form-wrapper {
        max-width: 750px;
        height: 800px;
        border: 1px solid #c0c2c7;
        margin: auto;
    }
    .ot-form-wrapper iframe {
        width: 100%;
        height: 100%;
        border: none;
    }
</style>-->
<!--<div class="ot-form-wrapper">
    <iframe src="https://privacyportal-eu.onetrust.com/webform/5b67668c-ad63-4a18-b1ea-a937e37dbf07/0a97fdff-cbe5-45f7-a1b5-336c98dd4916">
    </iframe>
</div>-->
<!-- OneTrust Web Form end -->
                <?php echo do_shortcode('[Form id="17"]'); ?>
            </div>

            <!--Footer-->
            <!--      <div class="modal-footer justify-content-center">
                    <a type="button" class="btn btn-primary waves-effect waves-light">Send
                      <i class="fa fa-paper-plane ml-1"></i>
                    </a>
                    <a type="button" class="btn btn-outline-primary waves-effect" data-dismiss="modal">Cancel</a>
                  </div>-->
        </div>
    </div>
</div>
    <div class="td-main-content-wrap td-container-wrap">
        <div class="td-container">
            <div class="td-crumb-container">
                <?php echo tagdiv_page_generator::get_breadcrumbs(array(
                    'template' => 'page',
                    'page_title' => get_the_title(),
                )); ?>
            </div>

            <div class="td-pb-row">
                <div class="td-pb-span12 td-main-content">
                    <div class="td-ss-main-content">
                        <?php
                            if (have_posts()) {
                                while ( have_posts() ) : the_post();
                                    ?>
                                    <div class="td-page-header">
                                        <h1 class="entry-title td-page-title">
                                            <span><?php the_title() ?></span>
                                        </h1>
                                    </div>
                                    <div class="td-page-content tagdiv-type">
                                        <?php the_content(); ?>
                                        
                                        
                                        <div class="consumer-requests" id="consumer-requests-2">
                                            <h2>Request Removal/Deletion</h2>
                                            <p>Want to remove your existing information from our database? Click the button below. Once you click this button, all the information pertaining to you will be removed from our database on immediate notice.</p>
                                            <!--<button class="btn btn-primary data-request-btn" data-title="Request Removal/Deletion from <?php echo get_bloginfo( 'name' ); ?>" data-type-value="Request Deletion">Request Deletion</button>-->
                                            <a class="btn btn-primary" href="<?php echo site_url('do-not-sell-my-information-request-removal') ?>">Request Deletion</a>
                                        </div>
                                        <div class="consumer-requests" id="consumer-requests-1">
                                            <h2>Request Access to Collected Data</h2>
                                            <p>We respect your privacy. Please be informed that the collected data is absolutely safe with us. To learn more about the collected data, please click the link below.  </p>
                                            <a class="btn btn-primary" data-title="Request Access to Collected Data" href="<?php echo site_url('do-not-sell-my-information-request-access') ?>">Request Access</a>
                                            
                                        </div>
                                        
                                        <div class="consumer-requests" id="consumer-requests-3">
                                            <h2>Privacy at <?php echo get_bloginfo( 'name' ); ?></h2>
                                            <p>We respect your data. For further details on our privacy policy and terms of service, please click the below links:
</p>
                                            <a style="font-weight: bold" target="_blank" href="<?php echo site_url('privacy-policy') ?>"><?php echo get_bloginfo( 'name' ); ?>'s Privacy Policy</a><br/>
                                            <a style="font-weight: bold" target="_blank" href="<?php echo site_url('terms-of-service') ?>"><?php echo get_bloginfo( 'name' ); ?>'s Terms of Service</a>
                                        </div>
                                    </div>
                            <?php endwhile;//end loop
                                comments_template('', true);
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--<script type="text/javascript">
    jQuery('.data-request-btn').click(function() {
        jQuery('.modal-form-head').html(jQuery(this).data('title'));
        jQuery('.consumer_request_type').val(jQuery(this).data('type-value'))
        jQuery('#consumer-request-modal').modal({
            backdrop: 'static',
            keyboard: false
        });
    });
    </script>-->
<?php get_footer();