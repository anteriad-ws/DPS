<?php
/*
 * Template Name: Signin Page Template
 */

if (is_user_logged_in()){
    wp_redirect( home_url() );
    exit;
}
get_header('nomenu');
global $wp;
$current_url = home_url(add_query_arg(array(), $wp->request));
$link_array = explode('/', $current_url);
$currpage = end($link_array);
?>
<div class="td-main-content-wrap td-container-wrap">
    <div class=""><!--td-container-->
        <div class="td-pb-row">
            <div class="td-pb-span12 td-main-content">
                <div class="td-ss-main-content">
                    <?php
                    if (have_posts()) {
                        while (have_posts()) : the_post();
                            ?>
                            <div class=""><!--td-page-content tagdiv-type preference-block-->

                                <div class="login-form-row">
                                    <div class="login-form-col-1">
                                        <a href="<?php echo home_url(); ?>"><img src="https://thehrempire.com/wp-content/uploads/2020/08/Signin-logo.png" /></a>
                                        <h1>Welcome to The HR Empire</h1>
                                        <?php $value = get_option( 'total_followers', '' ); ?>
                                        
                                        <!--<h2>READ WHAT <?php echo number_format($value); ?> + Organizational Behavior Experts and HR Leaders READ EVERY DAY.</h2>-->
                                        <h2>SEE WHAT <?php echo number_format($value); ?> + ORGANIZATIONAL BEHAVIOR EXPERTS and HR LEADERS ARE INTERESTED IN EVERY DAY</h2>
                                    </div>
                                    <div class="login-form-col-2">
                                        <!--<div id="login-block" style="<?php echo ((isset($_GET['page']) && $_GET['page'] !== 'register') || !isset($_GET['page']) || $currpage != 'register') ? 'display:block;' : 'display:none;'; ?>">-->
                                        <div id="login-block" style="<?php echo ($currpage != 'register') ? 'display:block;' : 'display:none;'; ?>">
                                            
                                            <h4 class="text-center lost">Sign in to get full access to The HR Empire now!</h4>
                                            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'registered') { ?>
                                            <div class="alert alert-success">Please check your email for verification</div>
                                            <?php } 
                                            if((isset($_SESSION['registered']) && $_SESSION['registered'] == 'true')|| (isset($_GET['msg']) && $_GET['msg'] == 'verified')) { ?>
                                            <div class="alert alert-success">Your email is successfully verified. Continue to login with your chosen password to explore The HR Empire</div>
                                            <?php 
                                                unset($_SESSION['registered']);
                                            } ?>
                                            <?php echo do_shortcode('[user_registration_my_account]'); ?>
                                            <p id="hideid">Don't have an account? Join leading HR and Organizational Behavior Experts!</p>
                                            <?php if ($currpage != 'lost-password') { ?>
                                               <a href="https://thehrempire.com/register/"> <input type="button" value="Create an Account"  class="create-account-btn" /></a>
                                            <?php } ?>
                                        
                                            <div class="or">OR</div>
                                            <div id="magic-link-div">
                                            <!--<button id="passwordless-login-btn" class="magic-link-btn"><i class="fa fa-magic"></i> Login with Magic Link</button>-->
                                                <!--<div id="passwordless-login-div" style="display: none;">-->
                                                <p>
                                                    
                                                    <!--<span style="font-size: 12px">Worry not! Save time with our magic link and sign in instantly.</span>-->
                                                    <!--<span style="font-size: 12px">Get a link to Sign in instantly</span>-->

                                                </p>

                                                <?php echo do_shortcode('[magiclink-login]'); ?></div>
                                            <!--</div>-->

                                            <!--<p>Don't have an account? Join the hub of leading HR and Organizational Behavior Experts for free!</p>-->
                                            
                                        </div>
                                      
                                        <div style="display: flex;margin-bottom: 40px;">
                                            <?php if ($currpage === 'lost-password') { ?>
                                                <div class="back-to-home">
                                                    <a href="<?php echo home_url('sign-in'); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Login</a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="back-to-home">
                                                    <a href="<?php echo home_url(); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Home</a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
//                                the_content();
                                ?>
                                <div class="clearfix"></div>
                            </div>
                            <?php
                        endwhile; //end loop
                        comments_template('', true);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer('nomenu');
