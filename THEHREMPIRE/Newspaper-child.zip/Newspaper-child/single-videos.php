<?php
/**
 * The single post loop Default template
 * */
get_header();
?>

<style>
    .td-editor-date {
        display:none !important;
    }
    .td_block_wrap .td-load-more-wrap{margin-top:10px !important}
</style>

<?php
if (have_posts()) {
    the_post();
    ?>
    <div class="td-container">
        <div class="td-pb-row">
            <div class="td-pb-span12 td-main-content">
                <div class="td-ss-main-content">
                    <article class="<?php echo join(' ', get_post_class()); ?>" data-post-url="<?php echo get_the_permalink(); ?>" data-post-edit-url="<?php echo home_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&amp;action=edit" data-post-title="<?php the_title() ?>">
                        <div class="td-post-header">


                            <header class="td-post-title">
                                <!-- title -->
                                <h3 class="entry-title td-module-title" title="<?php the_title_attribute() ?>" style="margin-top: 30px;">
                                    <!--<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute() ?>">-->
                                    <?php the_title() ?>
                                    <!--</a>-->
                                </h3>

                                <div class="td-module-meta-info">
                                    <!-- author -->
                                    <!--                    <div class="td-post-author-name">
                                                            <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))) ?>"><?php the_author() ?></a>
                                                            <div class="td-author-line"> - </div>
                                                        </div>-->

                                    <!-- date -->
                                    <span class="td-post-date">
                                        <time class="entry-date updated td-module-date" datetime="<?php echo esc_html(date(DATE_W3C, get_the_time('U'))) ?>" ><?php the_time(get_option('date_format')) ?></time>
                                    </span>

                                    <!-- comments -->
                                    <!--                    <div class="td-post-comments">
                                                            <a href="<?php comments_link() ?>">
                                                                <i class="td-icon-comments"></i>
                                    <?php comments_number('0', '1', '%') ?>
                                                            </a>
                                                        </div>-->
                                </div>
                            </header>

                            <div class="td-post-content tagdiv-type">
                                <!-- image -->

                                <div class="news-content">
                                    <?php the_content() ?>
                                </div>

                            </div>


                        </div>

                    </article>
                </div>
            </div>
        </div>
    </div>
    <hr>

        <!--	<style>
        .tdc-row{
                width: 1200px !important;
        } 
        </style> -->
    <div class="td-container">
        <div class="td-pb-row video-page">
            <?php
            //echo do_shortcode('[tdc_zone type="tdc_content"][vc_row full_width="stretch_row_1400 td-stretch-content"][vc_column][td_flex_block_1 modules_on_row="" limit="5" hide_audio="yes" image_size="td_485x360" image_height="100" image_floated="float_left" image_width="20" meta_margin="10px" meta_padding="10px" installed_post_types="videos" sort="oldest_posts" ajax_pagination="load_more" custom_title="Related Videos" block_template_id="td_block_template_5" show_author="none" show_date="none" td-editor-date="none" show_excerpt="none" show_review="none" show_com="none"][/vc_column][/vc_row][/tdc_zone]');
echo do_shortcode('[tdc_zone type="tdc_content"][vc_row full_width="stretch_row_1400 td-stretch-content"][vc_column][td_flex_block_1 modules_on_row="eyJhbGwiOiIyNSUiLCJwb3J0cmFpdCI6IjUwJSIsInBob25lIjoiMTAwJSJ9" limit="4" hide_audio="yes" image_size="" image_floated="" meta_margin="eyJhbGwiOiIxMHB4IiwibGFuZHNjYXBlIjoiMHB4IiwicGhvbmUiOiIwcHgifQ==" meta_padding="10px" installed_post_types="videos" sort="" ajax_pagination="load_more" custom_title="Related Videos" block_template_id="td_block_template_1" show_author="none" show_date="" td-editor-date="none" show_excerpt="none" show_review="none" show_com="none" image_height="60" image_alignment="0" show_cat="none" show_btn="none" f_title_font_size="eyJsYW5kc2NhcGUiOiIxOCJ9"][/vc_column][/vc_row][/tdc_zone]');
            
            ?>
            <?php
        }
        ?>
    </div>
</div>
<style type="text/css">
    @media (max-width: 767px) {
        .video-page .td_module_flex_1 .td-module-container, 
        .video-page .td_module_flex_3 .td-module-container,
        .video-page .td_module_flex_4 .td-module-container,
        .video-page .td_module_flex_5 .td-module-container {
            display: block;
        }
        .video-page .td-image-container {
            width: 100%;
            flex: none;
        }
        .video-page .td-module-meta-info {
            margin: auto 0 auto 0;
            padding-left: 0;
            padding-right: 0;
        }
    }
</style>
<?php
get_footer();
?>