<?php
/**
 * The single post loop Default template
 **/


if (have_posts()) {
    the_post(); ?>
    <article class="<?php echo join(' ', get_post_class());?>">
        <div class="td-post-header">
            <ul class="td-category">
                <?php
                $categories = get_the_category();
                if( !empty( $categories ) ) {
                    foreach($categories as $category) {
                        $cat_link = get_category_link($category->cat_ID);
                        $cat_name = $category->name; ?>
                        <li class="entry-category"><a href="<?php echo esc_url($cat_link) ?>"><?php echo esc_html($cat_name) ?></a></li>
                    <?php }
                } ?>
            </ul>

            <header class="td-post-title">
                <!-- title -->
                <h3 class="entry-title td-module-title" title="<?php the_title_attribute() ?>">
                    <!--<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute() ?>">-->
                        <?php the_title() ?>
                    <!--</a>-->
                </h3>

                <div class="td-module-meta-info">
                    <!-- author -->
<!--                    <div class="td-post-author-name">
                        <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta( 'ID' ))) ?>"><?php the_author() ?></a>
                        <div class="td-author-line"> - </div>
                    </div>-->

                    <!-- date -->
                    <span class="td-post-date">
                        <time class="entry-date updated td-module-date" datetime="<?php echo esc_html(date(DATE_W3C, get_the_time('U'))) ?>" ><?php the_time(get_option('date_format')) ?></time>
                    </span>

                    <!-- comments -->
<!--                    <div class="td-post-comments">
                        <a href="<?php comments_link() ?>">
                            <i class="td-icon-comments"></i>
                            <?php comments_number('0','1','%') ?>
                        </a>
                    </div>-->
                </div>
            </header>

              <div class="td-post-content tagdiv-type">
                <!-- image -->
                <?php
                    if( get_the_post_thumbnail_url(null, 'full') != false ) { ?>
                        <div class="td-post-featured-image">
                            <?php if(get_the_post_thumbnail_caption() != '' ) { ?>
                                <figure>
                                    <img class="entry-thumb" src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'full')) ?>" alt="<?php the_title() ?>" title="<?php echo esc_attr(strip_tags(the_title())) ?>" />
                                    <figcaption class="wp-caption-text"><?php echo esc_html(get_the_post_thumbnail_caption()) ?></figcaption>
                                </figure>
                            <?php } else { ?>
                                <img class="entry-thumb" src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'full')) ?>" alt="<?php the_title() ?>" title="<?php echo esc_attr(strip_tags(the_title())) ?>" />
                            <?php } ?>

                            <div style="margin-bottom: 15px;
    font-style: italic;
    color: #aaa;float:right;margin-top:-20px;font-size:12px;color:#0000ff85"><?php 
echo do_shortcode('[image_courtesy_shortcode]') ?></div>


                        </div>

                        


                      


                <?php } ?>
                <div class="news-content">
                <?php the_content() ?>
                </div>
                <?php
        if(get_post_type( get_the_ID()) == 'news') {
            ?>
        <span class="td-post-date td-post-source" style="margin-top: 5px;">
            News Source: <a href="<?php echo (get_post_meta($post->ID, '_source_url', true) != '') ? get_post_meta($post->ID, '_source_url', true) : home_url(); ?>" target="_blank"><?php echo (get_post_meta($post->ID, '_source_name', true) != '') ? get_post_meta($post->ID, '_source_name', true) : 'source'; ?></a></span>
        <?php } 
        ?>
            </div>

            <footer>
                <?php
                    // post pagination
                    wp_link_pages(array(
                        'before' => '<div class="page-nav page-nav-post td-pb-padding-side">',
                        'after' => '</div>',
                        'link_before' => '<div>',
                        'link_after' => '</div>',
                        'nextpagelink'     => '<i class="td-icon-menu-right"></i>',
                        'previouspagelink' => '<i class="td-icon-menu-left"></i>',
                    ));

                    // tags
                    $td_post_tags = get_the_tags();
                    if( !empty($td_post_tags) ) { ?>
                        <div class="td-post-source-tags">
                            <ul class="td-tags td-post-small-box clearfix">
                                <li><span><?php esc_html_e('TAGS', 'newspaper') ?></span></li>
                                <?php
                                    foreach ($td_post_tags as $td_post_tag) { ?>
                                        <li><a href="<?php echo esc_url(get_tag_link($td_post_tag->term_id)) ?>"><?php echo esc_html($td_post_tag->name) ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                <?php }

                    // next/prev posts
                    $next_post = get_next_post();
                    $prev_post = get_previous_post();

                    if (!empty($next_post) or !empty($prev_post)) { ?>
                        <div class="td-block-row td-post-next-prev">
                            <?php if (!empty($prev_post)) { ?>
                                <div class="td-block-span6 td-post-prev-post">
                                    <div class="td-post-next-prev-content">
                                        <span><?php esc_html_e('Previous news', 'newspaper') ?></span>
                                        <a href="<?php echo esc_url(get_permalink($prev_post->ID)) ?>"><?php echo esc_html(get_the_title($prev_post->ID)) ?></a>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <div class="td-block-span6 td-post-prev-post"></div>
                            <?php } ?>

                            <div class="td-next-prev-separator"></div>

                        <?php if (!empty($next_post)) { ?>
                            <div class="td-block-span6 td-post-next-post">
                                <div class="td-post-next-prev-content">
                                    <span><?php esc_html_e('Next news', 'newspaper') ?></span>
                                    <a href="<?php echo esc_url(get_permalink($next_post->ID)) ?>"><?php echo esc_html(get_the_title($next_post->ID)) ?></a>
                                </div>
                            </div>
                        <?php } ?>
                        </div>
                <?php } ?>

                <!-- author box -->
                <?php
//                $author_id = get_the_author_meta( 'ID' );
                ?>
<!--                <div class="author-box-wrap">
                    <a href="<?php echo esc_url(get_author_posts_url($author_id)) ?>">
                        <?php echo get_avatar(get_the_author_meta('email', $author_id), '96') ?>
                    </a>

                    <div class="desc">
                        <div class="td-author-name vcard author"><span class="fn">
                            <a href="<?php echo esc_url(get_author_posts_url($author_id)) ?>"><?php echo get_the_author_meta('display_name', $author_id) ?></a>
                        </span></div>

                        <?php  if (get_the_author_meta('user_url', $author_id) != '') { ?>
                            <div class="td-author-url"><a href="<?php echo esc_url(get_the_author_meta('user_url', $author_id)) ?>"><?php echo esc_url(get_the_author_meta('user_url', $author_id)) ?></a></div>
                        <?php } ?>

                        <div class="td-author-description">
                            <?php echo esc_html(get_the_author_meta('description', $author_id)) ?>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                </div>-->
            </footer>
        </div>
        <style type="text/css">
            .td-post-next-prev-content span {
    display: block;
    font-size: 16px;
    color: #333;
    margin-bottom: 7px;
    font-weight: 600;
}
.td-post-next-prev-content a {
    display: block;
    font-size: 17px;
    color: #222;
    line-height: 21px;
    margin-bottom: 43px;
    font-weight: 900;
}
        </style>
    </article>
<?php } ?>
<?php 
//echo do_shortcode('[tdc_zone type="tdc_content"][vc_row tdc_css="eyJhbGwiOnsicGFkZGluZy10b3AiOiI0MCIsImRpc3BsYXkiOiIifX0="][vc_column][td_flex_block_1 modules_on_row="" limit="10" hide_audio="yes" image_size="td_1920x0" image_height="100" image_floated="eyJhbGwiOiJmbG9hdF9sZWZ0IiwicGhvbmUiOiJub19mbG9hdCJ9" image_width="eyJhbGwiOiIyMCIsInBvcnRyYWl0IjoiNDAiLCJwaG9uZSI6IjEwMCJ9" meta_margin="eyJhbGwiOiIxMHB4IiwicGhvbmUiOiIwcHgifQ==" meta_padding="10px" installed_post_types="news" sort="oldest_posts" ajax_pagination="load_more" custom_title="In Other News" block_template_id="td_block_template_9" td_ajax_filter_type="td_category_ids_filter" show_author="none" show_date="none" show_review="none" show_com="none"][/vc_column][/vc_row][/tdc_zone]');
echo do_shortcode('[tdc_zone type="tdc_content"][vc_row tdc_css="eyJhbGwiOnsicGFkZGluZy10b3AiOiI0MCIsImRpc3BsYXkiOiIifX0="][vc_column][td_flex_block_1 modules_on_row="" limit="10" hide_audio="yes" image_size="td_1920x0" image_height="100" image_floated="eyJhbGwiOiJmbG9hdF9sZWZ0IiwicGhvbmUiOiJub19mbG9hdCJ9" image_width="eyJhbGwiOiIyMCIsInBvcnRyYWl0IjoiNDAiLCJwaG9uZSI6IjEwMCJ9" meta_margin="eyJhbGwiOiIxMHB4IiwicGhvbmUiOiIwcHgifQ==" meta_padding="10px" installed_post_types="news" sort="oldest_posts" ajax_pagination="load_more" custom_title="In Other News" block_template_id="td_block_template_9" show_author="none" show_date="none" show_review="none" show_com="none"][/vc_column][/vc_row][/tdc_zone]');

         ?>