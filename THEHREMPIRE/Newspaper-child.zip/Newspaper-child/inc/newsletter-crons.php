<?php

function newsletter_daily_func() {
    global $wpdb;
    $email_content = preview_daily_newsletter();

    $dynamic_template_id = sendgridController::SG_DYNAMIC_EMAIL_TEMPLATES['newsletter_daily'];

    $query = "SELECT * FROM `{$wpdb->prefix}posts` WHERE post_date >= '" . date('Y-m-d', strtotime('-1 day')) . "' AND post_date < '" . date('Y-m-d') . "' AND post_type IN ('news') AND post_status = 'publish' ORDER BY `{$wpdb->prefix}posts`.`post_date` DESC LIMIT 0, 1";

    $result = $wpdb->get_row($query, OBJECT);
    ;

    $top_news = $result->post_title;

    if (!empty($top_news)) {
        $response = sendgridController::send_newsletter($dynamic_template_id, sendgridController::SG_UNSUBSCRIBE_GROUPS['daily'], array(
                    'email_content' => $email_content,
                    'current_date' => date('F j, Y'),
                    'curr_year' => date('Y'),
                    'brand_name' => get_bloginfo('name'),
                    'newsletter_title' => ti_daily_unsub_title,
                    'home_url' => home_url(),
                    'top_news' => $top_news,
                    'privacy_policy_url' => site_url('privacy-policy'),
                    'terms_of_service_url' => site_url('terms-of-service'),
                    'contact_us_url' => site_url('contact-us'),
                    'news_url' => site_url('news'),
                    'facebook_link' => esc_attr(get_option('facebook_link')),
                    'twitter_link' => esc_attr(get_option('twitter_link')),
                    'linkedin_link' => esc_attr(get_option('linkedin_link')),
                    'instagram_link' => esc_attr(get_option('instagram_link')),
                    'manage_your_preferences_link' => site_url('my-account/email-preferences'),
                        ), 'daily');
    }

    exit();
}

add_action('newsletter_daily', 'newsletter_daily_func');

function newsletter_weekly_func() {

    global $wpdb;

    $email_content = preview_weekly_newsletter();

    $dynamic_template_id = sendgridController::SG_DYNAMIC_EMAIL_TEMPLATES['newsletter_weekly'];
    $query = "SELECT * FROM `{$wpdb->prefix}posts` WHERE post_date >= '" . date('Y-m-d', strtotime('-1 week')) . "' AND post_date < '" . date('Y-m-d', strtotime('-1 day')) . "' AND post_type IN ('news') AND post_status = 'publish' ORDER BY `{$wpdb->prefix}posts`.`post_date` ASC LIMIT 0, 1";
    $result = $wpdb->get_row($query, OBJECT);

    $todays_post = $result;

    if (!empty($todays_post)) {
        $response = sendgridController::send_newsletter($dynamic_template_id, sendgridController::SG_UNSUBSCRIBE_GROUPS['weekly'], array(
                    'email_content' => $email_content,
                    'curr_year' => date('Y'),
                    'brand_name' => get_bloginfo('name'),
                    'newsletter_title' => ti_weekly_unsub_title,
                    'home_url' => home_url(),
                    'privacy_policy_url' => site_url('privacy-policy'),
                    'terms_of_service_url' => site_url('terms-of-service'),
                    'contact_us_url' => site_url('contact-us'),
                    'blogs_url' => site_url('blog'),
                    'facebook_link' => esc_attr(get_option('facebook_link')),
                    'twitter_link' => esc_attr(get_option('twitter_link')),
                    'linkedin_link' => esc_attr(get_option('linkedin_link')),
                    'instagram_link' => esc_attr(get_option('instagram_link')),
                    "manage_your_preferences_link" => site_url('my-account/email-preferences'),
                        ), 'weekly');
    }
    exit();
}

add_action('newsletter_weekly', 'newsletter_weekly_func');

function newsletter_monthly_func() {

    if (date('Y-m-d') !== date('Y-m-t')) {
        exit(0);
    }

    $email_content = preview_monthly_newsletter();

    $dynamic_template_id = sendgridController::SG_DYNAMIC_EMAIL_TEMPLATES['newsletter_monthly'];
    $response = sendgridController::send_newsletter($dynamic_template_id, sendgridController::SG_UNSUBSCRIBE_GROUPS['monthly'], array(
                'email_content' => $email_content,
                'brand_name' => get_bloginfo('name'),
                'home_url' => home_url(),
                'newsletter_title' => ti_monthly_unsub_title,
                'privacy_policy_url' => site_url('privacy-policy'),
                'terms_of_service_url' => site_url('terms-of-service'),
                'contact_us_url' => site_url('contact-us'),
                'blogs_url' => site_url('blogs'),
                'facebook_link' => esc_attr(get_option('facebook_link')),
                'twitter_link' => esc_attr(get_option('twitter_link')),
                'linkedin_link' => esc_attr(get_option('linkedin_link')),
                'instagram_link' => esc_attr(get_option('instagram_link')),
                'month' => date('F') . ', ' . date('Y'),
                'curr_year' => date('Y'),
                'manage_your_preferences_link' => site_url('my-account/email-preferences'),
                    ), 'monthly');

    exit();
}

add_action('newsletter_monthly', 'newsletter_monthly_func');
