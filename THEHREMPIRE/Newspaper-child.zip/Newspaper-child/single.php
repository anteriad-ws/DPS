<?php get_header();
    global $content_width;

    $content_width = 1068;
    
    function the_breadcrumb() {

    $sep = ' > ';

    if (!is_front_page()) {
	
	// Start the breadcrumb with a link to your homepage
        echo '<div class="breadcrumbs">';
        echo '<a href="';
        echo get_option('home');
        echo '">';
        bloginfo('name');
        echo '</a>' . $sep;
	
	// Check if the current page is a category, an archive or a single page. If so show the category or archive name.
        if (is_category() || is_single() ){
            the_category('title_li=');
        } elseif (is_archive() || is_single()){
            if ( is_day() ) {
                printf( __( '%s', 'text_domain' ), get_the_date() );
            } elseif ( is_month() ) {
                printf( __( '%s', 'text_domain' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'text_domain' ) ) );
            } elseif ( is_year() ) {
                printf( __( '%s', 'text_domain' ), get_the_date( _x( 'Y', 'yearly archives date format', 'text_domain' ) ) );
            } else {
                _e( 'Blog Archives', 'text_domain' );
            }
        }
	
	// If the current page is a single post, show its title with the separator
        if (is_single()) {
            echo $sep;
            the_title();
        }
	
	// If the current page is a static page, show its title.
        if (is_page()) {
            echo the_title();
        }
	
	// if you have a static page assigned to be you posts list page. It will find the title of the static page and display it. i.e Home >> Blog
        if (is_home()){
            global $post;
            $page_for_posts_id = get_option('page_for_posts');
            if ( $page_for_posts_id ) { 
                $post = get_page($page_for_posts_id);
                setup_postdata($post);
                the_title();
                rewind_posts();
            }
        }

        echo '</div>';
    }
}
?>

    <div class="td-main-content-wrap td-container-wrap">
        <div class="td-container">
            <div class="td-crumb-container">
                <?php 
//                echo tagdiv_page_generator::get_breadcrumbs(array(
//                    'template' => 'single',
//                    'title' => get_the_title(),
//                )); 
                
//                echo get_the_title( $post->post_parent );
//                echo '<pre>';
//                print_r(get_post_type( get_the_ID()));
//                echo '</pre>';
                ?>
                <div class="td-crumb-container">
                <div class="entry-crumbs"><span>
                        <a title="" class="entry-crumb" href="<?php echo home_url(); ?>">Home</a>
                    </span> 
                    <i class="td-icon-right td-bread-sep"></i> 
                    <span>
                        <!--<a title="View all posts in Leadership" class="entry-crumb" href="#">-->
                        
                               <?php echo ucfirst(get_post_type( get_the_ID())); ?>
                    <!--</a>-->
                    </span> 
                    <i class="td-icon-right td-bread-sep td-bred-no-url-last"></i> 
                    <span class="td-bred-no-url-last">
                        <?php echo get_the_title(); ?>
                    </span></div>            
                </div>
            </div>

            <div class="td-pb-row">
                <div class="td-pb-span12 td-main-content">
                    <div class="td-ss-main-content">
                        <?php
                        get_template_part('loop-single' );
                        comments_template('', true);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php get_footer(); ?>