<p>This Cookie Policy explains what cookies are and how we use them, the types of cookies we use i.e, the information we collect using cookies and how that information is used, and how to control the cookie preferences. For further information on how we use, store, and keep your personal data secure, see our Privacy Policy.</p>

<p>You can at any time change or withdraw your consent from the Cookie Declaration on our website</p>
<p>Learn more about who we are, how you can contact us, and how we process personal data in our Privacy Policy.</p>
<p>Your consent applies to the following domains: {{site_url}}</p>
<p>[user_consent_state]</p>