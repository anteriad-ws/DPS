<?php get_header();
    //setPostViews(get_the_ID());
    global $content_width;

    $content_width = 1068;
?>

<style>
    .single-news-image{
        width:700px;
        
    }
    
    .herald-post-thumbnail{
        background-color: transparent !important;
    }

    .herald-ovrld{
        background: transparent !important;
    }
</style>

    <div id="content" class="herald-site-content herald-slide">
        <div class="herald-section container" style="margin-bottom: 25px;">
            <?php
                get_template_part('loop-news' );
                comments_template('', true);
            ?>
        </div>
    </div>

<?php get_footer(); ?>