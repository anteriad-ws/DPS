<title>Cloud Tech Alert - Sign In | Register</title>
<?php
/**
 * User Registration Form
 *
 * Shows user registration form
 *
 * This template can be overridden by copying it to yourtheme/user-registration/form-registration.php.
 *
 * HOWEVER, on occasion UserRegistration will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.wpeverest.com/user-registration/template-structure/
 * @author  WPEverest
 * @package UserRegistration/Templates
 * @version 1.0.0
 */
/**
 * @var $form_data_array array
 * @var $form_id         int
 * @var $is_field_exists boolean
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

$frontend = UR_Frontend::instance();
$form_template = ur_get_form_setting_by_key($form_id, 'user_registration_form_template', 'Default');
$custom_class = ur_get_form_setting_by_key($form_id, 'user_registration_form_custom_class', '');
$redirect_url = ur_get_form_setting_by_key($form_id, 'user_registration_form_setting_redirect_options', '');
$template_class = '';

if ('Bordered' === $form_template) {
    $template_class = 'ur-frontend-form--bordered';
} elseif ('Flat' === $form_template) {
    $template_class = 'ur-frontend-form--flat';
} elseif ('Rounded' === $form_template) {
    $template_class = 'ur-frontend-form--rounded';
} elseif ('Rounded Edge' === $form_template) {
    $template_class = 'ur-frontend-form--rounded ur-frontend-form--rounded-edge';
}

$custom_class = apply_filters('user_registration_form_custom_class', $custom_class, $form_id);

/**
 * @since 1.5.1
 */
do_action('user_registration_before_registration_form', $form_id);
?>
<!-- CSS -->
<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.min.css">

<!-- JS -->
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.jquery.min.js"></script>

<div class='user-registration ur-frontend-form <?php echo $template_class . ' ' . $custom_class; ?>' id='user-registration-form-<?php echo absint($form_id); ?>'>
    <form method='post' autocomplete="off" class='register' data-enable-strength-password="<?php echo $enable_strong_password; ?>" data-minimum-password-strength="<?php echo $minimum_password_strength; ?>" <?php echo apply_filters('user_registration_form_params', ''); ?>>

        <?php
        do_action('user_registration_before_form_fields', $form_data_array, $form_id);
        ?>
        <div class="ur-form-row ur-form-row-1">
            <div class="ur-form-grid">
                <div class="ur-field-item field-user_email">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="user_email_field" data-priority="">
                        <input data-rules="" data-id="user_email" type="email" class="input-text input-email ur-frontend-field td-login-input" name="user_email" id="user_email" value="" required="required" data-label="User Email" aria-invalid="true" placeholder="Business E-mail *" onkeypress="return event.keyCode != 13;">
                        <!--<i class="fas fa-spin fa-spinner hide-ele" id="email-spinner"></i>-->
                    </p>
                </div>
            </div>
        </div>
        <div class="ur-form-row ur-form-row-1">
            <div class="ur-form-grid password-field">
                <div class="ur-field-item field-user_pass">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="user_pass_field" data-priority="">
                        <input data-rules="" data-id="user_pass" type="password" class="input-text input-password ur-frontend-field td-login-input" name="user_pass" id="user_pass" value="" required="required" data-label="Password" aria-invalid="true" placeholder="Password *" onkeypress="return event.keyCode != 13;">
                    </p>
                </div>
            </div>
        </div>
        <div class="ur-form-row ur-form-row-1">
            <div class="ur-form-grid form-register-row-col">
                <div class="ur-field-item field-first_name">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="first_name_field" data-priority="">
                        <input data-rules="" data-id="first_name" type="text" class="input-text input-text ur-frontend-field td-login-input" name="first_name" id="first_name" value="" required="required" data-label="First Name" aria-invalid="true" placeholder="First Name *" onkeypress="return event.keyCode != 13;">
                    </p>
                </div>
            </div>
        </div>

        <div class="ur-form-row ur-form-row-1" id="">
            <div class="ur-form-grid form-register-row-col">
                <div class="ur-field-item field-last_name">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="last_name_field" data-priority="">
                        <input data-rules="" data-id="last_name" type="text" class="input-text input-text ur-frontend-field td-login-input" name="last_name" id="last_name" value="" required="required" data-label="Last Name" aria-invalid="true" placeholder="Last Name *" onkeypress="return event.keyCode != 13;">
                    </p>
                </div>
            </div>
        </div>

        <div class="ur-form-row ur-form-row-1" id="">
            <div class="ur-form-grid">
                <div class="ur-field-item field-select">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="company_name_field" data-priority="">
                        <input data-rules="" data-id="company_name" type="text" class="input-text input-text ur-frontend-field td-login-input" name="company_name" id="company_name" value="" required="required" data-label="Company Name" maxlength="20" aria-invalid="true" placeholder="Company Name *" onkeypress="return event.keyCode != 13;">
                    </p>
                </div>
            </div>
        </div>

        <div class="ur-form-row ur-form-row-2" id="" style="display: none">
            <div class="ur-form-grid">
                <div class="ur-field-item field-select">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="job_title_field" data-priority="">
                        <input data-rules="" data-id="job_title" type="text" class="input-text input-text ur-frontend-field td-login-input" name="job_title" id="job_title" value="" required="required" data-label="Job Title" maxlength="127" aria-invalid="true" placeholder="Job Title *" onkeypress="return event.keyCode != 13;">
                    </p>
                </div>
            </div>
        </div>
        <div class="ur-form-row ur-form-row-2" id="" style="display: none">
            <div class="ur-form-grid">
                <div class="ur-field-item field-select">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="country_field" data-priority="">
                        <!--<input data-rules="" data-id="country" type="text" class="input-text input-text ur-frontend-field td-login-input" name="country" id="country" value="" data-label="Country" maxlength="20" aria-invalid="true" placeholder="Select Country">--><select data-rules="" data-id="country" type="text" name="country" id="country" value="" data-label="Country" class="input-text input-text ur-frontend-field td-login-input chosen-select">
                            <option value="">Select Country</option>
                            <option value="Afganistan">Afghanistan</option>
                            <option value="Albania">Albania</option>
                            <option value="Algeria">Algeria</option>
                            <option value="American Samoa">American Samoa</option>
                            <option value="Andorra">Andorra</option>
                            <option value="Angola">Angola</option>
                            <option value="Anguilla">Anguilla</option>
                            <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
                            <option value="Argentina">Argentina</option>
                            <option value="Armenia">Armenia</option>
                            <option value="Aruba">Aruba</option>
                            <option value="Australia">Australia</option>
                            <option value="Austria">Austria</option>
                            <option value="Azerbaijan">Azerbaijan</option>
                            <option value="Bahamas">Bahamas</option>
                            <option value="Bahrain">Bahrain</option>
                            <option value="Bangladesh">Bangladesh</option>
                            <option value="Barbados">Barbados</option>
                            <option value="Belarus">Belarus</option>
                            <option value="Belgium">Belgium</option>
                            <option value="Belize">Belize</option>
                            <option value="Benin">Benin</option>
                            <option value="Bermuda">Bermuda</option>
                            <option value="Bhutan">Bhutan</option>
                            <option value="Bolivia">Bolivia</option>
                            <option value="Bonaire">Bonaire</option>
                            <option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
                            <option value="Botswana">Botswana</option>
                            <option value="Brazil">Brazil</option>
                            <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                            <option value="Brunei">Brunei</option>
                            <option value="Bulgaria">Bulgaria</option>
                            <option value="Burkina Faso">Burkina Faso</option>
                            <option value="Burundi">Burundi</option>
                            <option value="Cambodia">Cambodia</option>
                            <option value="Cameroon">Cameroon</option>
                            <option value="Canada">Canada</option>
                            <option value="Canary Islands">Canary Islands</option>
                            <option value="Cape Verde">Cape Verde</option>
                            <option value="Cayman Islands">Cayman Islands</option>
                            <option value="Central African Republic">Central African Republic</option>
                            <option value="Chad">Chad</option>
                            <option value="Channel Islands">Channel Islands</option>
                            <option value="Chile">Chile</option>
                            <option value="China">China</option>
                            <option value="Christmas Island">Christmas Island</option>
                            <option value="Cocos Island">Cocos Island</option>
                            <option value="Colombia">Colombia</option>
                            <option value="Comoros">Comoros</option>
                            <option value="Congo">Congo</option>
                            <option value="Cook Islands">Cook Islands</option>
                            <option value="Costa Rica">Costa Rica</option>
                            <option value="Cote DIvoire">Cote DIvoire</option>
                            <option value="Croatia">Croatia</option>
                            <option value="Cuba">Cuba</option>
                            <option value="Curaco">Curacao</option>
                            <option value="Cyprus">Cyprus</option>
                            <option value="Czech Republic">Czech Republic</option>
                            <option value="Denmark">Denmark</option>
                            <option value="Djibouti">Djibouti</option>
                            <option value="Dominica">Dominica</option>
                            <option value="Dominican Republic">Dominican Republic</option>
                            <option value="East Timor">East Timor</option>
                            <option value="Ecuador">Ecuador</option>
                            <option value="Egypt">Egypt</option>
                            <option value="El Salvador">El Salvador</option>
                            <option value="Equatorial Guinea">Equatorial Guinea</option>
                            <option value="Eritrea">Eritrea</option>
                            <option value="Estonia">Estonia</option>
                            <option value="Ethiopia">Ethiopia</option>
                            <option value="Falkland Islands">Falkland Islands</option>
                            <option value="Faroe Islands">Faroe Islands</option>
                            <option value="Fiji">Fiji</option>
                            <option value="Finland">Finland</option>
                            <option value="France">France</option>
                            <option value="French Guiana">French Guiana</option>
                            <option value="French Polynesia">French Polynesia</option>
                            <option value="French Southern Ter">French Southern Ter</option>
                            <option value="Gabon">Gabon</option>
                            <option value="Gambia">Gambia</option>
                            <option value="Georgia">Georgia</option>
                            <option value="Germany">Germany</option>
                            <option value="Ghana">Ghana</option>
                            <option value="Gibraltar">Gibraltar</option>
                            <option value="Great Britain">Great Britain</option>
                            <option value="Greece">Greece</option>
                            <option value="Greenland">Greenland</option>
                            <option value="Grenada">Grenada</option>
                            <option value="Guadeloupe">Guadeloupe</option>
                            <option value="Guam">Guam</option>
                            <option value="Guatemala">Guatemala</option>
                            <option value="Guinea">Guinea</option>
                            <option value="Guyana">Guyana</option>
                            <option value="Haiti">Haiti</option>
                            <option value="Hawaii">Hawaii</option>
                            <option value="Honduras">Honduras</option>
                            <option value="Hong Kong">Hong Kong</option>
                            <option value="Hungary">Hungary</option>
                            <option value="Iceland">Iceland</option>
                            <option value="Indonesia">Indonesia</option>
                            <option value="India">India</option>
                            <option value="Iran">Iran</option>
                            <option value="Iraq">Iraq</option>
                            <option value="Ireland">Ireland</option>
                            <option value="Isle of Man">Isle of Man</option>
                            <option value="Israel">Israel</option>
                            <option value="Italy">Italy</option>
                            <option value="Jamaica">Jamaica</option>
                            <option value="Japan">Japan</option>
                            <option value="Jordan">Jordan</option>
                            <option value="Kazakhstan">Kazakhstan</option>
                            <option value="Kenya">Kenya</option>
                            <option value="Kiribati">Kiribati</option>
                            <option value="Korea North">Korea North</option>
                            <option value="Korea Sout">Korea South</option>
                            <option value="Kuwait">Kuwait</option>
                            <option value="Kyrgyzstan">Kyrgyzstan</option>
                            <option value="Laos">Laos</option>
                            <option value="Latvia">Latvia</option>
                            <option value="Lebanon">Lebanon</option>
                            <option value="Lesotho">Lesotho</option>
                            <option value="Liberia">Liberia</option>
                            <option value="Libya">Libya</option>
                            <option value="Liechtenstein">Liechtenstein</option>
                            <option value="Lithuania">Lithuania</option>
                            <option value="Luxembourg">Luxembourg</option>
                            <option value="Macau">Macau</option>
                            <option value="Macedonia">Macedonia</option>
                            <option value="Madagascar">Madagascar</option>
                            <option value="Malaysia">Malaysia</option>
                            <option value="Malawi">Malawi</option>
                            <option value="Maldives">Maldives</option>
                            <option value="Mali">Mali</option>
                            <option value="Malta">Malta</option>
                            <option value="Marshall Islands">Marshall Islands</option>
                            <option value="Martinique">Martinique</option>
                            <option value="Mauritania">Mauritania</option>
                            <option value="Mauritius">Mauritius</option>
                            <option value="Mayotte">Mayotte</option>
                            <option value="Mexico">Mexico</option>
                            <option value="Midway Islands">Midway Islands</option>
                            <option value="Moldova">Moldova</option>
                            <option value="Monaco">Monaco</option>
                            <option value="Mongolia">Mongolia</option>
                            <option value="Montserrat">Montserrat</option>
                            <option value="Morocco">Morocco</option>
                            <option value="Mozambique">Mozambique</option>
                            <option value="Myanmar">Myanmar</option>
                            <option value="Nambia">Nambia</option>
                            <option value="Nauru">Nauru</option>
                            <option value="Nepal">Nepal</option>
                            <option value="Netherland Antilles">Netherland Antilles</option>
                            <option value="Netherlands">Netherlands (Holland, Europe)</option>
                            <option value="Nevis">Nevis</option>
                            <option value="New Caledonia">New Caledonia</option>
                            <option value="New Zealand">New Zealand</option>
                            <option value="Nicaragua">Nicaragua</option>
                            <option value="Niger">Niger</option>
                            <option value="Nigeria">Nigeria</option>
                            <option value="Niue">Niue</option>
                            <option value="Norfolk Island">Norfolk Island</option>
                            <option value="Norway">Norway</option>
                            <option value="Oman">Oman</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="Palau Island">Palau Island</option>
                            <option value="Palestine">Palestine</option>
                            <option value="Panama">Panama</option>
                            <option value="Papua New Guinea">Papua New Guinea</option>
                            <option value="Paraguay">Paraguay</option>
                            <option value="Peru">Peru</option>
                            <option value="Phillipines">Philippines</option>
                            <option value="Pitcairn Island">Pitcairn Island</option>
                            <option value="Poland">Poland</option>
                            <option value="Portugal">Portugal</option>
                            <option value="Puerto Rico">Puerto Rico</option>
                            <option value="Qatar">Qatar</option>
                            <option value="Republic of Montenegro">Republic of Montenegro</option>
                            <option value="Republic of Serbia">Republic of Serbia</option>
                            <option value="Reunion">Reunion</option>
                            <option value="Romania">Romania</option>
                            <option value="Russia">Russia</option>
                            <option value="Rwanda">Rwanda</option>
                            <option value="St Barthelemy">St Barthelemy</option>
                            <option value="St Eustatius">St Eustatius</option>
                            <option value="St Helena">St Helena</option>
                            <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                            <option value="St Lucia">St Lucia</option>
                            <option value="St Maarten">St Maarten</option>
                            <option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
                            <option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
                            <option value="Saipan">Saipan</option>
                            <option value="Samoa">Samoa</option>
                            <option value="Samoa American">Samoa American</option>
                            <option value="San Marino">San Marino</option>
                            <option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
                            <option value="Saudi Arabia">Saudi Arabia</option>
                            <option value="Senegal">Senegal</option>
                            <option value="Seychelles">Seychelles</option>
                            <option value="Sierra Leone">Sierra Leone</option>
                            <option value="Singapore">Singapore</option>
                            <option value="Slovakia">Slovakia</option>
                            <option value="Slovenia">Slovenia</option>
                            <option value="Solomon Islands">Solomon Islands</option>
                            <option value="Somalia">Somalia</option>
                            <option value="South Africa">South Africa</option>
                            <option value="Spain">Spain</option>
                            <option value="Sri Lanka">Sri Lanka</option>
                            <option value="Sudan">Sudan</option>
                            <option value="Suriname">Suriname</option>
                            <option value="Swaziland">Swaziland</option>
                            <option value="Sweden">Sweden</option>
                            <option value="Switzerland">Switzerland</option>
                            <option value="Syria">Syria</option>
                            <option value="Tahiti">Tahiti</option>
                            <option value="Taiwan">Taiwan</option>
                            <option value="Tajikistan">Tajikistan</option>
                            <option value="Tanzania">Tanzania</option>
                            <option value="Thailand">Thailand</option>
                            <option value="Togo">Togo</option>
                            <option value="Tokelau">Tokelau</option>
                            <option value="Tonga">Tonga</option>
                            <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
                            <option value="Tunisia">Tunisia</option>
                            <option value="Turkey">Turkey</option>
                            <option value="Turkmenistan">Turkmenistan</option>
                            <option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
                            <option value="Tuvalu">Tuvalu</option>
                            <option value="Uganda">Uganda</option>
                            <option value="United Kingdom">United Kingdom</option>
                            <option value="Ukraine">Ukraine</option>
                            <option value="United Arab Erimates">United Arab Emirates</option>
                            <option value="United States of America">United States of America</option>
                            <option value="Uraguay">Uruguay</option>
                            <option value="Uzbekistan">Uzbekistan</option>
                            <option value="Vanuatu">Vanuatu</option>
                            <option value="Vatican City State">Vatican City State</option>
                            <option value="Venezuela">Venezuela</option>
                            <option value="Vietnam">Vietnam</option>
                            <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                            <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                            <option value="Wake Island">Wake Island</option>
                            <option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
                            <option value="Yemen">Yemen</option>
                            <option value="Zaire">Zaire</option>
                            <option value="Zambia">Zambia</option>
                            <option value="Zimbabwe">Zimbabwe</option>
                        </select>
                    </p>
                </div>
            </div>
        </div>

        <div class="ur-form-row ur-form-row-2" id="" style="display: none">
            <div class="ur-form-grid">
                <div class="ur-field-item field-select">
                    <p class="user-registration-form-row user-registration-form-row--wide form-row form-row-wide" id="contact_no_field" data-priority="">
                        <input data-rules="" data-id="contact_no" type="text" class="input-text input-text ur-frontend-field td-login-input" name="contact_no" id="contact_no" value="" data-label="Contact Number" maxlength="20" aria-invalid="true" placeholder="Contact Number" onkeypress="return event.keyCode != 13;">
                    </p>
                </div>
            </div>
        </div>

        <?php
        do_action('user_registration_after_form_fields', $form_data_array, $form_id);
        ?>
        <div class="ur-form-row-2 check-text form-margin-top-10" id="" style="display: none">
            <div class="ur-form-grid">
                <div class="ur-field-item field-newsletter_check">
                    <label class="user-registration-form__label user-registration-form__label-for-checkbox inline container-label set-relative">
                        <input class="user-registration-form__input user-registration-form__input-checkbox register_check form-margin-top-0" name="newsletter_check" type="checkbox" id="newsletter_check" value="forever" /> <span><?php _e('Yes, I want to receive emails from CloudTech Alert that may be of interest to me.', 'user-registration-terms'); ?></span>
                        <span class="checkmark"></span>
                    </label>
                </div>
            </div>
        </div>

        <div class="ur-form-row-2 check-text set-relative" id="" style="display: none">
            <div class="ur-form-grid">
                <div class="ur-field-item field-privacy_check">
                    <label class="user-registration-form__label user-registration-form__label-for-checkbox inline container-label set-relative">
                        <input class="user-registration-form__input user-registration-form__input-checkbox register_check form-margin-top-0" name="privacy_check" type="checkbox" id="privacy_check" required="true" value="checked"/> <span>
                            
                            By registering, I agree to The CloudTech Alert's (c/o Anteriad) <a class="form-check-a" target="_blank" href="<?php echo site_url('terms-of-service') ?>" style="color:#2291ed;">Terms of Service</a> and <a class="form-check-a" href="https://anteriad.com/privacy-policy/" target="_blank" style="color:#2291ed;">Privacy Policy</a>. I also understand that I can review and update my marketing preferences at any time. 

                           <!--  I understand by creating an account, I agree to Cloud Tech Alert's <a class="form-check-a" href="<?php //echo site_url('terms-of-service') ?>">Terms of Use</a> and <a class="form-check-a" href="https://anteriad.com/privacy-policy/" target="_blank">Privacy Policy</a> and that I may review and update my marketing preferences at any time. -->
                         <!-- Check this to turn on GDPR related features and enhancement. Read our <a class="form-check-a" href="<?php //echo site_url('gdpr-general-data-protection-regulation'); ?>">GDPR DOCUMENTATION</a> to learn more.<abbr class="required" title="required">*</abbr></span> -->
                        <span class="checkmark"></span>
                    </label>
                    <!--</div>-->
                </div>
            </div>
        </div>

        <div class="go-back" style="display: none">< Go Back</div>
        <?php
        if (!empty($recaptcha_node)) {
            echo '<div id="ur-recaptcha-node" style="width:100px;max-width: 100px;"> ' . $recaptcha_node . '</div>';
        }
        ?>
        <!--</div>-->
        <?php
        if ($is_field_exists) {
            ?>
            <?php
//            if (!empty($recaptcha_node)) {
//                echo '<div id="ur-recaptcha-node" style="width:100px;max-width: 100px;"> ' . $recaptcha_node . '</div>';
//            }

            $btn_container_class = apply_filters('user_registration_form_btn_container_class', array(), $form_id);
            ?>
            <div class="ur-button-container <?php echo esc_html(implode(' ', $btn_container_class)); ?>" >
                <?php
                do_action('user_registration_before_form_buttons', $form_id);

                $submit_btn_class = apply_filters('user_registration_form_submit_btn_class', array(), $form_id);
                ?>

                <button type="submit" disabled="true" class="btn button ur-submit-button <?php echo esc_html(implode(' ', $submit_btn_class)); ?>">
                    <span></span>
                    <?php
                    $submit = ur_get_form_setting_by_key($form_id, 'user_registration_form_setting_form_submit_label');
                    echo ur_string_translation($form_id, 'user_registration_form_setting_form_submit_label', $submit);
                    ?>
                </button>

                <?php do_action('user_registration_after_form_buttons', $form_id); ?>
            </div>
            <?php
        }

        if (count($form_data_array) == 0) {
            ?>
            <h2><?php echo esc_html__('Form not found, form id :' . $form_id, 'user-registration'); ?></h2>
            <?php
        }
        ?>
        <div class="ur-button-container ur-form-row-2 form-no-padding-margin" style="display: none">
            <button type="submit" class="wpb_button btn td-login-button ur-submit-button " id="register_button">
                <span></span>Register
            </button>
        </div>
        <div class="ur-button-container save-form-btn form-padding-0 ur-form-row-1">
            <button type="button" class="wpb_button btn td-login-button ur-submit-button" id="save_form">
                <span></span>Submit
            </button>
        </div>
        <div class="clearfix"></div>
        <div class="ur-form-grid">
            <input type="hidden" name="ur-user-form-id" value="<?php echo absint($form_id); ?>"/>
            <input type="hidden" name="ur-redirect-url" class="ur-frontend-field" value="<?php echo site_url('sign-in') . '?msg=registered'; ?>"/>
            <?php wp_nonce_field('ur_frontend_form_id-' . $form_id, 'ur_frontend_form_nonce', false); ?>
        </div>

        <?php do_action('user_registration_form_registration_end', $form_id); ?>
    </form>

    <div class="clearfix"></div>
</div>
<script>
    function onSubmit(token) {
        document.getElementByClass("register").submit();
    }
</script>
<?php
/**
 * User registration form template.
 *
 * @since 1.0.0
 */
do_action('user_registration_form_registration', $form_id);

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
