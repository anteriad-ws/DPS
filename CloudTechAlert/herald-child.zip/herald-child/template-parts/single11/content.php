<div class="entry-content herald-entry-content">

	<style type="text/css">
		.td-post-date.td-post-source.news-source {
    display: none;
}
.meta-tags {
    margin-bottom: 10px;
}
.news-source {
    margin-bottom: 20px;
}
	</style>

	<?php if( herald_is_paginated_post() && strpos( herald_get_option( 'single_paginated_nav_position'), 'above' ) !== false ) : ?>
		<?php get_template_part( 'template-parts/single/paginated-nav' ); ?>
	<?php endif; ?>

	<?php if( herald_get_post_display( 'headline' ) && has_excerpt() ): ?>
		<div class="entry-headline h5"><?php echo get_the_excerpt(); ?></div>
	<?php endif; ?>

	<?php if( herald_get_post_display( 'ad_above' ) ) : ?>
		<?php get_template_part('template-parts/ads/above-single'); ?>
	<?php endif; ?>

	<?php $share_option = herald_get_option('single_share_content_position'); ?>
	<?php if (  strpos($share_option, 'above') !== false ): ?>
		<?php get_template_part( 'template-parts/single/share' ); ?>
	<?php endif ?>
	
	<?php the_content(); ?>

	<?php if( herald_is_paginated_post() && strpos( herald_get_option( 'single_paginated_nav_position'), 'below' ) !== false ) : ?>
		<?php get_template_part( 'template-parts/single/paginated-nav' ); ?>
	<?php endif; ?>

	<?php if( herald_get_post_display( 'tags' ) && has_tag() ) : ?>
		<div class="meta-tags">
			<span><?php echo __herald('tagged_as'); ?></span><?php the_tags( false, ' ', false ); ?>
		</div>
		<!-- News Source -->
		<div class="news-source">
				<?php if(get_post_type( get_the_ID()) == 'news') { ?>
					<span class="td-post-date td-post-source">
						<strong>News Source: </strong>
						<a href="<?php echo (get_post_meta($post->ID, '_source_url', true) != '') ? get_post_meta($post->ID, '_source_url', true) : home_url(); ?>" target="_blank">
							<?php echo (get_post_meta($post->ID, '_source_name', true) != '') ? get_post_meta($post->ID, '_source_name', true) : 'source'; ?>
						</a>
					</span>
				<?php }?>
			</div>
			<!-- News Source End -->
	<?php endif; ?>

	<?php if (  strpos($share_option, 'below') !== false ): ?>
		<?php get_template_part( 'template-parts/single/share' ); ?>
	<?php endif ?>

	<?php if( herald_get_post_display( 'ad_below' ) ) : ?>
		<?php get_template_part('template-parts/ads/below-single'); ?>
	<?php endif; ?>
</div>