<?php if ( function_exists('meks_ess_share') ) : ?>
	<ul class="herald-share">
		<span class="herald-share-meta"><i class="fa fa-share-alt"></i><?php echo __herald( 'share_text' );?></span>
		<div class="meta-share-wrapper">
			<?php	
				$share_settings = get_option('meks_ess_settings');
				$share_class = herald_sticky_share_bar_classes( $share_settings );
				meks_ess_share( $share_settings['platforms'] , true, '<div class="meks_ess '. $share_class .' ">', '</div>' );
			?>
			<?php //meks_ess_share(); ?>
	 	</div>
	</ul>
<?php endif; ?>