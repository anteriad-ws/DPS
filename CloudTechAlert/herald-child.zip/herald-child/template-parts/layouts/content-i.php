<article <?php post_class('herald-lay-i'); ?>>
	

	<?php if ( $fimg = herald_get_featured_image( 'herald-lay-i' ) ) : ?>
		<div class="herald-post-thumbnail herald-format-icon-small">
			<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
				<?php echo herald_wp_kses( $fimg ); ?>
				<?php echo herald_post_format_icon(); ?>
			</a>
		</div>
	<?php endif; ?>


	<div class="entry-header">
		<?php if( herald_get_option( 'lay_i_cat' ) ) : ?>
			<span class="meta-category meta-small"><?php echo herald_get_category(); ?></span>
		<?php endif; ?>

		

		<?php if( $meta = herald_get_meta_data( 'i' ) ) : ?>
			<!-- <div class="entry-meta meta-small"><?php echo wp_kses_post( $meta ); ?></div> -->
		<?php endif; ?>
		<div class="entry-meta meta-small">
			<!-- client name -->
			<?php
					$sponsored_by = get_the_terms($post->ID, 'sponsored_by');
					foreach ($sponsored_by as $sponsored_by_single) {
					?>
					<!-- <i class="fa fa-suitcase" style="font-size: 1.0rem;color: #999999;" aria-hidden="true"></i>  -->
					
					<a class="meta-item resource-client-name" 
							href="<?php echo get_term_link($sponsored_by_single->term_id); ?>"><?php echo $sponsored_by_single->name; ?></a>  
				<?php } ?>

				<!-- resource type -->
				<?php $categories = get_the_terms($loop->post->ID, "resource_types"); 
						if($categories){
							foreach ($categories as $category) { ?>
								<div style="float:right;margin-right:-3%;">
								<!-- <i class="fa fa-file-pdf-o" aria-hidden="true" style="font-size: 1.0rem;color: #999999;"></i>  -->
								<a  class="meta-item resource-type"
									href="<?php echo get_term_link($category->term_id); ?> "><?php echo $category->name; ?></a></div>
				<?php       }                   
						}?>
		</div>
		<?php the_title( sprintf( '<h2 class="entry-title h5"><a href="%s">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		
	</div>
	<a class="herald-read-more resource-cta-btn" href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php echo "Download"; ?></a>

</article>