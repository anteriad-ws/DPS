<?php get_header(); ?>

<?php if( $fa = herald_get_featured_area() ) : ?>
		<?php if(!empty($fa['query']) && !empty( $fa['query']->posts ) ): ?>
			<?php $fa_query = $fa['query']; ?>
			<div class="herald-section container herald-no-sid">
				<div class="row">
					<div class="herald-module col-lg-12 col-md-12">
						<?php herald_set_img_flag('full'); ?>
						<?php include( locate_template('template-parts/featured/area-'. $fa['layout'].'.php' ) ); ?>
						<?php herald_set_img_flag(''); ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
<?php endif; ?>

<?php global $herald_sidebar_opts; ?>
<?php $section_class = $herald_sidebar_opts['use_sidebar'] == 'none' ? 'herald-no-sid' : '' ?>

<div class="herald-section container <?php echo esc_attr($section_class); ?>">
	<div class="row">
        
        <?php if($herald_sidebar_opts['use_sidebar'] == 'left'): ?>
			<?php get_sidebar(); ?>
            <?php endif; ?>
            
        <?php $wrap_class = $herald_sidebar_opts['use_sidebar'] != 'none' ? 'herald-main-content col-lg-9 col-md-9' : 'col-lg-12 col-md-12' ?>

		<div class="herald-module col-mod-main <?php echo esc_attr($wrap_class); ?>">
            
        <div class="herald-mod-wrap">
            <div class="herald-mod-head">
                <div class="herald-mod-title">
                    <h1 class="h6 herald-mod-h herald-color">Videos</h1>
                </div>
            </div>
        </div>

			<?php echo herald_get_archive_heading(); ?>
		
			<?php $ad_position = herald_get_option('ad_between_posts') ? absint( herald_get_option('ad_between_posts_position') - 1 ) : false ; ?>

			<div class="row row-eq-height herald-posts">
				<?php if(have_posts()): ?>
					<?php $i = 0; while ( have_posts() ) : the_post(); ?>
					<!-- content -->
                    <article <?php post_class('herald-lay-f'); ?>>
                        <?php if ( $fimg = herald_get_featured_image( 'herald-lay-f' ) ) : ?>
                            <div class="herald-post-thumbnail herald-format-icon-middle">
                                <a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
                                    <?php echo herald_wp_kses( $fimg ); ?>
                                    <?php echo herald_post_format_icon(); ?>
                                    <span class="herald-format-icon"><i class="fa fa-play"></i></span>
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="entry-header">
                            <?php if( herald_get_option( 'lay_f_cat' ) ) : ?>
                                <span class="meta-category meta-small"><?php echo herald_get_category(); ?></span>
                            <?php endif; ?>

                            <?php the_title( sprintf( '<h2 class="entry-title h5"><a href="%s">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

                            <?php if( $meta = herald_get_meta_data( 'f' ) ) : ?>
                                <div class="entry-meta meta-small"><?php echo wp_kses_post( $meta ); ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if( herald_get_option('lay_f_excerpt') ) : ?>
                            <div class="entry-content">
                                <?php echo herald_get_excerpt( 'f' ); ?>
                            </div>
                        <?php endif; ?>

                        <?php if( herald_get_option('lay_f_rm') ) : ?>
                            <a class="herald-read-more" href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php echo __herald('read_more'); ?></a>
                        <?php endif; ?>

                    </article>
					<!-- content end -->
                    <?php if( $i === $ad_position ) { get_template_part('template-parts/ads/between-posts'); } ?>
					<?php $i++; endwhile; ?>
				<?php else : ?>
					<?php get_template_part('template-parts/layouts/content-none' ); ?>
				<?php endif;?>
			</div>
		
			<?php if( $pagination = herald_get_current_pagination() ) : ?>
				<?php get_template_part( 'template-parts/pagination/' . $pagination ); ?>
			<?php endif; ?>
				
		</div>

		<?php if( $herald_sidebar_opts['use_sidebar'] == 'right' ): ?>
			<?php get_sidebar(); ?>
		<?php endif; ?>

	</div>

</div>

<?php get_footer(); ?>