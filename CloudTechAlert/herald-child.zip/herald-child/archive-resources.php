<title>Resources | CloudTech Alert</title>
<?php get_header(); ?>


    <div class="herald-section container herald-no-sid " id="herald-section-0">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="herald-module col-lg-12 col-md-12 col-sm-12" id="herald-module-0-0" data-col="12">
                        <!-- header -->
                        <div class="herald-mod-wrap"><div class="herald-mod-head ">
                            <div class="herald-mod-title">
                                <h2 class="h6 herald-mod-h herald-color">Resources</h2>
                            </div>
                        </div>
                        <!-- content -->
                        <div class="row herald-posts row-eq-height ">
                           <?php get_template_part('loop-resources'); ?>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


<?php
get_footer();
?>
