	<?php
    if(function_exists('show_ti_posts_fn')){
		
		do_shortcode('[show_ti_posts type="resources" ppp="9" show-tax="yes" tax-name="resource_types"]');
		
	}else{
		
		$default_posts_per_page = get_option( 'posts_per_page' );

		$args = array(
			'post_type' => 'resources',
			'posts_per_page' => $default_posts_per_page
		);

		$loop = new WP_Query($args);
											
		if ($loop->have_posts()) {
			
			?>
		<div class="post_loop_">
			
			<?php 
			while ($loop->have_posts()) : $loop->the_post();
			
				$post_thumbnail_url = '';

				if (get_the_post_thumbnail_url(null, 'medium_large') != false) {
					
					$post_thumbnail_url = get_the_post_thumbnail_url(null, 'medium_large');
					
				} else {
					
					$post_thumbnail_url = get_template_directory_uri() . '/assets/img/resource-default.jpg';
					
				}
				?>
                <article class="herald-lay-f post-<?php echo get_post()->ID;?> resources type-resources status-publish has-post-thumbnail hentry category-business category-digital-marketing category-marketing category-martech tag-automation-platform tag-automation-strategy tag-digital-business geo-location-global resource_types-ebook sponsored_by-ibm">
                    <div class="herald-post-thumbnail herald-format-icon-middle">
                        <a href="<?php the_permalink() ?>" rel="bookmark" class="td-image-wrap " title="<?php the_title_attribute() ?>">
                            <img src="<?php echo esc_url($post_thumbnail_url) ?>)" alt="<?php the_title_attribute() ?>" class="img-responsive"  />
                        </a>
                    </div>
                    <div class="entry-header">
					    <span class="meta-category meta-small">
                            <?php
                                $categories = get_the_terms($post->ID, 'resource_types');
                                if($categories){
                                    foreach ($categories as $category) {
                                    ?>
                                <a href="<?php echo get_term_link($category->term_id); ?>" class="herald-cat-<?php echo $category->term_id; ?>"><?php echo $category->name; ?></a> 
                        </span>
                        <h2 class="entry-title h5">
                                <a href="<?php the_permalink() ?>" title="<?php the_title_attribute() ?>"><?php the_title() ?></a>
                        </h2>
                    <?php } 
						}?> 
                    </div>
                    <span class="td-author-date">
                        <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="<?php echo esc_html(date(DATE_W3C, get_the_time('U'))) ?>"><?php the_time(get_option('date_format')) ?></time></span>
                    </span>
                </article>
				<?php endwhile; ?>
		</div>		
			
		<?php }
			wp_reset_postdata();
		}
		?>