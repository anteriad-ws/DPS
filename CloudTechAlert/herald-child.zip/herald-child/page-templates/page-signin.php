<?php
/*
 * Template Name: Signin Page Template
 */

if (is_user_logged_in()){
    wp_redirect( home_url() );
    exit;
}
get_header('nomenu');
global $wp;
$current_url = home_url(add_query_arg(array(), $wp->request));
$link_array = explode('/', $current_url);
$currpage = end($link_array);
?>
<style type="text/css">
    label#checkbox_name\[\]-error {
    margin-top: -22%;
    position: relative;
}
@media only screen and (max-width: 768px)
{
   label#checkbox_name\[\]-error {
    margin-top: -18% !important;
} 
}

@media only screen and (max-width: 580px) and (min-width: 320px)  
{
    label#checkbox_name\[\]-error {
    margin-top: -37% !important;
} 

}
@media only screen and (max-width: 360px) 
{
    label#checkbox_name\[\]-error {
    margin-top: -38% !important;
} 

}

/*
.login-form-row
{
    height: 100vh;
}
*/
</style>
<div class="td-main-content-wrap td-container-wrap">

    <div class=""><!--td-container-->
        <div class="td-pb-row">
            <div class="td-pb-span12 td-main-content">
                <div class="td-ss-main-content">
                    <?php
                    if (have_posts()) {
                        while (have_posts()) : the_post();
                            ?>
                            <div class=""><!--td-page-content tagdiv-type preference-block-->

                                <div class="login-form-row">
                                    <div class="login-form-col-1">
                                        <a href="<?php echo home_url(); ?>"><img src="https://cloud-tech-alert.com/assets/CloudTechAlert_Logo_Color.png" alt="<?php echo bloginfo(); ?>" /></a>
                                        <h3 class="entry-title h3" style="padding:15px 0;">Welcome to CloudTech Alert</h3>
                                    </div>
                                    <div class="login-form-col-2">
                                        <div id="login-block" style="<?php echo ($currpage != 'register') ? 'display:block;' : 'display:none;'; ?>">
                                            <h5 class="text-center" style="padding:15px 0;">Sign In to get complete access</h5>
                                            <?php if(isset($_GET['msg']) && $_GET['msg'] == 'registered') { ?>
                                            <div class="alert alert-success">Please check your email for verification</div>
                                            <?php } 
                                            if((isset($_SESSION['registered']) && $_SESSION['registered'] == 'true')|| (isset($_GET['msg']) && $_GET['msg'] == 'verified')) { ?>
                                            <div class="alert alert-success">Your email is successfully verified. Continue to login with your chosen password to explore <?php echo bloginfo(); ?></div>
                                            <?php 
                                                unset($_SESSION['registered']);
                                            } ?>
                                            <?php echo do_shortcode('[user_registration_my_account]'); ?>
											
											<a href="https://cloud-tech-alert.com/register/"> <input type="button" value="Create an Account"  class="create-account-btn" /></a>
											
                                            <div class="or">OR</div>
                                            <div id="magic-link-div">
                                               
                                                <?php echo do_shortcode('[magiclink-login]'); ?></div>
                                            <?php if ($currpage != 'lost-password') { ?>
                                              <!-- <a href="https://cloud-tech-alert.com/register/"> <input type="button" value="Create an Account"  class="create-account-btn" /></a> -->
                                            <?php } ?>
                                        </div>
                                        
                                        <div style="display: flex;margin-bottom: 40px;">
                                            <?php if ($currpage === 'lost-password') { ?>
                                                <div class="back-to-home">
                                                    <a href="<?php echo home_url('sign-in'); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Login</a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="back-to-home">
                                                    <a href="<?php echo home_url(); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back to Home</a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
//                                the_content();
                                ?>
                                <div class="clearfix"></div>
                            </div>
                            <?php
                        endwhile; //end loop
                        comments_template('', true);
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer('nomenu');
