<?php
/* Template Name: Contact Us   */
get_header();
global $content_width;
$content_width = 1068;
$current_user = wp_get_current_user();
?> 
<div id="content" class=" herald-slide">
    <div class="herald-section container herald-no-sid">
        <div class="row">
            <div class="col-lg-12">
                <!-- Body -->
                    <!-- Map Location -->
                    <div class="row">
                        <div class="col-lg-6" style="display:none">
                        <p><b>Our Office:</b> 2 International Drive, Rye Brook, New York 10573, USA</p>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.892310466369!2d-73.69030728511565!3d41.049484024838016!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c297c7c4df953f%3A0xe9d1fbb99ac157ac!2s2%20International%20Dr%2C%20Port%20Chester%2C%20NY%2010573%2C%20USA!5e0!3m2!1sen!2sin!4v1663304466752!5m2!1sen!2sin" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                        <div class="col-lg-12">
                            <h1 class="entry-title h1">Contact Us</h1><hr>
                                <p><b>Working Hours:</b> Monday - Friday: 09:00 - 17:00</p>
                               
                            <p>Your feedback, suggestions, and questions are extremely important to us. </p>
                            <p>You can get in touch with us by filling in the form below and the CloudTech Alert team will get in touch with you at the earliest. </p>
                            <span style="display: none;" id="get_user_email"><?php echo $current_user->user_email; ?></span>
                            <span style="display: none;" id="get_user_name"><?php echo $current_user->user_login; ?></span>
                            <?php echo do_shortcode('[Form id="1"]'); ?>
                        </div>
                    </div>
                <!-- End of Body -->
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
