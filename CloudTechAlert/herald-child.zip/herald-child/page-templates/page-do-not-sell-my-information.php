<?php 
/*
 * Template Name: Do Not Sell My Information Template
 */
get_header(); ?>
<div id="content" class="herald-site-content herald-slide">
    <div class="herald-section container herald-no-sid">
        <div class="row">
            <div class="col-lg-9 col-mod-single col-mod-main">
                <!-- Header -->
                <header class="entry-header">
                    <h1 class="entry-title h1"><?php echo get_the_title(); ?></h1>
                </header>
                <!-- Header End -->
                <!-- body -->
                <div class="herald-entry-content">
                <?php if (have_posts()) {
                                while ( have_posts() ) : the_post();
                                    ?>
                    <?php the_content(); ?>
                    <div class="consumer-requests" id="consumer-requests-2">
                        <h2>Request Removal/Deletion</h2>
                        <p>Want to remove your existing information from our database? Click the button below. Once you click this button, all the information pertaining to you will be removed from our database on immediate notice.</p>
                        <!--<button class="btn btn-primary data-request-btn" data-title="Request Removal/Deletion from <?php echo get_bloginfo( 'name' ); ?>" data-type-value="Request Deletion">Request Deletion</button>-->
                        <a class="btn btn-primary" href="<?php echo site_url('do-not-sell-my-information-request-removal') ?>">Request Deletion</a>
                    </div>
                    <div class="consumer-requests" id="consumer-requests-1">
                        <h2>Request Access to Collected Data</h2>
                        <p>We respect your privacy. Please be informed that the collected data is absolutely safe with us. To learn more about the collected data, please click the link below.  </p>
                        <a class="btn btn-primary" data-title="Request Access to Collected Data" href="<?php echo site_url('do-not-sell-my-information-request-access') ?>">Request Access</a>
                    </div>
                    <div class="consumer-requests" id="consumer-requests-3">
                        <h2>Privacy at <?php echo get_bloginfo( 'name' ); ?></h2>
                        <p>We respect your data. For further details on our privacy policy and terms of service, please click the below links:</p>
                        <a style="font-weight: bold" target="_blank" href="<?php echo site_url('privacy-policy') ?>"><?php echo get_bloginfo( 'name' ); ?>'s Privacy Policy</a><br/>
                        <a style="font-weight: bold" target="_blank" href="<?php echo site_url('terms-of-service') ?>"><?php echo get_bloginfo( 'name' ); ?>'s Terms of Service</a>
                    </div>
                    <?php endwhile;//end loop
                                comments_template('', true);
                            }
                        ?> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer();