jQuery(document).ready(function () {

    jQuery('.post-template-default').find('.a2a_floating_style,.addtoany_share_save_container').hide();

    jQuery(".chosen-select").chosen();

    if (jQuery(".chosen-select").length > 0) {
        jQuery(".chosen-container").css('width', '100%');
    }
//    jQuery(".chosen-select").chosen({disable_search_threshold: 10});
    //ARIA-LABEL for Search Button
    if (jQuery('.tdb-head-search-btn').length > 0) {
        jQuery('.tdb-head-search-btn').attr('aria-label', 'Search Button');
    }

    if (jQuery('.tdb-head-usr-avatar').length > 0) {
        jQuery('.head-subscribe-btn').hide();
    }
//    if(jQuery('.ctis-load-more').length > 0) {
//        jQuery('.ctis-load-more button').append('<i class="td-icon-font td-icon-menu-down"></i>');
//    }
//    
//    jQuery('.ctis-load-more').load(function() {
//        alert('hello');
//        jQuery('.ctis-load-more button').append('<i class="td-icon-font td-icon-menu-down"></i>');
//    });

    if (jQuery('.user-registration-MyAccount-navigation').length > 0) {
        jQuery('.user-registration-MyAccount-navigation-link--user-logout').remove();
    }

    jQuery('#create-acc').click(function () {
        jQuery("#register-block").show();
        //login-block
        jQuery("#login-block").hide();
    });

    jQuery('#go-login').click(function () {
        jQuery("#register-block").hide();
        //login-block
        jQuery("#login-block").show();
    });

    jQuery('#passwordless-login-btn').click(function () {
        jQuery('#passwordless-login-div').show();
        jQuery(this).hide();
    });

    if (jQuery('#landing-page1-modal').length > 0) {
        jQuery(window).scroll(function () {
            if (jQuery(document).height() <= (jQuery(window).height() + jQuery(window).scrollTop())) {
                jQuery('#landing-page1-modal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            }
        });
        jQuery('#get-details-btn').click(function () {
            jQuery('#landing-page1-modal').modal({
                backdrop: 'static',
                keyboard: false
            });
        });
    }

    jQuery('.download-btn').click(function () {
        if (jQuery(window).width() > 979) {
            jQuery('.download-form').show('slow');
        } else {
            jQuery('.mobile-download-form').show('slow');
        }
        jQuery('.download-btn').hide();
    });

    if (jQuery('.thank-you-page').length > 0) {
        if (jQuery(window).width() > 979) {
            jQuery('#subscription-form').show('slow');
        } else {
            jQuery('#mobile-subscription-form').show('slow');
        }
    }
    jQuery(function () {
        if (jQuery(window).width() > 580) {
            setTimeout(function () {
                if (jQuery('#resource-modal').data('popup-displayed') === 'hidden' && !jQuery('#exit-modal').hasClass('show')) {
                    jQuery.ajax({
                        type: "get",
                        dataType: "json",
                        url: td_ajax_url,
                        data: {'action': "save_resource_modal_data"},
                        beforeSend: function () {
                        }, success: function (response) {
                            if (response.msg === 'success') {
                                jQuery('#resource-modal').modal({
                                    //                                backdrop: 'static',
                                    keyboard: false
                                });
                                jQuery('#resource-modal').data('popup-displayed', 'shown');
                            }
                        }, error: function () {
                        }
                    });
                }
            }, 30 * 1000);
        }
    });


    // var timerID = setInterval(function () {
    //     jQuery.ajax({
    //         type: "get",
    //         dataType: "json",
    //         url: td_ajax_url,
    //         data: {'action': "fetch_posts", "shown_posts": JSON.stringify(glob_shown_posts)},
    //         beforeSend: function () {
    //         }, success: function (response) {
    //             if (response.status == 'success' && jQuery(window).width() > 580) {
    //                 toastr.options = {
    //                     "closeButton": true,
    //                     "debug": false,
    //                     "newestOnTop": true,
    //                     "progressBar": true,
    //                     "positionClass": "toast-bottom-left",
    //                     "preventDuplicates": true,
    //                     "onclick": function () {
    //                         window.location.replace(response.data.permalink);
    //                     },
    //                     "showDuration": "300",
    //                     "hideDuration": "1000",
    //                     "timeOut": 10 * 1000,
    //                     "extendedTimeOut": 0,
    //                     "showEasing": "swing",
    //                     "hideEasing": "linear",
    //                     "showMethod": "fadeIn",
    //                     "hideMethod": "fadeOut",
    //                     "tapToDismiss": false,
    //                     "maxOpened": 1,
    //                     "closeOnHover": false,
    //                 };
    //                 toastr["info"](response.data.user_name + ' from ' + response.data.user_state + ' has downloaded "' + response.data.post_title + '" ' + response.data.resource_type);
    //                 glob_shown_posts.push(response.data.id);
    //             }
    //         }, error: function () {
    //         }
    //     });
    // }, 150 * 1000);

    // START -- Increment the blog views by 100
    if (jQuery('.blog-views').length > 0) {
        jQuery(".blog-views").find(".td-fix-index span:last-child").addClass('blog-view_count');
        if (jQuery(".blog-view_count").html() != '') {
            var count = jQuery(".blog-view_count").html();
            jQuery(".blog-view_count").html((parseInt(count) + 100));
        }
    }
    // END -- Increment the blog views by 100

//Home page
//    jQuery('.news_geo_filter li a').each(function (index) {
//        var tooltip = '';//'News from all over the world'
//        if (jQuery(this).html() === 'NA') {
//            tooltip = 'North America';
//        } else if (jQuery(this).html() === 'LATAM') {
//            tooltip = 'Latin America';
//        } else if (jQuery(this).html() === 'EMEA') {
//            tooltip = 'Europe, Middle East, and Africa';
//        } else if (jQuery(this).html() === 'APAC') {
//            tooltip = 'Asia Pacific';
//        }
//        jQuery(this).attr('data-toggle', 'tooltip');
//        jQuery(this).attr('data-placement', 'top');
//        jQuery(this).attr('title', tooltip);
//    });

    if (jQuery(document).find('[data-toggle="tooltip"]').length > 0) {
        jQuery('[data-toggle="tooltip"]').tooltip();
    }
});

//POpup - when user try to close the tab
jQuery("html").bind("mouseleave", function () {
    /* Remove this condition if you want to test the popup as the popup will appear 
     * every time you hover around the browser tab
     */
    if (jQuery(window).width() > 580) {
        setTimeout(function () {
            if (jQuery('#exit-modal').data('popup-displayed') === 'hidden' && !jQuery('#resource-modal').hasClass('show')) {
                jQuery.ajax({
                    type: "get",
                    dataType: "json",
                    url: td_ajax_url,
                    data: {'action': "save_exit_modal_data"},
                    beforeSend: function () {
                    }, success: function (response) {
                        if (response.msg === 'success') {
                            jQuery('#exit-modal').modal({
                                backdrop: 'static',
                                keyboard: false
                            });
                            jQuery('#exit-modal').data('popup-displayed', 'shown');
                        }
                    }, error: function () {
                    }
                });
            }
        }, 50 * 1000);
    }
});
jQuery(document).on("click", ".resources-load-more", function (e) {
    e.preventDefault();
    resource_filter_func(jQuery(this));
});
