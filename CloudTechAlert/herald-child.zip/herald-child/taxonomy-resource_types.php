<?php get_header(); ?>

<div class="herald-section container herald-no-sid " id="herald-section-0">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="herald-module col-lg-12 col-md-12 col-sm-12" id="herald-module-0-0" data-col="12">
                        <!-- header -->
                        <div class="herald-mod-wrap">
                            <div class="herald-mod-head ">
                                <div class="herald-mod-title">
                                <?php  $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); ?>
                                    <h2 class="h6 herald-mod-h herald-color"><?php echo $term->name; ?></h2>
                                </div>
                            </div>
                        </div>
                        <!-- content -->
                        <div class="row herald-posts row-eq-height ">
                            <?php if ( have_posts() ) { ?>
                            <div class="post_loop_1" style="display: inline-block;width: 100%;margin-top: 15px;padding-left: 20px;padding-right: 20px;">
                                <?php while ( have_posts() ): the_post(); 
                                            $post_thumbnail_url = '';

                                            if (get_the_post_thumbnail_url(null, 'medium_large') != false) {
                                                $post_thumbnail_url = get_the_post_thumbnail_url(null, 'medium_large');
                                            } else {
                                                $post_thumbnail_url = get_template_directory_uri() . '/assets/img/resource-default.jpg';
                                            }	
                                ?>
                                    <div class="bit-3 resource-card" style="padding-right: 20px;padding-bottom: 35px;margin-bottom: 15px;">
                                    <div class="td-module-container td-category-pos-above post-box">
                                        <div class="td-image-container123">
                                            <div class="td-module-thumb">
                                                <a href="<?php echo get_the_permalink(); ?>" rel="bookmark" class="td-image-wrap " title="<?php echo the_title_attribute(); ?>">
                                                    <img src="<?php echo esc_url($post_thumbnail_url); ?>" alt="<?php echo the_title_attribute(); ?>" class="img-responsive"></a>
                                            </div>
                                        </div>
                                        <div class="td-module-meta-info123 content-box" style="height: 220px;">
                                            <div class="custom-tax-box">
                                                <a href="<?php echo $term->id; ?>" class="resource-category td-post-category"><?php echo $term->name; ?></a>
                                               <?php  $sponsored_by = get_the_terms($post->ID, 'sponsored_by');
								                        foreach ($sponsored_by as $sponsored_by_single) { ?>
                								<a class="client-name" href="<?php echo get_term_link($sponsored_by_single->term_id); ?>"><?php echo $sponsored_by_single->name; ?></a>	
								                <?php } ?>  
                                            </div>
                                            <h6 class="entry-title td-module-title">
                                                <a href="<?php echo get_the_permalink(); ?>" rel="bookmark" title="<?php echo the_title_attribute(); ?>"><?php echo get_the_title(); ?></a>
                                            </h6>
                                            <a class="readMore" href="<?php echo get_the_permalink(); ?>" rel="bookmark" title="<?php echo the_title_attribute(); ?>">Download</a>
                                        </div>
                                    </div>
                                </div>

                                <?php endwhile; ?>
                            </div>
                        <?php }?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
</div>

<?php
get_footer();
