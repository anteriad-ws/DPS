<?php
/**
 * The single post loop Default template
 **/


if (have_posts()) {
    the_post(); ?>
    <?php global $herald_sidebar_opts; ?>

<?php if($herald_sidebar_opts['use_sidebar'] == 'left'): ?>
    <?php get_sidebar(); ?>
<?php endif; ?>
			
<div class="col-lg-9 col-md-9 col-mod-single col-mod-main">
	<!-- title start -->
	<header class="entry-header herald-clear-blur" style="text-align:left;">
			<h1 class="entry-title h1"> <?php the_title() ?></h1>	
			<div class="entry-meta entry-meta-single">
				<!-- date & time -->
				<div class="meta-item herald-date">
					<i class="fa fa-clock-o" aria-hidden="true"></i> <time class="entry-date updated td-module-date" 
						datetime="<?php echo esc_html(date(DATE_W3C, get_the_time('U'))) ?>">
							<?php echo  the_time( 'j F Y, g:i a' ); ?>
					</time>
				</div>

				<!-- no. of views -->
				<div class="meta-item herald-views"><?php
						$info =	get_post_meta(get_the_ID(), 'views');
						echo $info[0];
					?>
				</div>
			</div>
	</header>
	<div class="herald-ovrld herald-ovrld-3">
		<div class="herald-post-thumbnail herald-post-thumbnail-single" style="background: #d5d5d5 !important;text-align: center;">
			<!-- <span> -->
			<img src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'full')) ?>" 		
				class="attachment-herald-lay-single-full size-herald-lay-single-full wp-post-image single-news-image" 
				alt="<?php the_title() ?>" loading="lazy">
			<!-- </span> -->
		</div>
		

                       
	</div>
	<div style="margin-bottom: 15px;

font-style: italic;

color: #aaa;float:right;margin-top:-20px;font-size:12px;color:#0000ff85"><?php

echo do_shortcode('[image_courtesy_shortcode]') ?></div>
	<!-- title end -->

		<div class="">
			<?php //get_template_part('template-parts/single/meta');	?>

			<div class="<?php //echo esc_attr(herald_single_content_class()); ?>">
				<?php get_template_part('template-parts/single/content'); ?>
				<hr>
                <!-- News Source -->
                <?php if(get_post_type( get_the_ID()) == 'news') { ?>
                    <span class="td-post-date td-post-source" style="margin-top: 5px;">
                        <strong>News Source: </strong>
                        <a href="<?php echo (get_post_meta($post->ID, '_source_url', true) != '') ? get_post_meta($post->ID, '_source_url', true) : home_url(); ?>" target="_blank">
                            <?php echo (get_post_meta($post->ID, '_source_name', true) != '') ? get_post_meta($post->ID, '_source_name', true) : 'source'; ?>
                        </a>
                    </span>
                <?php }?>
                <!-- News Source End-->
			</div>


		</div>

</div>

<?php if( $herald_sidebar_opts['use_sidebar'] == 'right' ): ?>
	<?php get_sidebar(); ?>
<?php endif; ?>
<?php } ?>