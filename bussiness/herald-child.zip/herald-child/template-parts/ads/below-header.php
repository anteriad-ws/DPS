<?php if( herald_can_display_ads() && $ad = herald_get_option('ad_below_header') ): ?>
	<div class="herald-da herald-slide herald-below-header"><?php echo do_shortcode( $ad ); ?></div>
<?php endif; ?>
<?php if( function_exists('tradingview_stock_ticker_shortcode') ){ ?>
<?php echo do_shortcode("[tradingview_stock_ticker]"); ?>
<?php } ?>
