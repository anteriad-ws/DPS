<!DOCTYPE html>
<html class="js no-touchevents" lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link href="<?php echo trailingslashit(get_stylesheet_directory_uri()); ?>/landing-pages/assets/styles.css" rel="stylesheet" type="text/css">
	<style>
		/*
		html.vc_desktop{
			margin-top: 0px !important;
		}
		#wpadminbar{
			display:none;
		}
		*/
		body{
			overflow-x:hidden;
		}
		body.resources-template{
			color: #33475b;
			font-family: "AvenirNext","Helvetica Neue",Helvetica,Arial,sans-serif;
		}
		body h1, body h2, body h3, body h4, body h5, body h6, body .h1, body .h2, body .h3, body .h4, body .h5, body .h6, body .h7, body .wp-block-cover .wp-block-cover-image-text, body .wp-block-cover .wp-block-cover-text, body .wp-block-cover h2, body .wp-block-cover-image .wp-block-cover-image-text, body .wp-block-cover-image .wp-block-cover-text, body .wp-block-cover-image h2{
			font-family: "AvenirNext","Helvetica Neue",Helvetica,Arial,sans-serif;
		}
		.checkmarked-list ul li{
			background: url(/wp-content/themes/herald-child/landing-pages/assets/checkmark.svg) no-repeat left top;
			padding-left: 48px;
			margin: 1rem 0;
			color:#33475b;
			font-size:18px;
			font-weight:400px;
		}
		.light-text{
			font-weight:400;
		}
		.letter-space{
			letter-spacing: 1px;
		}
		.font-weight-900{
			font-weight:900;
		}
		.font-weight-800{
			font-weight:800;
		}
		.font-weight-700{
			font-weight:700;
		}
		.font-weight-600{
			font-weight:600;
		}
		.font-weight-500{
			font-weight:500;
		}
		.font-weight-400{
			font-weight:400;
		}
		.font-weight-300{
			font-weight:300;
		}
		.font-size-18{
			font-size:18px;
		}
		.shadow-box{
			box-shadow: 0 0 13px rgb(0 0 0 / 50%);
		}
		body .fm-form .wdform-label{
			font-weight:500;
		}
		body .fm-form-container.fm-theme1 .fm-form input[type="text"], body .fm-form-container.fm-theme1 .fm-form .ui-corner-all, body .fm-form-container.fm-theme1 .fm-form input[type="number"], body .fm-form-container.fm-theme1 .fm-form input[type=password], body .fm-form-container.fm-theme1 .fm-form input[type=url], body .fm-form-container.fm-theme1 .fm-form input[type=email], body .fm-form-container.fm-theme1 .fm-form textarea, body .fm-form-container.fm-theme1 .fm-form .StripeElement, body .fm-form-container.fm-theme1 .fm-form .ui-spinner-input, body .fm-form-container.fm-theme1 .fm-form .file-upload-status, body .fm-form-container.fm-theme1 .fm-form .country-name, body .fm-form-container.fm-theme1 .fm-form select{
			border-radius:3px !important;
		}
		.fm-form .wd-width-100:focus {
			border-color: rgba(0,208,228,.5);
			box-shadow: 0 0 4px 1px rgb(0 208 228 / 30%), 0 0 0 1px #00d0e4;
			outline: 0;
		}
		body .fm-form-container.fm-theme1 .fm-form button.button-submit:hover {
			background-color: #ff8f73;
			border-color: #ff8f73;
			color: #fff;
		}
		body .fm-form-container.fm-theme1 .fm-form button.button-submit {
			margin-right:0px;
			background-color: #ff7a59;
			border-color: #ff7a59;
			color: #fff;
			font-size: 14px;
			line-height: 16px;
			padding: 11px 24px;
			font-family: Avenir Next W02,Helvetica,Arial,sans-serif;
			font-weight: 500;
			border-radius: 3px;
			border-style: solid;
			border-width: 1px;
			-webkit-font-smoothing: auto;
			-moz-osx-font-smoothing: auto;
			text-align: center;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			transition: all .15s ease-out;
			display: inline-block;
			width: 100%;
			overflow: hidden;
			text-overflow: ellipsis;
			vertical-align: middle;
			white-space: nowrap;
			margin-top:20px;
		}
		body .fm-form-container, body .fm-form-container.fm-theme1{
			width:100%;
		}
		body .wpb_gallery .wpb_flexslider .flex-control-nav{
			margin-top:60px;
		}
		body .wpb_gallery .wpb_flexslider .flex-control-paging li a{
			width:16px;
			height:16px;
		}
		body .wpb_gallery .wpb_flexslider .flex-direction-nav a:hover {
			box-shadow: 1px 8px 24px 0 rgb(0 0 0 / 20%);
		}
		body .wpb_gallery .wpb_flexslider .flex-direction-nav a{
			opacity:1 !Important;
			width: 40px;
			height: 40px;
			display: flex;
			border: 0 solid #fff;
			background-color: #fff;
			border-radius: 50%;
			box-shadow: 0 0 4px 0 rgb(0 0 0 / 20%);
			transition: 0.3s ease-in-out;
			align-items: center;
			justify-content: center;
			padding: .5rem;
			pointer-events: auto;
			cursor: pointer;
			color:#ffffff;
		}
		body .wpb_gallery .wpb_flexslider .flex-direction-nav a:before,
		body .wpb_gallery .wpb_flexslider .flex-direction-nav a:after{
			font-size: 20px;
			margin-bottom: 100px;
			color:#3E5E74;
			top:11px;
			position:absolute;
		}
		body .wpb_gallery .wpb_flexslider .flex-control-paging li a.flex-active{
			border: 2px solid #00a4bd;
			background:#00a4bd;
		}
		body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_content{
			margin-left:42px;
		}
		body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_content h4{
			font-size: 18px;
			line-height: 26px;
			font-weight: 700;
			padding: 15px 0px;
		}
		body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_content p{
			font-size: 17.7px;
			line-height: 26px;
			font-weight: 400;
		}
		body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_content a{
			color: #0091ae;
			font-weight: 600;
		}
		body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_content a:hover{
			color: #007a8c;
			text-decoration: underline;
		}
		body .wpb_gallery .wpb_flexslider .flex-control-paging li a{
			border: 2px solid #00a4bd;
			background:#ffffff;
		}
		body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_icon::after, body .vc_toggle_color_sky.vc_toggle_arrow .vc_toggle_icon::before{
			border-color:#00a4bd;
		}
		body .vc_toggle_size_lg.vc_toggle_arrow .vc_toggle_icon::after, body .vc_toggle_size_lg.vc_toggle_arrow .vc_toggle_icon::before{
			margin-left:-20px;
		}
		body .vc_toggle_size_lg.vc_toggle_arrow .vc_toggle_icon::after, body .vc_toggle_size_lg.vc_toggle_arrow .vc_toggle_icon::before{
			border-width: 3px;
			height: 11px;
			width: 11px;
		}
		.faq-row .vc_toggle_title h4{
			font-size: 18px;
			line-height: 22.4px;
			font-weight: 700;
		}
		body .vc_toggle_size_lg.vc_toggle_arrow .vc_toggle_icon::before{
			margin-top:0px;
		}
		body .vc_toggle_arrow.vc_toggle_active .vc_toggle_icon::after, body .vc_toggle_arrow.vc_toggle_active .vc_toggle_icon::before{
			-webkit-transform: rotate(90deg) translateX(-30%);
			transform: rotate(90deg) translateX(-30%);
		}
		body .vc_toggle_arrow .vc_toggle_icon::after, body .vc_toggle_arrow .vc_toggle_icon::before {
			content: '';
			display: block;
			left: 50%;
			position: absolute;
			top: 50%;
			-webkit-box-sizing: border-box;
			-moz-box-sizing: border-box;
			box-sizing: border-box;
			-webkit-transform: rotate(0) translateY(-50%);
			transform: rotate(0) translateY(-50%);
			transition: -webkit-transform 0.15s ease-in-out;
			transition: transform 0.15s ease-in-out;
			transition: transform 0.15s ease-in-out, -webkit-transform 0.15s ease-in-out;
			border:none;
			background:url('/wp-content/themes/herald-child/landing-pages/assets/rightArrow-nav.svg') !Important;
			width:24px !important;
			height:24px !important;
			background-repeat:no-repeat !important;
			background-size:contain !important;
			background-position:center !important;
		}
		.footer-container.container-fluid{
			padding-left:0px;
			padding-right:0px;
		}
		.virality-cta {
			margin: 0;
			padding: 1rem 0 0;
			background-color: #33475b;
		}
		.virality-cta__wrapper {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			position: relative;
			top: 20px;
			height: auto;
			width: 75%;
			margin: 0 auto;
			padding: 0.5rem 0;
			border-radius: .1875rem;
			background-color: #fff;
		}
		#hsg-footer--lp .hsg-footer__layout{
			padding-top:30px;
		}
		.virality-cta__text {
			padding: 0 0.5rem;
			font-size: 14px;
			font-weight: 600;
			line-height: 1;
			text-align: center;
			color: #425b76;
			margin:1em 0em;
		}
		.virality-cta__logo {
			margin: 0;
			margin-left:10px;
		}
		@media (min-width: 1300px){
			body .wpb_gallery .wpb_flexslider .flex-direction-nav .flex-prev {
				left: -100px !Important;
			}
			body .wpb_gallery .wpb_flexslider .flex-direction-nav .flex-next {
				right :-100px !Important;
			}
		}
		@media (min-width: 501px){
			.virality-cta__text {
				padding: 0;
			}
			.virality-cta__logo {
				height: 25px;
				margin-right: 8px;
			}
			.virality-cta__wrapper {
				flex-direction: row;
				height: 40px;
				width: 453px;
			}
		}
		div#hsg-modals-wrapper {
			display: none;
		}
		.main-logo{
			max-width:300px;
			margin:0 auto;
		}
		.has-partner-logo .main-logo,
		.has-partner-logo .partner-logo{
			max-width:200px;
		}
		.has-partner-logo .main-logo{
			padding-right:20px;
		}
		.has-partner-logo .partner-logo{
			padding-left:20px;
		}
		.gradiant3{
			background-image: linear-gradient( 45deg,#6a78d1,#00a4bd);
			min-height:40px;
			padding: 40px 0px 100px;
			position: relative;
		}
		#menu-landing-page-2-header-menu li{
			float:left;
			padding:10px 30px;
			margin-bottom:0px;
		}
		#menu-landing-page-2-header-menu li a{
			color:#33475b;
			font-weight:600;
		}
		.primary-navigation{
			float:right;
		}
		.gradiant3 .breadcrumbs a,
		.gradiant3 .breadcrumbs span{
			color:#ffffff;
		}
		.gradiant3 .breadcrumbs span i{			
			margin: 0px 8px;
		}
		@media (min-width: 1200px){
			body .container {
				width: 1080px;
			}
		}
	</style>
	<?php wp_head(); ?></head>

<body <?php body_class(); ?>>
	<?php
	$has_partner_logo = '';
	$partner_logo = get_post_meta(get_the_ID(), 'partner_logo', true);
	if(!empty($partner_logo)){
		$has_partner_logo = 'has-partner-logo';
	}
	$partner_link = get_post_meta(get_the_ID(), 'partner_link', true);
	$partner_link_open = $partner_link_close = '';
	if(!empty($partner_link)){
		$partner_link_open = "<a href='$partner_link' target='_blank'>";
		$partner_link_close = "</a>";
	}
	?>
	
	<div class="header-container container">
		<div class="row" <?php echo $has_partner_logo; ?>" data-background="white">
			<div class="row" style="padding:20px 0px;">
				<div class="col-md-4">
					<a href='/'><img src="/Assets/logo.png" alt="Logo" class="main-logo"></a>
					<?php
					if(!empty($partner_logo)){
						echo "$partner_link_open<img src='$partner_logo' alt='Partner Logo' class='partner-logo' style='border-left: 2px solid #cbd6e2;'>$partner_link_close";
					}
					?>
				</div>
				<div class="col-md-8">
					<nav class="primary-navigation">
					<?php
						wp_nav_menu( array(
							'theme_location'  => 'header_HSlandingPage_2',
						) );
					?>
					</nav>
				</div>
			</div><!--end row-wrapper -->
		</div><!--end header -->
	</div><!--end row -->
	<div class="gradiant3">
		<div class="breadcrumbs-container container">
			<div class="row">
				<div class="col-12">
					<div class=" breadcrumbs">
						<?php
							if ( function_exists('yoast_breadcrumb') ) {
								//yoast_breadcrumb( '<p id="breadcrumbs" class="breadcrumbs">','</p>' );
								if( isset($args['breadcrumb']) && !empty($args['breadcrumb']) ){
									echo $args['breadcrumb'];
								}else{
									echo do_shortcode('[wpseo_breadcrumb]');
								}
							}
						?>
					</div>
				</div>
			</div>
		</div>