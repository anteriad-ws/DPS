<!--<title> Resources |  Delta Punch </title>-->

<?php get_header(); ?>

	<div class="body-container-resource">
	
		<?php get_template_part('loop-resources'); ?>

	</div>
                       
<?php
get_footer();
