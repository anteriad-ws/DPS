<?php
add_shortcode( 'dp-posts', 'ti_display_posts' );
function ti_display_posts( $atts ) {
    $atts = shortcode_atts( array(
        'post_type' => 'post',
        'count' => '4',
        'style' => 'one-large',
        'cat' => 'business',
        'author' => 'no'
    ), $atts, 'dp-posts' );
 
	$cat_name = $atts['cat'];
	$category_id = get_cat_ID( $cat_name );
    $category_link = get_category_link( $category_id );
	
	$args_ = array(
				'post_type'     => $atts['post_type'], //your post type
				'post_status' 	=> 'publish',
				'posts_per_page' => $atts['count'],
				'orderby'       => 'ID',
				'order'         => 'DESC',
				'cat' => $category_id
			);
	$args_loop = new WP_Query( $args_ );
	$html = '';
	if ( $args_loop->have_posts() ) :
	
		$html .='<div class="section-title">
					<h1><span><a href="'.$category_link.'">'.$cat_name.$post_count.'</a></span></h1>
				</div><style>.gallery-turner{ display: none; }</style>';
		$i = 1;
		
		while ( $args_loop->have_posts() ) : $args_loop->the_post();
		
			if( $atts['style'] == 'one-large'){
				if($i==1){
					$html .= '<div class="tr-post">
								<div class="entry-header">
									<div class="entry-thumbnail">
										<a href="'.get_the_permalink().'"><img class="img-fluid" src="'.get_the_post_thumbnail_url().'" alt="Image"></a>
									</div>
								</div>
								<div class="post-content">';
									$posted_by = '';
									if( $atts['author'] == 'yes' ){
										if($avatar = get_avatar(get_the_author_meta('ID')) !== FALSE){
										$html .= '
										<div class="author">
											<a href="'.get_author_posts_url( get_the_author_meta('ID') ).'">
												 '.get_avatar( get_the_author_meta('ID'), 32, '', 'alt', array('class' => 'img-fluid img-circle') ).'
											</a>
										</div>';
										}
										
										$author = get_user_by( 'id', get_the_author_meta('ID') );
										
										$posted_by = '<li>By <a href="'.get_author_posts_url( get_the_author_meta('ID') ).'"> '.get_the_name( get_the_author_meta('ID') ).'</a></li>';
										
									}
									
									$html .= '
									<div class="entry-meta">
										<ul>
											'.$posted_by.'
											<li><a> '.time_elapsed_string( get_the_date() ).'</a></li>
											<li class="pull-right">
												<ul>
													<li>Share</li>
													<li>
														<a href="https://www.facebook.com/sharer/sharer.php?u='.urlencode(get_the_permalink( get_the_ID() )).'&t'.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;"
														   target="_blank" title="Share on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i>
														</a>
													<li>
														<a href="https://twitter.com/share?url='.urlencode(get_the_permalink( get_the_ID() )).'&text='.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;"
														   target="_blank" title="Share on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i>
														</a>
													</li>
													<li>
														<a href="https://linkedin.com/sharing/share-offsite/?url='.urlencode(get_the_permalink( get_the_ID() )).'&text='.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;" target="_blank" title="Share on LinkedIn"><i class="fa fa-linkedin" aria-hidden="true"></i>
														</a>
													</li>
												</ul>
											</li>
										</ul>
									</div>
									<h2 class="entry-title">
										<a href="'.get_the_permalink().'">'.get_the_title().'</a>
									</h2>
								</div>
							</div>';
				}else{
					
					if($i%2==0){
						
						$html .='<div class="row row-eq-height iValue'.$i.'">';
						
					}
					if (has_post_thumbnail( get_the_ID() ) ){
						$image_url = get_the_post_thumbnail_url(get_the_ID(),'two-small');
					}else{
						$image_url =  get_template_directory_uri().'/assets/images/placeholder-320x218.jpg';
					}
					$html .= '
						<div class="col-xl-6 offset-xl-0 col-lg-8 offset-lg-2 col-md-8 offset-md-2 col-sm-8 offset-sm-2">
							<div class="tr-post medium-post">
								<div id="carousel-'.$i.'" class="carousel slide" data-ride="carousel">
									<div class="carousel-inner" role="listbox">
										<div class="item carousel-item active">
											<div class="entry-header">
												<div class="entry-thumbnail">
													<a href="'.get_the_permalink().'"><img class="img-fluid" src="'.$image_url.'" alt="Image"></a>
												</div>
											</div>
										</div>';
										
										$meta_keys = array('second_featured_image','third_featured_image');
										$image_meta_val = '';
										foreach($meta_keys as $meta_key){
											$image_meta_val = get_post_meta( get_the_ID(), $meta_key, true);
											if(!empty($image_meta_val)){
												$html .= '
												<div class="item carousel-item">
													<div class="entry-header">
														<div class="entry-thumbnail">
															<a href="'.get_the_permalink().'">';
															$html .= wp_get_attachment_image( $image_meta_val, "two-small", "", array( "class" => "img-fluid" ) );
															$html .= '
															</a>
														</div>
													</div>
												</div>
												<style>
													body .galary-turner-'.$i.'{
														display:block !Important;
													}
												</style>';
											}
										}
														
									$html .='</div>';
									
									$html .='
									<div class="gallery-turner galary-turner-'.$i.'">
										<a class="left-photo" href="#carousel-'.$i.'" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
										<a class="right-photo" href="#carousel-'.$i.'" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
									</div>';
								$html .= '
								</div>
								<div class="post-content">
									';
									$posted_by = '';
									if( $atts['author'] == 'yes' ){
										if($avatar = get_avatar(get_the_author_meta('ID')) !== FALSE){
										$html .= '
										<div class="author">
											<a href="'.get_author_posts_url( get_the_author_meta('ID') ).'">
												 '.get_avatar( get_the_author_meta('ID'), 32, '', 'alt', array('class' => 'img-fluid img-circle') ).'
											</a>
										</div>';
										}
										
										$posted_by = '<li>By <a href="'.get_author_posts_url( get_the_author_meta('ID') ).'"> '.get_the_name( get_the_author_meta('ID') ).'</a></li>';
									}									
									
									$html .='
									<div class="entry-meta">
										<ul>
											'.$posted_by.'
											<li><a> '.time_elapsed_string( get_the_date() ).'</a></li>
											<li class="pull-right">
												<ul>
													<li>
														<a href="https://www.facebook.com/sharer/sharer.php?u='.urlencode(get_the_permalink( get_the_ID() )).'&t'.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;"
														   target="_blank" title="Share on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i>
														</a>
													<li>
														<a href="https://twitter.com/share?url='.urlencode(get_the_permalink( get_the_ID() )).'&text='.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;"
														   target="_blank" title="Share on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i>
														</a>
													</li>
													<li>
														<a href="https://linkedin.com/sharing/share-offsite/?url='.urlencode(get_the_permalink( get_the_ID() )).'&text='.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;" target="_blank" title="Share on LinkedIn"><i class="fa fa-linkedin" aria-hidden="true"></i>
														</a>
													</li>
												</ul>
											</li>
										</ul>
									</div>
									<h2 class="entry-title">
										<a href="'.get_the_permalink().'">'.get_the_title().'</a>
									</h2>
								</div>
							</div>
						</div>
					';
					
					
					if( $args_loop->post_count == $i ){
			
						$html .='</div>';
						
					}else{
						
						if(($i-1)%2==0){
						
							$html .='</div>';
							
						}
						
					}
				}
			
			}else if( $atts['style'] == 'two-small' ){
			
				if(($i-1)%2==0){
						
						$html .='<div class="row row-eq-height">';
						
					}
					$image_url = get_the_post_thumbnail_url(get_the_ID(),'two-small');
					$html .= '
						<div class="col-xl-6 offset-xl-0 col-lg-8 offset-lg-2 col-md-8 offset-md-2 col-sm-8 offset-sm-2">
							<div class="tr-post medium-post">
								<div class="entry-header">
									<div class="entry-thumbnail">
										<a href="'.get_the_permalink().'"><img class="img-fluid" src="'.$image_url.'" alt="Image"></a>
									</div>
								</div>
								';
								$html .= '
								<div class="post-content">';
									$posted_by = '';
									if( $atts['author'] == 'yes' ){
										if($avatar = get_avatar(get_the_author_meta('ID')) !== FALSE){
										$html .= '
										<div class="author">
											<a href="'.get_author_posts_url( get_the_author_meta('ID') ).'">
												 '.get_avatar( get_the_author_meta('ID'), 32, '', 'alt', array('class' => 'img-fluid img-circle') ).'
											</a>
										</div>';
										}
										
										$posted_by = '<li>By <a href="'.get_author_posts_url( get_the_author_meta('ID') ).'"> '.get_the_name( get_the_author_meta('ID') ).'</a></li>';
									}
									
									$html .='
									<div class="entry-meta">
										<ul>
											'.$posted_by.'
											<li><a> '.time_elapsed_string( get_the_date() ).'</a></li>
											<li class="pull-right">
												<ul>
													<li>
														<a href="https://www.facebook.com/sharer/sharer.php?u='.urlencode(get_the_permalink( get_the_ID() )).'&t'.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;"
														   target="_blank" title="Share on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i>
														</a>
													<li>
														<a href="https://twitter.com/share?url='.urlencode(get_the_permalink( get_the_ID() )).'&text='.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;"
														   target="_blank" title="Share on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i>
														</a>
													</li>
													<li>
														<a href="https://linkedin.com/sharing/share-offsite/?url='.urlencode(get_the_permalink( get_the_ID() )).'&text='.urlencode(get_the_title()).'" onclick="javascript:window.open(this.href, \' \', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;" target="_blank" title="Share on LinkedIn"><i class="fa fa-linkedin" aria-hidden="true"></i>
														</a>
													</li>
												</ul>
											</li>
										</ul>
									</div>
									<h2 class="entry-title">
										<a href="'.get_the_permalink().'">'.get_the_title().'</a>
									</h2>
								</div>
							</div>
						</div>
					';
					
					if( $args_loop->post_count == $i ){
			
						$html .='</div>';
						
					}else{
						
						if($i%2==0){
							
							$html .='</div>';
							
						}
					
					}
					
			}
			
			$i++;
			
		endwhile;
		
	endif;
	
    return $html;

}



add_shortcode( 'dp-sports', 'ti_display_sports_feed' );
function ti_display_sports_feed( $atts ) {
    $atts = shortcode_atts( array(
        'post_type' => 'sports',
        'count' => '3',
        'style' => 'one-large'
    ), $atts, 'dp-sports' );
	
	$args_2 = array(
				'post_status' 	=> 'publish',
				'posts_per_page' => $atts['count'],
				'orderby'       => 'ID',
				'order'         => 'DESC'
			);
	$args_loop2 = new WP_Query( $args_2 );
	
	$html = '';
	
	$html .='<div class="section-title">
				<h1><span><a href="/sports/">Sports</a></span></h1>
			</div>';
			
	$html .= '
			<div class="latest-result text-center">
			<div class="latest-result-content">
			<div class="row">
			<div class="col-md-4">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/logo1.png" alt="Image">
			<h2 class="score">278/10</h2>
			<span class="over">Over: 19.5</span>
			<ul>
			<li>Mehedi Hasan 103*</li>
			<li>Shakib Al Hasan 73</li>
			</ul>
			</div>
			<div class="col-md-4">
			<div class="match-category">
			<div class="category-logo">
			<a href="https://demo.themeregion.com/newshub/#"><img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/logo2.png" alt="Image"></a>
			</div>
			<p>2nd One Day Match <span>BNS Ground</span></p>
			</div>
			</div>
			<div class="col-md-4">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/logo3.png" alt="Image">
			<h2 class="score">32/0</h2>
			<span class="over">Over: 6.2</span>
			<ul>
			<li>Moeen Ali 12*</li>
			<li>Joe Root 20*</li>
			</ul>
			</div>
			</div>
			</div>
			</div>
			<div class="football-result">
			<div class="row">
			<div class="col-md-6">
			<div class="tr-post medium-post">
			<div class="featured-result">
			<h2 class="league-name">Premier League</h2>
			<div class="row">
			<div class="col-4">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/logo4.png" alt="">
			<span class="match-result">3</span>
			</div>
			<div class="col-4">
			<span class="verses">VS</span>
			<span class="match-time">90:00</span>
			</div>
			<div class="col-4">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/logo5.png" alt="">
			<span class="match-result">0</span>
			</div>
			</div>
			</div>
			<div class="post-content">
			<div class="entry-meta">
			<ul>
			<li>163 Share /<a href="https://demo.themeregion.com/newshub/#"> 7 Hour ago</a></li>
			<li>
			<ul>
			<li><a href="https://demo.themeregion.com/newshub/#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
			<li><a href="https://demo.themeregion.com/newshub/#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			<li><a href="https://demo.themeregion.com/newshub/#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
			<li><a href="https://demo.themeregion.com/newshub/#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
			</ul>
			</li>
			</ul>
			</div>
			<h2 class="entry-title">
			<a href="https://demo.themeregion.com/newshub/#">Our closest relatives aren\'t fans of daylight saving time</a>
			</h2>
			</div>
			</div>
			</div>
			<div class="col-md-6">
			<div class="tr-section">
			<div class="league-result text-center">
			<h2>Todays Match</h2>
			<ul>
			<li>
			<ul>
			<li>
			<div class="pull-left">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team2.png" alt="">
			<span class="team-name">Bra</span>
			</div>
			</li>
			<li>
			<span class="match-result">3-2</span>
			</li>
			<li>
			<div class="pull-right">
			<span class="team-name">Arg</span>
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team1.png" alt="">
			</div>
			</li>
			</ul>
			</li>
			<li>
			<ul>
			<li>
			<div class="pull-left">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team1.png" alt="">
			<span class="team-name">Arg</span>
			</div>
			</li>
			<li>
			<span class="match-result">7-4</span>
			</li>
			<li>
			<div class="pull-right">
			<span class="team-name">Bra</span>
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team2.png" alt="">
			</div>
			</li>
			</ul>
			 </li>
			<li>
			<ul>
			<li>
			<div class="pull-left">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team2.png" alt="">
			<span class="team-name">Bra</span>
			</div>
			</li>
			<li>
			<span class="match-result">1-2</span>
			</li>
			<li>
			<div class="pull-right">
			<span class="team-name">Arg</span>
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team1.png" alt="">
			</div>
			</li>
			</ul>
			</li>
			<li>
			<ul>
			<li>
			<div class="pull-left">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team1.png" alt="">
			<span class="team-name">Ara</span>
			</div>
			</li>
			<li>
			<span class="match-result">3-1</span>
			</li>
			<li>
			<div class="pull-right">
			<span class="team-name">Brg</span>
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team2.png" alt="">
			</div>
			</li>
			</ul>
			</li>
			<li>
			<ul>
			<li>
			<div class="pull-left">
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team2.png" alt="">
			<span class="team-name">Bra</span>
			</div>
			</li>
			<li>
			<span class="match-result">6-2</span>
			</li>
			<li>
			<div class="pull-right">
			<span class="team-name">Arg</span>
			<img class="img-fluid" src="'.get_template_directory_uri().'/assets/images/team1.png" alt="">
			</div>
			</li>
			</ul>
			</li>
			</ul>
			</div>
			</div>
			</div>
			</div>
			</div>';
			
	return $html;
	
	/* 		
	if ( $args_loop2->have_posts() ) :
		
		$i = 1;
		
		while ( $args_loop2->have_posts() ) : $args_loop2->the_post();
		
		endwhile;
		
	endif;
	 */
}
?>