<?php

function update_suppression_group_func($data = array()) {
    $group_id = $_POST['group_id'];
    $curr_user = wp_get_current_user();
    $recipient_emails = array(
        "recipient_emails" => array(
            $curr_user->data->user_email,
    ));

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.sendgrid.com/v3/asm/groups/$group_id/suppressions",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($recipient_emails),
        CURLOPT_HTTPHEADER => array(
            "authorization: Bearer " . sendgridController::SG_API_KEY,
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    $msg = array();
    if ($err) {
        $msg = array(
            'status' => 'error',
            'message' => "cURL Error #:" . $err,
        );
    } else {
        $msg = array(
            'status' => 'success',
        );
    }

    return json_encode($msg);
}
add_action('wp_ajax_update_suppression_group_func', 'update_suppression_group_func');
add_action('wp_ajax_nopriv_update_suppression_group_func', 'update_suppression_group_func');



function remove_receipient_func($data = array()) {
    $group_id = $_POST['group_id'];
    $curr_user = wp_get_current_user();
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.sendgrid.com/v3/asm/groups/$group_id/suppressions/" . $curr_user->data->user_email,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "DELETE",
        CURLOPT_POSTFIELDS => "null",
        CURLOPT_HTTPHEADER => array(
            "authorization: Bearer " . sendgridController::SG_API_KEY,
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    $msg = array();
    if ($err) {
        $msg = array(
            'status' => 'error',
            'message' => "cURL Error #:" . $err,
        );
    } else {
        $msg = array(
            'status' => 'success',
        );
    }

    echo json_encode($msg);	
    exit(0);
}
add_action('wp_ajax_remove_receipient_func', 'remove_receipient_func');
add_action('wp_ajax_nopriv_remove_receipient_func', 'remove_receipient_func');

function subscribe_to_all($data = array()) {
    $group_id = $_POST['group_id'];
    $curr_user = wp_get_current_user();

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.sendgrid.com/v3/asm/suppressions/global/" . $curr_user->data->user_email,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "DELETE",
        CURLOPT_POSTFIELDS => "null",
        CURLOPT_HTTPHEADER => array(
            "authorization: Bearer " . sendgridController::SG_API_KEY,
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    $user_groups = sendgridController::get_supression_group();
    $user_groups = json_decode($user_groups['response']);
    $groups = $user_groups->suppressions;

    foreach ($groups as $user_group) {

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.sendgrid.com/v3/asm/groups/{$user_group->id}/suppressions/" . $curr_user->data->user_email,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "DELETE",
            CURLOPT_POSTFIELDS => "null",
            CURLOPT_HTTPHEADER => array(
                "authorization: Bearer " . sendgridController::SG_API_KEY,
                "content-type: application/json"
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
    }

    $msg = array();
    if ($err) {
        $msg = array(
            'status' => 'error',
            'message' => "cURL Error #:" . $err,
        );
    } else {
        $msg = array(
            'status' => 'success',
        );
    }

    echo json_encode($msg);
    exit(0);
}
add_action('wp_ajax_subscribe_to_all', 'subscribe_to_all');
add_action('wp_ajax_nopriv_subscribe_to_all', 'subscribe_to_all');

function unsubscribe_from_all($data = array()) {
    $group_id = $_POST['group_id'];
    $curr_user = wp_get_current_user();



    $user_groups = sendgridController::get_supression_group();
    $user_groups = json_decode($user_groups['response']);
    $groups = $user_groups->suppressions;	

    foreach ($groups as $user_group) {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.sendgrid.com/v3/asm/groups/{$user_group->id}/suppressions",
			CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_POSTFIELDS => json_encode(array(
				'recipient_emails' => array(
					$curr_user->data->user_email
				)
			)),
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_HTTPHEADER => array(
                "authorization: Bearer " . sendgridController::SG_API_KEY,
                "content-type: application/json"
            ),
        ));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
    }

    /*

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.sendgrid.com/v3/asm/suppressions/global",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode(array(
            'recipient_emails' => array(
                $curr_user->data->user_email
            )
        )),
        CURLOPT_HTTPHEADER => array(
            "authorization: Bearer " . sendgridController::SG_API_KEY,
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl); */

    $msg = array();
    if ($err) {
        $msg = array(
            'status' => 'error',
            'message' => "cURL Error #:" . $err,
        );
    } else {
        $msg = array(
            'status' => 'success',
        );
    }

    echo json_encode($msg);
    exit(0);
}
add_action('wp_ajax_unsubscribe_from_all', 'unsubscribe_from_all');
add_action('wp_ajax_nopriv_unsubscribe_from_all', 'unsubscribe_from_all');

function save_subscribe_form() {
    global $wpdb;
    $unsubscribe_groups = $_REQUEST['data'];
    $r_data = array();
    $email = $ip_address = '';
    $my_groups = array();

    foreach ($unsubscribe_groups as $group) {
        if ($group['name'] === 'all_groups') {
            $all_groups = unserialize(base64_decode($group['value']));
        } else if ($group['name'] === 'email') {
            $email = $group['value'];
        } else if ($group['name'] === 'ip_address') {
            $ip_address = $group['value'];
        } else {
            $group_data = sendgridController::get_group_data($group['name']);
            $new_group_data = json_decode($group_data);
            $my_groups[$new_group_data->id] = $new_group_data->name;
        }
    }

    $query = "SELECT id FROM ".$wpdb->prefix."users WHERE user_email LIKE '$email'";

    $user_table = $wpdb->get_row($query);

    if (!empty($user_table)) {
        $r_data = array(
            'status' => 'registered',
            //'subscribe_url' => site_url('my-account/email-preferences'),
            'subscribe_url' => site_url('sign-in?') . 'redirect_to=' . home_url('my-account/email-preferences'),
        );

        echo json_encode($r_data);
        exit();
    }

    $query = "SELECT id,verified FROM subscriptions WHERE email_id LIKE '$email'";

    $result = $wpdb->get_row($query);

    if (empty($result)) {

        /* START - Insert into a table */
        $length = 50;
        $token = '';
        $codeAlphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $codeAlphabet .= 'abcdefghijklmnopqrstuvwxyz';
        $codeAlphabet .= '0123456789';
        $max = strlen($codeAlphabet);

        for ($i = 0; $i < $length; $i++) {
            $token .= $codeAlphabet[random_int(0, $max - 1)];
        }

        $secret_key = 'ur_secret_key';
        $secret_iv = 'ur_secret_iv';

        $output = false;
        $encrypt_method = 'AES-256-CBC';
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16);

        if ($action == 'e') {
            $output = base64_encode(openssl_encrypt($email, $encrypt_method, $key, 0, $iv));
        } elseif ($action == 'd') {
            $output = openssl_decrypt(base64_decode($email), $encrypt_method, $key, 0, $iv);
        }

        $table = 'subscriptions';
        $data = array(
            'email_id' => $email,
            'ip_address' => $ip_address,
            'hash' => $token,
            'group_ids' => serialize(array_keys($my_groups)),
            'created_on' => date('Y-m-d H:i:s'),
            'modified_on' => date('Y-m-d H:i:s')
        );
        $wpdb->insert($table, $data);
        $my_id = $wpdb->insert_id;

        /* END - Insert into a table */

        $r_data = array(
            'message' => 'error',
        );
//        if ($output->job_id) {
        if (!empty($my_id)) {
            $dynamic_template_email_confirmation_id = sendgridController::SG_DYNAMIC_EMAIL_TEMPLATES['new_subscriber_email_confirmation'];
            $response = sendgridController::send_dynamic_email($dynamic_template_email_confirmation_id, 0, array(), array(
                        array(
                            'to' => array(
                                array(
                                    'name' => $email,
                                    'email' => $email,
                                )),
								'dynamic_template_data' => array(
									'verification_link' => site_url("subscribe-thank-you?verify_email=true&verification_token=$token&email_id=" . base64_encode($email)),
									'curr_year' => date('Y'),                                    
									'brand_name' => get_bloginfo('name'),                                 
									'home_url' => site_url(),
									'privacy_policy_url' => site_url('privacy-policy'),
									'terms_of_service_url' => site_url('terms-of-service'),
									'contact_us_url' => site_url('contact-us'),
									'facebook_link' => esc_attr(get_option('facebook_link')),
									'twitter_link' => esc_attr(get_option('twitter_link')),
									'linkedin_link' =>  esc_attr(get_option('linkedin_link')),
									'instagram_link' =>  esc_attr(get_option('instagram_link')),
									'manage_your_preferences_link' => site_url('my-account/email-preferences'),
								)
							)
						));
			
            $r_data = array(
                'status' => 'success',
                'message' => 'success',
            );
        }
    } else {
        $r_data = array(
            'status' => 'error',
            'subscribe_url' => site_url('subscribe?email_id=' . base64_encode($email)),
        );
    }

    echo json_encode($r_data);
    exit();
}
add_action('wp_ajax_nopriv_save_subscribe_form', 'save_subscribe_form');
add_action('wp_ajax_save_subscribe_form', 'save_subscribe_form');

function update_subscribe_form() {
    global $wpdb;
    $unsubscribe_groups = $_REQUEST['data'];
    $r_data = array();
    $email = $ip_address = '';
    $my_groups = array();

    foreach ($unsubscribe_groups as $group) {
        if ($group['name'] === 'all_groups') {
            $all_groups = unserialize(base64_decode($group['value']));
        } else if ($group['name'] === 'email') {
            $email = $group['value'];
        } else if ($group['name'] === 'ip_address') {
            $ip_address = $group['value'];
        } else if ($group['name'] === 'subscription_id') {
            $subscription_id = $group['value'];
        } else {
            $group_data = sendgridController::get_group_data($group['name']);
            $new_group_data = json_decode($group_data);
            $my_groups[$new_group_data->id] = $new_group_data->name;
        }
    }

    $table = 'subscriptions';
    $data = array(
        'group_ids' => serialize(array_keys($my_groups)),
        'modified_on' => date('Y-m-d H:i:s')
    );
    $wpdb->update($table, $data, array(
        'id' => $subscription_id
    ));

    /* END - Insert into a table */

    foreach ($all_groups as $single_grp) {
        $unsubscribe_from_group = sendgridController::add_user_suppression_group(array(
                    'group_id' => $single_grp->id,
                    'email_id' => $email,
        ));
    }

    foreach ($my_groups as $key => $single_grp) {
        $subscribe_to_group = sendgridController::remove_user_suppression_group(array(
                    'group_id' => $key,
                    'email_id' => $email,
        ));
    }


    echo json_encode(array(
        'status' => 'success',
    ));
    exit();
}
add_action('wp_ajax_nopriv_update_subscribe_form', 'update_subscribe_form');
add_action('wp_ajax_update_subscribe_form', 'update_subscribe_form');

function subscribe_resend_verification_link() {
    global $wpdb;
    $ip_address = '';
    $email = '';
    $unsubscribe_groups = $_REQUEST['data'];
    $r_data = array();
    $email = $ip_address = '';
    $my_groups = array();

    foreach ($unsubscribe_groups as $group) {
        if ($group['name'] === 'all_groups') {
            $all_groups = unserialize(base64_decode($group['value']));
        } else if ($group['name'] === 'email') {
            $email = $group['value'];
        } else if ($group['name'] === 'ip_address') {
            $ip_address = $group['value'];
        } else if ($group['name'] === 'subscription_id') {
            $subscription_id = $group['value'];
        } else {
            $group_data = sendgridController::get_group_data($group['name']);
            $new_group_data = json_decode($group_data);
            $my_groups[$new_group_data->id] = $new_group_data->name;
        }
    }

    /* START - Insert into a table */
    $length = 50;
    $token = '';
    $codeAlphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $codeAlphabet .= 'abcdefghijklmnopqrstuvwxyz';
    $codeAlphabet .= '0123456789';
    $max = strlen($codeAlphabet);

    for ($i = 0; $i < $length; $i++) {
        $token .= $codeAlphabet[random_int(0, $max - 1)];
    }

    $secret_key = 'ur_secret_key';
    $secret_iv = 'ur_secret_iv';

    $output = false;
    $encrypt_method = 'AES-256-CBC';
    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if ($action == 'e') {
        $output = base64_encode(openssl_encrypt($email, $encrypt_method, $key, 0, $iv));
    } elseif ($action == 'd') {
        $output = openssl_decrypt(base64_decode($email), $encrypt_method, $key, 0, $iv);
    }

    $table = 'subscriptions';
    $data = array(
        'email_id' => $email,
        'ip_address' => $ip_address,
        'hash' => $token,
        'created_on' => date('Y-m-d H:i:s'),
        'modified_on' => date('Y-m-d H:i:s')
    );
    $wpdb->insert($table, $data);
    $my_id = $wpdb->insert_id;

    /* END - Insert into a table */

    $r_data = array(
        'message' => 'error',
    );

    $dynamic_template_email_confirmation_id = sendgridController::SG_DYNAMIC_EMAIL_TEMPLATES['new_subscriber_email_confirmation'];

    $response = sendgridController::send_dynamic_email($dynamic_template_email_confirmation_id, 0, array(), array(
                array(
                    'to' => array(
                        array(
                            'name' => $email,
                            'email' => $email,
                        )), 'dynamic_template_data' => array(
                        'verification_link' => site_url("subscribe?verify_email=true&verification_token=$token&email_id=" . base64_encode($email)),
                        'curr_year' => date('Y'),
						'brand_name' => get_bloginfo('name'),
						'home_url' => home_url(),
                        'privacy_policy_url' => site_url('privacy-policy'),
                        'terms_of_service_url' => site_url('terms-of-service'),
                        'contact_us_url' => site_url('contact-us'),
						'facebook_link' => esc_attr(get_option('facebook_link')),
						'twitter_link' => esc_attr(get_option('twitter_link')),
						'linkedin_link' =>  esc_attr(get_option('linkedin_link')),
						'instagram_link' =>  esc_attr(get_option('instagram_link')),
						'manage_your_preferences_link' => site_url('my-account/email-preferences'),
                    ))
    ));

    $r_data = array(
        'status' => 'success',
        'message' => 'success',
    );

    echo json_encode($r_data);
    exit();
}
add_action('wp_ajax_nopriv_subscribe_resend_verification_link', 'subscribe_resend_verification_link');
add_action('wp_ajax_subscribe_resend_verification_link', 'subscribe_resend_verification_link');

function ur_auto_login($user_id, $status) {
	
    if ($status === true) {
        $_SESSION['registered'] = 'true';
//        wp_set_auth_cookie($user_id, true);
        //Add in SendGrid Contact List
        $user_info = get_userdata($user_id);
        $user_meta = get_user_meta($user_id);

        //Unsubscribe the user from all groups by default except the DAILY ALERT
        $user_groups = sendgridController::fetch_groups();
        $user_groups = json_decode($user_groups);

        foreach ($user_groups as $single_grp) {
            if ( $single_grp->id != daily_unsub_id ) {
                $unsubscribe_from_group = sendgridController::add_user_suppression_group(array(
                            'group_id' => $single_grp->id,
                            'email_id' => $user_info->data->user_email,
                ));
            }
        }

        $data = array(
            'list_ids' => array(
                sendgridController::SG_REGISTRATION_LISTID
            ),
            'contacts' => array(array(
                    "country" => (isset($user_meta['country'])) ? $user_meta['country'][0] : '',
                    "email" => $user_info->data->user_email,
                    "first_name" => $user_meta['first_name'][0],
                    "last_name" => $user_meta['last_name'][0],
                ))
        );
        $response = sendgridController::add_to_list($data);
        wp_safe_redirect('/sign-in/?msg=verified'); // Redirect URL after login.
        exit();
    }
}
add_action('user_registration_check_token_complete', 'ur_auto_login', 10, 2);
?>