<?php

if (!class_exists('newzmania_main_menu_Walker')) {
class newzmania_main_menu_Walker extends Walker_Nav_Menu { 

       
	// Displays start of an element. E.g '<li> Item Name'
    // @see Walker::start_el()
    function start_el(&$output, $item, $depth=0, $args=array(), $id = 0) {
		// echo $item->classes[0];exit;
		// echo "<pre>";print_r($item->classes);echo "</pre>";
    	$object = $item->object;
    	$type = $item->type;
    	$title = $item->title;
    	$description = $item->description;
    	$permalink = $item->url;
		
		$active_class='';
		if ( in_array("current_page_item", $item->classes )){
			$active_class = 'active';
		}
		
		$dropdown_class='';
		if ( in_array("menu-item-has-children", $item->classes )){
			$dropdown_class = 'dropdown';
		}
		
		$aAfter = '';
		if ( in_array("fa", $item->classes )){
			$aAfter = $item->classes[0] . " " . $item->classes[1];
			unset($item->classes[0]);
			unset($item->classes[1]);
		}else{
			$aAfter = "fa fa-arrow-circle-right";
		}
      $output .= "<li class='" .  implode(" ", $item->classes) ." ". $active_class . " ". $dropdown_class . "'>";
        
      //Add SPAN if no Permalink
      if( $permalink && $permalink != '#' ) {
      	$output .= '<a href="' . $permalink . '">';
      	$output .= '<i class="' . $aAfter . '" aria-hidden="true"></i>';
      } else {
      	$output .= '<span>';
      }
       
      $output .= $title;

      if( $description != '' && $depth == 0 ) {
      	$output .= '<small class="description">' . $description . '</small>';
      }

      if( $permalink && $permalink != '#' ) {
      	$output .= '</a>';
      } else {
      	$output .= '</span>';
      }
    }

	}
}
?>