<?php

function after_login_redirect() {
    global $redirect_to;
    if (!isset($_GET['redirect_to']) || empty($_GET['redirect_to'])) {
        $redirect_to = home_url();
    } else {
        $redirect_to = $_GET['redirect_to'];
    }
    return $redirect_to;
}
add_filter('wpa_after_login_redirect', 'after_login_redirect', 10, 0);
add_filter('user_registration_login_redirect', 'after_login_redirect', 10, 0);

function after_register_redirect() {
    return site_url('sign-in');
}
add_filter('user_registration_registration_redirect', 'after_register_redirect', 10, 0);

function ur_custom_menu_items($items) {
    $items['login-history'] = __('Login History', 'user-registration');
    $items['my-downloads'] = __('My Downloads', 'user-registration');
    $items['email-preferences'] = __('Email Preferences', 'user-registration');
    return $items;
}
add_filter('user_registration_account_menu_items', 'ur_custom_menu_items', 10, 1);

function user_registration_add_new_my_account_endpoint() {
    add_rewrite_endpoint('login-history', EP_PAGES);
    add_rewrite_endpoint('my-downloads', EP_PAGES);
    add_rewrite_endpoint('email-preferences', EP_PAGES);
}
add_action('init', 'user_registration_add_new_my_account_endpoint');

function user_registration_login_history_endpoint_content() {
    ur_get_template('myaccount/my-login-history.php');
}
add_action('user_registration_account_login-history_endpoint', 'user_registration_login_history_endpoint_content');

function user_registration_my_downloads_endpoint_content() {
    ur_get_template('myaccount/my-downloads.php');
}
add_action('user_registration_account_my-downloads_endpoint', 'user_registration_my_downloads_endpoint_content');

function user_registration_email_preferences_endpoint_content() {
    ur_get_template('myaccount/my-email-preferences.php');
}
add_action('user_registration_account_email-preferences_endpoint', 'user_registration_email_preferences_endpoint_content');

function my_account_menu_order() {
    $menuOrder = array(
        'edit-profile' => __('Profile Details', 'user-registration'),
        'edit-password' => __('Change Password', 'user-registration'),
        'login-history' => __('Login History', 'user-registration'),
        'my-downloads' => __('Downloads', 'user-registration'),
        'email-preferences' => __('Email Preferences', 'user-registration'),
        'user-logout' => __('Log Out', 'user-registration'),
            //wp_logout_url()  => __('Logout', 'user-registration'),		
    );
    return $menuOrder;
}
add_filter('user_registration_account_menu_items', 'my_account_menu_order');

function custom_download($download_id, $download_link) {
    global $wpdb;
    $download = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."custom_sdm_downloads WHERE post_id = {$download_id} ORDER BY id DESC;");

    $pdf_tracker = (isset($_GET['pdftracking']) && $_GET['pdftracking'] === 'true') ? 'true' : 'false';
    $thankyou_redirect_url = (isset($_GET['thankyou_redirect_url']) && !empty($_GET['thankyou_redirect_url'])) ? $_GET['thankyou_redirect_url'] : 'false';
    if ((isset($_SESSION['form_submission']) && $_SESSION['form_submission'] == 'false') || !isset($_SESSION['form_submission'])) {
        $_SESSION['form_submission'] = 'true';
    }

    if ($pdf_tracker === 'true') {
        $url = site_url('thank-you-pdf?success=true&r_id=' . urlencode(base64_encode($_GET['r_id'])));
    } else if ($thankyou_redirect_url !== 'false') {
        $url = site_url('thank-you-redirect?success=true&r_id=' . urlencode(base64_encode($_GET['r_id'])) . '&r_url=' . urlencode(base64_encode($_GET['thankyou_redirect_url'])));
    } else {
        $url = site_url('thank-you?success=true&r_id=' . urlencode(base64_encode($_GET['r_id'])));
    }

    wp_redirect($url);
    exit;
}
add_action('sdm_process_download_request', 'custom_download', 10, 2);

function save_in_user_meta() {
    global $wpdb;
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        //check ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        //to check ip is pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    $last_updated_row = $wpdb->get_row("SELECT * FROM visitor_pdfviews WHERE user_ip_address = '$ip' AND resource_id = '{$_GET['resource_id']}' ORDER BY id DESC ");
    if (!isset($last_updated_row->id) || $last_updated_row->id == '') {
        $wpdb->insert('visitor_pdfviews', array(
            'ip_address' => $ip,
            'file_id' => 0,
            'file_url' => $_GET['file_url'],
            'read_pages' => $_GET['read_pages'],
            'total_pages' => $_GET['total_pages'],
            'resource_id' => $_GET['resource_id'],
        ));
    } else {
        $wpdb->update('visitor_pdfviews', array(
            'ip_address' => $ip,
            'file_url' => $_GET['file_url'],
            'read_pages' => $_GET['read_pages'],
            'total_pages' => $_GET['total_pages'],
            'created_on' => date('Y-m-d H:i:s'),
                ), array(
            'id' => $last_updated_row->id
        ));
    }

    exit();
}
add_action('wp_ajax_nopriv_save_in_user_meta', 'save_in_user_meta');
add_action('wp_ajax_save_in_user_meta', 'save_in_user_meta');

function post_data_meta_box() {
    add_meta_box('global-notice', __('Other Post Details', 'other_posts_details'), 'post_data_meta_box_callback', array('post', 'resources', 'news'), 'side');
}
add_action('add_meta_boxes', 'post_data_meta_box');


function post_data_meta_box_callback($post) {
    // Add a nonce field so we can check for it later.
    wp_nonce_field('premium_regular_nonce', 'premium_regular_nonce');
    $premium_regular_post = get_post_meta($post->ID, '_premium_regular', true);
    $author_name_post = get_post_meta($post->ID, '_author_name', true);
    $form_id = get_post_meta($post->ID, 'form_id', true);
    $sponsored_by_post = get_post_meta($post->ID, '_sponsored_by', true);
    $source_name_post = get_post_meta($post->ID, '_source_name', true);
    $source_url_post = get_post_meta($post->ID, '_source_url', true);
    $read_time_post = get_post_meta($post->ID, '_read_time', true);
    $partner_link = get_post_meta($post->ID, 'partner_link', true);
    $partner_logo = get_post_meta($post->ID, 'partner_logo', true);
    $image_courtesy_name_post = get_post_meta($post->ID, '_image_courtesy_name', true);
    $image_courtesy_url_post = get_post_meta($post->ID, '_image_courtesy_url', true);
    $types = array(
        'regular' => 'Regular',
        'premium' => 'Premium'
    );
    ?>
    <div class='inside'>
        <h3><?php _e('Premium or Regular', 'other_posts_details'); ?></h3>
        <p>
            <?php
            foreach ($types as $key => $type) {
                ?>
                <input type="radio" name="premium_regular" id="<?php echo $key; ?>_radio" value="<?php echo $key; ?>" <?php echo isset($premium_regular_post) ? ($premium_regular_post == $key ? 'checked' : '') : ('regular' == $key ? 'checked' : ''); ?>  /> 
                <label for="<?php echo $key; ?>_radio"><?php echo $type; ?></label><br />
                <?php
            }
            ?>
        </p>
    </div>
    <div class='inside'>
        <h3><?php _e('Form ID', 'form_id'); ?></h3>
        <p>
            <input type="text" name="form_id" id="form_id" value="<?php echo $form_id; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Author Name', 'author_name_text'); ?></h3>
        <p>
            <input type="text" name="author_name" id="author_name" value="<?php echo $author_name_post; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Sponsored by', 'sponsered_by_text'); ?></h3>
        <p>
            <input type="text" name="sponsored_by" id="sponsored_by" value="<?php echo $sponsored_by_post; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Source Name', 'source_name_text'); ?></h3>
        <p>
            <input type="text" name="source_name" id="source_name" value="<?php echo $source_name_post; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Source URL', 'source_url_text'); ?></h3>
        <p>
            <input type="text" name="source_url" id="source_url" value="<?php echo $source_url_post; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Read Time', 'read_time_text'); ?></h3>
        <p>
            <input type="text" name="read_time" id="read_time" value="<?php echo $read_time_post; ?>" /> 
        </p>
    </div>
	
    <div class='inside'>
        <h3><?php _e('Partner Link', 'read_time_text'); ?></h3>
        <p>
            <input type="text" name="partner_link" id="partner_link" style="width:100%;" value="<?php echo $partner_link; ?>" /> 
        </p>
    </div>
	
    <div class='inside'>
        <h3><?php _e('Partner Logo', 'read_time_text'); ?></h3>
        <p>
            <input type="text" name="partner_logo" id="partner_logo" style="width:100%;" value="<?php echo $partner_logo; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Image Courtesy', 'image_courtesy_name_text'); ?></h3>
        <p>
            <input type="text" name="image_courtesy_name" id="image_courtesy_name" value="<?php echo $image_courtesy_name_post; ?>" /> 
        </p>
    </div>

    <div class='inside'>
        <h3><?php _e('Image Courtesy URL', 'image_courtesy_url_text'); ?></h3>
        <p>
            <input type="text" name="image_courtesy_url" id="image_courtesy_url" value="<?php echo $image_courtesy_url_post; ?>" /> 
        </p>
    </div>


    <?php
}


function save_meta_boxes_data($post_id) {
    // Verify that the nonce is valid.
    if (!wp_verify_nonce($_POST['premium_regular_nonce'], 'premium_regular_nonce')) {
        return;
    }
    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check the user's permissions.
    if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {

        if (!current_user_can('edit_page', $post_id)) {
            return;
        }
    } else {

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }

    // OK, it's safe for us to save the data now.
    // Sanitize user input.
    $premium_regular = sanitize_text_field($_POST['premium_regular']);
    $form_id = sanitize_text_field($_POST['form_id']);
    $author_name = sanitize_text_field($_POST['author_name']);
    $sponsored_by = sanitize_text_field($_POST['sponsored_by']);
    $source_name = sanitize_text_field($_POST['source_name']);
    $source_url = sanitize_text_field($_POST['source_url']);
    $read_time = sanitize_text_field($_POST['read_time']);
    $partner_link = sanitize_text_field($_POST['partner_link']);
    $partner_logo = sanitize_text_field($_POST['partner_logo']);
    $image_courtesy_name = sanitize_text_field($_POST['image_courtesy_name']);
    $image_courtesy_url = sanitize_text_field($_POST['image_courtesy_url']);


    // Update the meta field in the database.
    update_post_meta($post_id, '_premium_regular', $premium_regular);
    update_post_meta($post_id, 'form_id', $form_id);
    update_post_meta($post_id, '_author_name', $author_name);
    update_post_meta($post_id, '_sponsored_by', $sponsored_by);
    update_post_meta($post_id, '_source_name', $source_name);
    update_post_meta($post_id, '_source_url', $source_url);
    update_post_meta($post_id, '_read_time', $read_time);
    update_post_meta($post_id, 'partner_link', $partner_link);
    update_post_meta($post_id, 'partner_logo', $partner_logo);
    update_post_meta($post_id, '_image_courtesy_name', $image_courtesy_name);
    update_post_meta($post_id, '_image_courtesy_url', $image_courtesy_url);
}
add_action('save_post', 'save_meta_boxes_data', 10, 1);

function filter_archive_title($title) {

    if (is_post_type_archive()) {
        return post_type_archive_title('', false);
    }
}
add_filter('get_the_archive_title', 'filter_archive_title');

function start_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'start_session', 1);

function validate_email() {
    $msg = '';
    $email = $_REQUEST['email_id'];
    if (!isset($_REQUEST['lp_var']) || $_REQUEST['lp_var'] === 'false') {
        $exists = email_exists($email);
        if ($exists){
            $msg = "E-mail already exists.";
			echo json_encode(array(
				'msg' => $msg,
				'curl_error' => $err
			));
			exit();
		}
    }
	
    $err = '';
    if ($msg == '' && $email != '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
		
        $url = 'https://disify.com/api/email/' . $email;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, 150);
        $err = curl_error($ch);
        $response = curl_exec($ch);
        curl_close($ch);

        //decode the json response
        $json = json_decode($response, true);
        $domain_arr = explode('.', $json['domain']);
        if (in_array(strtolower($domain_arr[0]), array('yahoo', 'gmail', 'outlook', 'rediffmail','ymail','yahoomail'))) {
            $msg = "We only accept business emails.";
        } else if ((isset($json['whitelist']) && $json['whitelist'] == 1) || (isset($json['disposable']) && $json['disposable'] == 1)) {
            $msg = "We only accept business e-mails.";
        } else {
            $msg = "";
        }
    } else {
        $msg = "Invalid business e-mail. Please check again.";
    }
    
	//$msg = "";/*bypass validation*/
	
    echo json_encode(array(
        'msg' => $msg,
        'curl_error' => $err
    ));
    exit();
}
add_action('wp_ajax_nopriv_validate_email', 'validate_email');
add_action('wp_ajax_validate_email', 'validate_email');

function fetch_user_details() {
    $msg = '';
    $email = $_REQUEST['email_id'];
    $exists = email_exists($email);
    $response = array(
        'status' => 'error',
        'msg' => $msg
    );

    if ($exists) {
        $user_id = $exists;
        $user_data = get_user_by('id', $user_id);
        $job_title = get_user_meta($user_id, 'user_registration_job_title', true);
        $company_name = get_user_meta($user_id, 'user_registration_company_name', true);

        $user_details = array(
            'name' => $user_data->first_name . ' ' . $user_data->last_name,
            'company_name' => $company_name,
            'job_title' => $job_title,
        );
        $response = array(
            'status' => 'success',
            'user_details' => $user_details,
            'msg' => $msg,
        );
    }

    echo json_encode($response);
    exit();
}
add_action('wp_ajax_nopriv_fetch_user_details', 'fetch_user_details');
add_action('wp_ajax_fetch_user_details', 'fetch_user_details');

function wpb_sender_name($original_email_from) {
    return esc_attr( get_bloginfo('name') );
}
add_filter('wp_mail_from_name', 'wpb_sender_name');


function ajax_filterposts_handler() {
    $category = esc_attr($_POST['category']);
    $resource_type = esc_attr($_POST['resource_type']);
    $date = esc_attr($_POST['date']);
    $current_page = (isset($_POST['page'])) ? $_POST['page'] : 1;
    $ppp = 8;
    $args = array(
        'post_type' => 'resources',
        'post_status' => 'publish',
        'posts_per_page' => $ppp,
        'orderby' => 'date',
        'order' => 'DESC',
        'offset' => ($current_page - 1) * $ppp
    );

    if ($category != 'all') {
        $args['cat'] = $category;
    }

    if ($resource_type != 'all') {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'resource_types',
                'field' => 'slug',
                'terms' => $resource_type,
            )
        );
    }

    if ($date == 'old') {
        $args['order'] = 'ASC';
    } else {
        $args['order'] = 'DESC';
    }
    $posts = 'No posts found.';
    $the_query = new WP_Query($args);

    $total_pages = $the_query->max_num_pages;
    if ($the_query->have_posts()) :
        ob_start();
        while ($the_query->have_posts()) : $the_query->the_post();
            $post_thumbnail_url = '';

            if (get_the_post_thumbnail_url(null, 'medium_large') != false) {
                $post_thumbnail_url = get_the_post_thumbnail_url(null, 'medium_large');
            } else {
                $post_thumbnail_url = get_template_directory_uri() . '/images/no-thumb/medium_large.png';
            }
            ?>
            <div class="td_module_flex td_module_flex_1 td_module_wrap td-animation-stack">
                <div class="td-module-container td-category-pos-above">
                    <div class="td-image-container">
                        <div class="td-module-thumb"><a href="<?php the_permalink() ?>" rel="bookmark" class="td-image-wrap " title="<?php the_title_attribute() ?>"><img src="<?php echo esc_url($post_thumbnail_url) ?>)" class="resource-img-resposnive" /></a></div>
                    </div>

                    <div class="td-module-meta-info">
                        <?php
                        $categories = get_the_terms(get_the_ID(), 'resource_types');
                        foreach ($categories as $category) {
                            ?>
                            <a href="<?php echo get_term_link($category->term_id); ?>" class="resource-category  td-post-category"><?php echo $category->name; ?></a>
                        <?php } ?> 

                        <h3 class="entry-title td-module-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute() ?>"><?php the_title() ?></a></h3>
                        <div class="td-excerpt"><?php the_excerpt(); ?></div>
                        <div class="td-editor-date">

                            <span class="td-author-date">
                                <?php
                                $sponsored_by = get_the_terms(get_the_ID(), 'sponsored_by');
                                foreach ($sponsored_by as $sponsored_by_single) {
                                    ?>
                                    <span class="td-post-author-name"><a href="<?php echo get_term_link($sponsored_by_single->term_id); ?>"><?php echo $sponsored_by_single->name; ?></a> <span>-</span> </span>
                                <?php } ?> 
                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="<?php echo esc_html(date(DATE_W3C, get_the_time('U'))) ?>"><?php the_time(get_option('date_format')) ?></time></span>
                            </span>
                        </div>

                        <div class="td-read-more">
                            <a href="<?php the_permalink() ?>">Read more</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        endwhile;
        if ($total_pages > 1 && $current_page < $total_pages) {
            ?>
            <div id="resources-ajax-load-more" class="ajax-load-more-container"><span class="resources-load-more" data-total-pages="<?php echo $total_pages; ?>" data-current-page="<?php echo $current_page; ?>"><a>Load more   &nbsp;<i class="td-icon-font td-icon-menu-down"></i></a></span></div>
            <?php
        }
        $posts = ob_get_clean();
    endif;

    $return = array(
        'posts' => $posts,
        'append' => ($current_page > 1) ? 'true' : 'false'
    );

    wp_send_json($return);
    exit(0);
}
add_action('wp_ajax_filterposts', 'ajax_filterposts_handler');
add_action('wp_ajax_nopriv_filterposts', 'ajax_filterposts_handler');

function register_fields() {
    register_setting('general', 'total_followers', 'esc_attr');
    add_settings_field('fav_color', '<label for="total_followers">' . __('Total Followers', 'total_followers') . '</label>', 'fields_html', 'general');
}
add_action('admin_init', 'register_fields');

function fields_html() {
    $value = get_option('total_followers', '');
    echo '<input type="text" id="total_followers" name="total_followers" value="' . $value . '" />';
}

function vComp() {
    $value = get_option('total_followers', '');
    return $value;
}
add_shortcode('vShortcode', 'vComp');

function post_read_time() {
    $post_id = url_to_postid(get_permalink());

    $read_time = (get_post_meta($post_id, '_read_time', true) != '') ? get_post_meta($post_id, '_read_time', true) : '';
    return $read_time;
}
add_shortcode('post-read-time', 'post_read_time');

function get_PostViews($post_ID) {
//    $count_key = 'post_views_count';
    $count_key = 'mnky_post_views_count';
//    $count = get_post_meta($postID, $count_key, true);
    $count = get_post_meta($post_ID, $count_key, true);
//    print $count;

    if ($count == '') {
//        delete_post_meta($postID, $count_key);
//        add_post_meta($postID, $count_key, '0');

        delete_post_meta($post_ID, $count_key);
        add_post_meta($post_ID, $count_key, '0');
        return "0 View";
    }
    return $count . ' Views';
}

function post_column_views($newcolumn) {
    //Retrieves the translated string, if translation exists, and assign it to the 'default' array.
    $newcolumn['post_views'] = __('Views');
    return $newcolumn;
}
add_filter('manage_posts_columns', 'post_column_views');

function post_custom_column_views($column_name, $id) {

    if ($column_name === 'post_views') {
        echo get_PostViews(get_the_ID());
    }
}
add_action('manage_posts_custom_column', 'post_custom_column_views', 10, 2);

function wpse28145_add_custom_types($query) {
    if (is_tag() && $query->is_main_query()) {

        $post_types = get_post_types();
        $query->set('post_type', $post_types);
		
    }
}
add_filter('pre_get_posts', 'wpse28145_add_custom_types');

function wti_loginout_menu_link( $items, $args) {
	if ($args->theme_location == 'top_bar_menu') {
		if (is_user_logged_in()) {
			$itens .='<li class="right"><a href="'.wp_logout_url() .'">'. __("Log Out") .'</a></li>';
			
		}
	}
return $items;
}
add_filter( 'wp_nav_menu_items', 'wti_loginout_menu_link', 10, 2);

function add_new_content_after_news_custom_post_type($content) {

      if (is_singular("news")){

			if(get_post_meta(get_the_ID(), '_source_url', true) != '') {
				$source_name = get_post_meta(get_the_ID(), '_source_name', true);
				$source_url = get_post_meta(get_the_ID(), '_source_url', true);
				$aftercontent = "<div class='td-post-date td-post-source news-source' style='margin-top: 5px;'>";
				$aftercontent .= "News Source: <a href='$source_url' target='_blank'>$source_name</a>";
				$aftercontent .= "</div>";
			}

        $fullcontent = $content . $aftercontent;

		return $fullcontent;

	}else{
	   
		return $content;
 
	}
}
add_filter('the_content', 'add_new_content_after_news_custom_post_type');

function get_the_name($id){
	
	$name = '';
	$first_name = '';
	$last_name = '';
	$meta = get_user_meta( $id );
	
	if(isset($meta['first_name'][0])){
		$first_name = $meta['first_name'][0];
	}
	if(isset($meta['last_name'][0])){
		$last_name = $meta['last_name'][0];
	}
	if( !empty($first_name) || !empty($last_name) ){
		if( !empty($first_name) ){
			$name = $first_name.' ';
		}
		if( !empty($last_name) ){
			$name .= $last_name;
		}
	}else{
		$user_ = get_user_by( 'id', $id );
		$name = $user_->nickname;
	}
	
	return $name;
	
}

function load_more_posts(){

    $limit = (isset($_POST["limit"])) ? $_POST["limit"] : 9;
    $paged = (isset($_POST['paged'])) ? $_POST['paged'] : 1;
    $s = (isset($_POST['search'])) ? $_POST['search'] : 'abcd';

    header("Content-Type: text/html");
	
	$offset = ( $limit * $paged ) - $limit;
	
	$args = array( 
		'posts_per_page' => $limit, 
		'paged' => $paged,  
		'offset' => $offset, 
		's' => $s
	);
	
	$allsearch = new WP_Query($args);
	if ( $allsearch->have_posts() ){

		while ( $allsearch->have_posts() ) : $allsearch->the_post();
			get_template_part( 'template-parts/content' );
		endwhile;

	}else{
		
		echo '<h3 style="margin-bottom:40px;text-align:center;color:#999999;">No More Contents!</h3><style>#load-more_posts{display:none;}</style>';
		
	}
	wp_reset_query();

}

add_action('wp_ajax_nopriv_load_more_posts', 'load_more_posts');
add_action('wp_ajax_load_more_posts', 'load_more_posts');

function get_post_count($s){
	$args = array( 
		'showposts' => '-1',
		's' => $s
	);								
	$allsearch = new WP_Query($args);
	$count = $allsearch->post_count;
	return $count;
}

function show_post_count($s){
	echo get_post_counts($s);
}

function ur_change_smart_tags( $content ) {
	
	$facebook_link = esc_attr(get_option('facebook_link'));
	$twitter_link = esc_attr(get_option('twitter_link'));
	$linkedin_link = esc_attr(get_option('linkedin_link'));
	$instagram_link = esc_attr(get_option('instagram_link'));
	$curr_year = date('Y');
	
	$content    = str_replace( '{{facebook_link}}', $facebook_link, $content );
	$content    = str_replace( '{{twitter_link}}', $twitter_link, $content );
	$content    = str_replace( '{{linkedin_link}}', $linkedin_link, $content );
	$content    = str_replace( '{{instagram_link}}', $instagram_link, $content );
	$content    = str_replace( '{{curr_year}}', $curr_year, $content );
	
    return $content;
	
}
add_filter( 'user_registration_email_template_message', 'ur_change_smart_tags',10 ,1 );

function insert_smart_tags($args){
    
    $content = $args['message'];
	$brand_name = get_bloginfo('name');
	$home_url = home_url();
	$facebook_link = esc_attr(get_option('facebook_link'));
	$twitter_link = esc_attr(get_option('twitter_link'));
	$linkedin_link = esc_attr(get_option('linkedin_link'));
	$instagram_link = esc_attr(get_option('instagram_link'));
	$curr_year = date('Y');
	
	$content    = str_replace( '{{facebook_link}}', $facebook_link, $content );
	$content    = str_replace( '{{twitter_link}}', $twitter_link, $content );
	$content    = str_replace( '{{linkedin_link}}', $linkedin_link, $content );
	$content    = str_replace( '{{instagram_link}}', $instagram_link, $content );
	$content    = str_replace( '{{curr_year}}', $curr_year, $content );
	$content    = str_replace( '{{brand_name}}', $brand_name, $content );
	$content    = str_replace( '{{home_url}}', $home_url, $content );
	
    $args['message'] = $content;
   
    return $args;
	
}
add_filter('wp_mail','insert_smart_tags', 10,1);


function time_elapsed_string($time_ago)
{
    $time_ago = strtotime($time_ago);
    $cur_time   = time();
    $time_elapsed   = $cur_time - $time_ago;
    $seconds    = $time_elapsed ;
    $minutes    = round($time_elapsed / 60 );
    $hours      = round($time_elapsed / 3600);
    // Seconds
    if($seconds <= 60){
        return "just now";
    }
    //Minutes
    else if($minutes <=60){
        if($minutes==1){
            return "one minute ago";
        }
        else{
            return "$minutes minutes ago";
        }
    }
    //Hours
    else if($hours <=24){
        if($hours==1){
            return "an hour ago";
        }else{
            return "$hours hrs ago";
        }
    }else{
		return date('F d, Y', $time_ago);
	}
	
}


if ( !function_exists( 'newzmania_pagination' ) ):
	function newzmania_pagination( $prev = '&lsaquo;', $next = '&rsaquo;' ) {
		global $wp_query, $wp_rewrite;
		$wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
		$pagination = array(
			'base' => @add_query_arg( 'paged', '%#%' ),
			'format' => '',
			'total' => $wp_query->max_num_pages,
			'current' => $current,
			'prev_text' => $prev,
			'next_text' => $next,
			'type' => 'plain'
		);
		if ( $wp_rewrite->using_permalinks() )
			$pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ) . 'page/%#%/', 'paged' );

		if ( !empty( $wp_query->query_vars['s'] ) )
			$pagination['add_args'] = array( 's' => str_replace( ' ', '+', get_query_var( 's' ) ) );

		$links = paginate_links( $pagination );

		return empty( $links ) ? '' : $links;
	}
endif;

add_action('template_redirect', function() {
	
    if ( is_user_logged_in() || !is_page() ) {
        return;
    }
	
	if ( !is_user_logged_in() && is_page('register') ) {
        return;
    }
	
	if ( !is_user_logged_in() &&  is_page('my-account')) {
		global $wp;
		wp_redirect(site_url('sign-in?') . 'redirect_to=' . home_url($wp->request));
		exit();
    }

    $restricted = array(16); // all your restricted pages
    if (in_array(get_queried_object_id(), $restricted)) {
        global $wp;
        wp_redirect(site_url('sign-in?') . 'redirect_to=' . home_url($wp->request));
        exit();
    }
	
});


function remove_admin_bar() {
    if (!current_user_can('administrator') && !current_user_can('editor') && !current_user_can('author') && !is_admin()) {
        show_admin_bar(false);
    }
}
add_action('after_setup_theme', 'remove_admin_bar');

function add_class_not_loggged_in($classes) {
	if( !is_user_logged_in() ) {
		$classes[] = 'not-logged-in';
	}
	return $classes;
}
add_filter('body_class','add_class_not_loggged_in');

/* Support for HTML5 */
add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

add_theme_support( 'yoast-seo-breadcrumbs' );


add_filter( 'wpseo_breadcrumb_single_link' ,'wpseo_remove_breadcrumb_link', 10 ,2);

function wpseo_remove_breadcrumb_link( $link_output , $link ){
    $text_to_remove = 'Home | Lead Marketwise';
  
    if( $link['text'] == $text_to_remove ) {
      $link_output = '<a href="/">Home</a>';
    }
 
    return $link_output;
}

function forgot_password_wpseo_metakeywords( $keyword ) { 
    global $wp;
	$current_url = home_url(add_query_arg(array(), $wp->request));
	$link_array = explode('/', $current_url);
	$currpage = end($link_array);
	if(isset($currpage) && $currpage == 'lost-password'){
		$keyword = 'Reset your password';
	}
	return $keyword; 
};
add_filter( 'wpseo_metakeywords', 'forgot_password_wpseo_metakeywords', 10, 1 );

function forgot_password_wpseo_metadesc( $meta_desc ) { 
    global $wp;
	$current_url = home_url(add_query_arg(array(), $wp->request));
	$link_array = explode('/', $current_url);
	$currpage = end($link_array);
	if(isset($currpage) && $currpage == 'lost-password'){
		$meta_desc = 'Lost your password, we have sent you a reset password link.';
	}
	return $meta_desc; 
};
add_filter( 'wpseo_metadesc', 'forgot_password_wpseo_metadesc', 10, 1 );

function forgot_password_wpseo_title($title) {
	global $wp;
	$current_url = home_url(add_query_arg(array(), $wp->request));
	$link_array = explode('/', $current_url);
	$currpage = end($link_array);
	if(isset($currpage) && $currpage == 'lost-password'){
		$title = 'Forgot Password Page | The Growth Insights';
	}
	return $title;
}
add_filter( 'wpseo_title', 'forgot_password_wpseo_title', 10, 1 );

function display_countries_dropdown(){
	?>
	<select data-rules="" data-id="country_1630075754" name="country_1630075754" id="country_1630075754" class="select ur-frontend-field user-registration-valid" data-label="Select Your Country" data-allow_clear="true" data-placeholder="" aria-invalid="false">
							<option value="AF">Afghanistan</option><option value="AX">Åland Islands</option><option value="AL">Albania</option><option value="DZ">Algeria</option><option value="AS">American Samoa</option><option value="AD">Andorra</option><option value="AO">Angola</option><option value="AI">Anguilla</option><option value="AQ">Antarctica</option><option value="AG">Antigua and Barbuda</option><option value="AR">Argentina</option><option value="AM">Armenia</option><option value="AW">Aruba</option><option value="AU">Australia</option><option value="AT">Austria</option><option value="AZ">Azerbaijan</option><option value="BS">Bahamas</option><option value="BH">Bahrain</option><option value="BD">Bangladesh</option><option value="BB">Barbados</option><option value="BY">Belarus</option><option value="BE">Belgium</option><option value="PW">Belau</option><option value="BZ">Belize</option><option value="BJ">Benin</option><option value="BM">Bermuda</option><option value="BT">Bhutan</option><option value="BO">Bolivia</option><option value="BQ">Bonaire, Saint Eustatius and Saba</option><option value="BA">Bosnia and Herzegovina</option><option value="BW">Botswana</option><option value="BV">Bouvet Island</option><option value="BR">Brazil</option><option value="IO">British Indian Ocean Territory</option><option value="VG">British Virgin Islands</option><option value="BN">Brunei</option><option value="BG">Bulgaria</option><option value="BF">Burkina Faso</option><option value="BI">Burundi</option><option value="KH">Cambodia</option><option value="CM">Cameroon</option><option value="CA">Canada</option><option value="CV">Cape Verde</option><option value="KY">Cayman Islands</option><option value="CF">Central African Republic</option><option value="TD">Chad</option><option value="CL">Chile</option><option value="CN">China</option><option value="CX">Christmas Island</option><option value="CC">Cocos (Keeling) Islands</option><option value="CO">Colombia</option><option value="KM">Comoros</option><option value="CG">Congo (Brazzaville)</option><option value="CD">Congo (Kinshasa)</option><option value="CK">Cook Islands</option><option value="CR">Costa Rica</option><option value="HR">Croatia</option><option value="CU">Cuba</option><option value="CW">Curaçao</option><option value="CY">Cyprus</option><option value="CZ">Czech Republic</option><option value="DK">Denmark</option><option value="DJ">Djibouti</option><option value="DM">Dominica</option><option value="DO">Dominican Republic</option><option value="EC">Ecuador</option><option value="EG">Egypt</option><option value="SV">El Salvador</option><option value="GQ">Equatorial Guinea</option><option value="ER">Eritrea</option><option value="EE">Estonia</option><option value="ET">Ethiopia</option><option value="FK">Falkland Islands</option><option value="FO">Faroe Islands</option><option value="FJ">Fiji</option><option value="FI">Finland</option><option value="FR">France</option><option value="GF">French Guiana</option><option value="PF">French Polynesia</option><option value="TF">French Southern Territories</option><option value="GA">Gabon</option><option value="GM">Gambia</option><option value="GE">Georgia</option><option value="DE">Germany</option><option value="GH">Ghana</option><option value="GI">Gibraltar</option><option value="GR">Greece</option><option value="GL">Greenland</option><option value="GD">Grenada</option><option value="GP">Guadeloupe</option><option value="GU">Guam</option><option value="GT">Guatemala</option><option value="GG">Guernsey</option><option value="GN">Guinea</option><option value="GW">Guinea-Bissau</option><option value="GY">Guyana</option><option value="HT">Haiti</option><option value="HM">Heard Island and McDonald Islands</option><option value="HN">Honduras</option><option value="HK">Hong Kong</option><option value="HU">Hungary</option><option value="IS">Iceland</option><option value="IN">India</option><option value="ID">Indonesia</option><option value="IR">Iran</option><option value="IQ">Iraq</option><option value="IE">Ireland</option><option value="IM">Isle of Man</option><option value="IL">Israel</option><option value="IT">Italy</option><option value="CI">Ivory Coast</option><option value="JM">Jamaica</option><option value="JP">Japan</option><option value="JE">Jersey</option><option value="JO">Jordan</option><option value="KZ">Kazakhstan</option><option value="KE">Kenya</option><option value="KI">Kiribati</option><option value="KW">Kuwait</option><option value="KG">Kyrgyzstan</option><option value="LA">Laos</option><option value="LV">Latvia</option><option value="LB">Lebanon</option><option value="LS">Lesotho</option><option value="LR">Liberia</option><option value="LY">Libya</option><option value="LI">Liechtenstein</option><option value="LT">Lithuania</option><option value="LU">Luxembourg</option><option value="MO">Macao S.A.R., China</option><option value="MK">Macedonia</option><option value="MG">Madagascar</option><option value="MW">Malawi</option><option value="MY">Malaysia</option><option value="MV">Maldives</option><option value="ML">Mali</option><option value="MT">Malta</option><option value="MH">Marshall Islands</option><option value="MQ">Martinique</option><option value="MR">Mauritania</option><option value="MU">Mauritius</option><option value="YT">Mayotte</option><option value="MX">Mexico</option><option value="FM">Micronesia</option><option value="MD">Moldova</option><option value="MC">Monaco</option><option value="MN">Mongolia</option><option value="ME">Montenegro</option><option value="MS">Montserrat</option><option value="MA">Morocco</option><option value="MZ">Mozambique</option><option value="MM">Myanmar</option><option value="NA">Namibia</option><option value="NR">Nauru</option><option value="NP">Nepal</option><option value="NL">Netherlands</option><option value="NC">New Caledonia</option><option value="NZ">New Zealand</option><option value="NI">Nicaragua</option><option value="NE">Niger</option><option value="NG">Nigeria</option><option value="NU">Niue</option><option value="NF">Norfolk Island</option><option value="MP">Northern Mariana Islands</option><option value="KP">North Korea</option><option value="NO">Norway</option><option value="OM">Oman</option><option value="PK">Pakistan</option><option value="PS">Palestinian Territory</option><option value="PA">Panama</option><option value="PG">Papua New Guinea</option><option value="PY">Paraguay</option><option value="PE">Peru</option><option value="PH">Philippines</option><option value="PN">Pitcairn</option><option value="PL">Poland</option><option value="PT">Portugal</option><option value="PR">Puerto Rico</option><option value="QA">Qatar</option><option value="RE">Reunion</option><option value="RO">Romania</option><option value="RU">Russia</option><option value="RW">Rwanda</option><option value="BL">Saint Barthélemy</option><option value="SH">Saint Helena</option><option value="KN">Saint Kitts and Nevis</option><option value="LC">Saint Lucia</option><option value="MF">Saint Martin (French part)</option><option value="SX">Saint Martin (Dutch part)</option><option value="PM">Saint Pierre and Miquelon</option><option value="VC">Saint Vincent and the Grenadines</option><option value="SM">San Marino</option><option value="ST">São Tomé and Príncipe</option><option value="SA">Saudi Arabia</option><option value="SN">Senegal</option><option value="RS">Serbia</option><option value="SC">Seychelles</option><option value="SL">Sierra Leone</option><option value="SG">Singapore</option><option value="SK">Slovakia</option><option value="SI">Slovenia</option><option value="SB">Solomon Islands</option><option value="SO">Somalia</option><option value="ZA">South Africa</option><option value="GS">South Georgia/Sandwich Islands</option><option value="KR">South Korea</option><option value="SS">South Sudan</option><option value="ES">Spain</option><option value="LK">Sri Lanka</option><option value="SD">Sudan</option><option value="SR">Suriname</option><option value="SJ">Svalbard and Jan Mayen</option><option value="SZ">Swaziland</option><option value="SE">Sweden</option><option value="CH">Switzerland</option><option value="SY">Syria</option><option value="TW">Taiwan</option><option value="TJ">Tajikistan</option><option value="TZ">Tanzania</option><option value="TH">Thailand</option><option value="TL">Timor-Leste</option><option value="TG">Togo</option><option value="TK">Tokelau</option><option value="TO">Tonga</option><option value="TT">Trinidad and Tobago</option><option value="TN">Tunisia</option><option value="TR">Turkey</option><option value="TM">Turkmenistan</option><option value="TC">Turks and Caicos Islands</option><option value="TV">Tuvalu</option><option value="UG">Uganda</option><option value="UA">Ukraine</option><option value="AE">United Arab Emirates</option><option value="GB">United Kingdom (UK)</option><option value="US" selected="selected">United States (US)</option><option value="UM">United States (US) Minor Outlying Islands</option><option value="VI">United States (US) Virgin Islands</option><option value="UY">Uruguay</option><option value="UZ">Uzbekistan</option><option value="VU">Vanuatu</option><option value="VA">Vatican</option><option value="VE">Venezuela</option><option value="VN">Vietnam</option><option value="WF">Wallis and Futuna</option><option value="EH">Western Sahara</option><option value="WS">Samoa</option><option value="YE">Yemen</option><option value="ZM">Zambia</option><option value="ZW">Zimbabwe</option>
	</select>
	<?php
}

function remove_all_theme_styles() {
	if ( is_page_template('landing-pages/landing-page-1.php') ) {
		global $wp_styles,$wp_scripts;
		foreach( $wp_styles->queue as $style ) :
		   wp_deregister_style($wp_styles->registered[$style]->handle);
		   wp_dequeue_style($wp_styles->registered[$style]->handle);
		endforeach;    
		foreach( $wp_scripts->queue as $script ) :
			wp_dequeue_script($wp_scripts->registered[$script]->handle);
			wp_deregister_script($wp_scripts->registered[$script]->handle);
		endforeach;
	}
}
// add_action( 'wp_enqueue_scripts', 'remove_all_theme_styles', 100 );


function tradingview_stock_ticker_shortcode($atts) {
    return '<div class="home-line-height"><iframe scrolling="no" allowtransparency="false" frameborder="0" src="https://s.tradingview.com/embed-widget/ticker-tape/?locale=in#%7B%22symbols%22%3A%5B%7B%22description%22%3A%22Peloton%22%2C%22proName%22%3A%22NASDAQ%3APTON%22%7D%2C%7B%22description%22%3A%22Farfetch%20Limited%22%2C%22proName%22%3A%22NYSE%3AFTCH%22%7D%2C%7B%22description%22%3A%22Crowdstrike%22%2C%22proName%22%3A%22NASDAQ%3ACRWD%22%7D%2C%7B%22description%22%3A%22Datadog%22%2C%22proName%22%3A%22NASDAQ%3ADDOG%22%7D%2C%7B%22description%22%3A%22Zoom%20Video%22%2C%22proName%22%3A%22NASDAQ%3AZM%22%7D%2C%7B%22description%22%3A%22Alteryx%22%2C%22proName%22%3A%22NYSE%3AAYX%22%7D%2C%7B%22description%22%3A%22Cloudera%22%2C%22proName%22%3A%22NYSE%3ACLDR%22%7D%2C%7B%22description%22%3A%22Lyft%22%2C%22proName%22%3A%22NASDAQ%3ALYFT%22%7D%2C%7B%22description%22%3A%22Twilio%22%2C%22proName%22%3A%22NYSE%3ATWLO%22%7D%2C%7B%22description%22%3A%22Lightspeed%20POS%22%2C%22proName%22%3A%22TSX%3ALSPD%22%7D%2C%7B%22description%22%3A%22Elastic%20N.V.%22%2C%22proName%22%3A%22NYSE%3AESTC%22%7D%2C%7B%22description%22%3A%22The%20RealReal%22%2C%22proName%22%3A%22NASDAQ%3AREAL%22%7D%2C%7B%22description%22%3A%22Cloudflare%22%2C%22proName%22%3A%22NYSE%3ANET%22%7D%2C%7B%22description%22%3A%22Coupa%20Software%22%2C%22proName%22%3A%22NASDAQ%3ACOUP%22%7D%2C%7B%22description%22%3A%22Smile%20Direct%20Club%22%2C%22proName%22%3A%22NASDAQ%3ASDC%22%7D%2C%7B%22description%22%3A%22Bill.com%22%2C%22proName%22%3A%22CURRENCYCOM%3ABILL%22%7D%2C%7B%22description%22%3A%22Shopify%22%2C%22proName%22%3A%22NYSE%3ASHOP%22%7D%2C%7B%22description%22%3A%22Okta%22%2C%22proName%22%3A%22NASDAQ%3AOKTA%22%7D%2C%7B%22description%22%3A%22MongoDB%22%2C%22proName%22%3A%22NASDAQ%3AMDB%22%7D%2C%7B%22description%22%3A%22Fastly%22%2C%22proName%22%3A%22NYSE%3AFSLY%22%7D%2C%7B%22description%22%3A%22Anaplan%22%2C%22proName%22%3A%22NYSE%3APLAN%22%7D%2C%7B%22description%22%3A%22Fiverr%22%2C%22proName%22%3A%22NYSE%3AFVRR%22%7D%2C%7B%22description%22%3A%222U%22%2C%22proName%22%3A%22NASDAQ%3ATWOU%22%7D%2C%7B%22description%22%3A%22Square%22%2C%22proName%22%3A%22NYSE%3ASQ%22%7D%2C%7B%22description%22%3A%22Avalara%22%2C%22proName%22%3A%22NYSE%3AAVLR%22%7D%2C%7B%22description%22%3A%22DocuSign%22%2C%22proName%22%3A%22NASDAQ%3ADOCU%22%7D%2C%7B%22description%22%3A%22PagerDuty%22%2C%22proName%22%3A%22NYSE%3APD%22%7D%2C%7B%22description%22%3A%22Atlassian%20%22%2C%22proName%22%3A%22NASDAQ%3ATEAM%22%7D%2C%7B%22description%22%3A%22Everbridge%22%2C%22proName%22%3A%22NASDAQ%3AEVBG%22%7D%2C%7B%22description%22%3A%22Zscaler%22%2C%22proName%22%3A%22NASDAQ%3AZS%22%7D%2C%7B%22description%22%3A%22Stichfix%22%2C%22proName%22%3A%22NASDAQ%3ASFIX%22%7D%2C%7B%22description%22%3A%22Salesforce.com%22%2C%22proName%22%3A%22NYSE%3ACRM%22%7D%2C%7B%22description%22%3A%22The%20Trade%20Desk%22%2C%22proName%22%3A%22NASDAQ%3ATTD%22%7D%2C%7B%22description%22%3A%22Veeva%20Systems%22%2C%22proName%22%3A%22NYSE%3AVEEV%22%7D%2C%7B%22description%22%3A%22Ringcentral%22%2C%22proName%22%3A%22NYSE%3ARNG%22%7D%2C%7B%22description%22%3A%22AppFolio%22%2C%22proName%22%3A%22NASDAQ%3AAPPF%22%7D%2C%7B%22description%22%3A%22Zendesk%22%2C%22proName%22%3A%22NYSE%3AZEN%22%7D%2C%7B%22description%22%3A%22Rapid7%22%2C%22proName%22%3A%22NASDAQ%3ARPD%22%7D%2C%7B%22description%22%3A%22ServiceNow%22%2C%22proName%22%3A%22NYSE%3ANOW%22%7D%2C%7B%22description%22%3A%22Pluralsight%22%2C%22proName%22%3A%22NASDAQ%3APS%22%7D%2C%7B%22description%22%3A%22Xero%22%2C%22proName%22%3A%22ASX%3AXRO%22%7D%2C%7B%22description%22%3A%228x8%22%2C%22proName%22%3A%22NYSE%3AEGHT%22%7D%2C%7B%22description%22%3A%22Netflix%22%2C%22proName%22%3A%22NASDAQ%3ANFLX%22%7D%2C%7B%22description%22%3A%22UBER%20TECHNOLOGIES%22%2C%22proName%22%3A%22NYSE%3AUBER%22%7D%2C%7B%22description%22%3A%22HubSpot%22%2C%22proName%22%3A%22NYSE%3AHUBS%22%7D%2C%7B%22description%22%3A%22Q2%20Holdings%22%2C%22proName%22%3A%22NYSE%3AQTWO%22%7D%2C%7B%22description%22%3A%22Tenable%20Holdings%22%2C%22proName%22%3A%22NASDAQ%3ATENB%22%7D%2C%7B%22description%22%3A%22BlackLine%22%2C%22proName%22%3A%22NASDAQ%3ABL%22%7D%2C%7B%22description%22%3A%22Paycom%20Software%22%2C%22proName%22%3A%22NYSE%3APAYC%22%7D%2C%7B%22description%22%3A%22Spotify%22%2C%22proName%22%3A%22NYSE%3ASPOT%22%7D%2C%7B%22description%22%3A%22LiveRamp%20Holdings%22%2C%22proName%22%3A%22NYSE%3ARAMP%22%7D%2C%7B%22description%22%3A%22Yext%22%2C%22proName%22%3A%22NYSE%3AYEXT%22%7D%2C%7B%22description%22%3A%22FIVN%22%2C%22proName%22%3A%22NASDAQ%3AFIVN%22%7D%2C%7B%22description%22%3A%22SPLK%22%2C%22proName%22%3A%22NASDAQ%3ASPLK%22%7D%2C%7B%22description%22%3A%22Medallia%22%2C%22proName%22%3A%22NYSE%3AMDLA%22%7D%2C%7B%22description%22%3A%22Mimecast%20Limited%22%2C%22proName%22%3A%22NASDAQ%3AMIME%22%7D%2C%7B%22description%22%3A%22Dynatrace%22%2C%22proName%22%3A%22NYSE%3ADT%22%7D%2C%7B%22description%22%3A%22WIX.COM%22%2C%22proName%22%3A%22NASDAQ%3AWIX%22%7D%2C%7B%22description%22%3A%22Workiva%22%2C%22proName%22%3A%22NYSE%3AWK%22%7D%2C%7B%22description%22%3A%22Teladoc%22%2C%22proName%22%3A%22NYSE%3ATDOC%22%7D%2C%7B%22description%22%3A%22Survey%20Monkey%22%2C%22proName%22%3A%22NASDAQ%3ASVMK%22%7D%2C%7B%22description%22%3A%22Workday%22%2C%22proName%22%3A%22NASDAQ%3AWDAY%22%7D%2C%7B%22description%22%3A%22Instructure%22%2C%22proName%22%3A%22SWB%3A1IN%22%7D%2C%7B%22description%22%3A%22Amazon%22%2C%22proName%22%3A%22NASDAQ%3AAMZN%22%7D%2C%7B%22description%22%3A%22Paylocity%20Holding%20Corporation%22%2C%22proName%22%3A%22NASDAQ%3APCTY%22%7D%2C%7B%22description%22%3A%22New%20Relic%22%2C%22proName%22%3A%22NYSE%3ANEWR%22%7D%2C%7B%22description%22%3A%22Proofpoint%22%2C%22proName%22%3A%22NASDAQ%3APFPT%22%7D%2C%7B%22description%22%3A%22Match%20Group%22%2C%22proName%22%3A%22NASDAQ%3AMTCH%22%7D%2C%7B%22description%22%3A%22Autodesk%22%2C%22proName%22%3A%22NASDAQ%3AADSK%22%7D%2C%7B%22description%22%3A%22Domo%22%2C%22proName%22%3A%22NASDAQ%3ADOMO%22%7D%2C%7B%22description%22%3A%22Adobe%22%2C%22proName%22%3A%22NASDAQ%3AADBE%22%7D%2C%7B%22description%22%3A%22Talend%20S.A.%22%2C%22proName%22%3A%22NASDAQ%3ATLND%22%7D%2C%7B%22description%22%3A%22Upwork%22%2C%22proName%22%3A%22NASDAQ%3AUPWK%22%7D%2C%7B%22description%22%3A%22Dropbox%22%2C%22proName%22%3A%22NASDAQ%3ADBX%22%7D%2C%7B%22description%22%3A%22Bandwidth%22%2C%22proName%22%3A%22NASDAQ%3ABAND%22%7D%2C%7B%22description%22%3A%22Paypal%22%2C%22proName%22%3A%22NASDAQ%3APYPL%22%7D%2C%7B%22description%22%3A%22J2%20Global%22%2C%22proName%22%3A%22NASDAQ%3AJCOM%22%7D%2C%7B%22description%22%3A%22Appian%20Corporation%22%2C%22proName%22%3A%22NASDAQ%3AAPPN%22%7D%2C%7B%22description%22%3A%22Zuora%22%2C%22proName%22%3A%22NYSE%3AZUO%22%7D%2C%7B%22description%22%3A%22Palo%20Alto%20Networks%22%2C%22proName%22%3A%22NYSE%3APANW%22%7D%2C%7B%22description%22%3A%22PING%20IDENTITY%22%2C%22proName%22%3A%22NYSE%3APING%22%7D%2C%7B%22description%22%3A%22Qualys%22%2C%22proName%22%3A%22NASDAQ%3AQLYS%22%7D%2C%7B%22description%22%3A%22Ceridian%20HCM%20Holding%22%2C%22proName%22%3A%22NYSE%3ACDAY%22%7D%2C%7B%22description%22%3A%22Intuit%22%2C%22proName%22%3A%22NASDAQ%3AINTU%22%7D%2C%7B%22description%22%3A%22RealPage%22%2C%22proName%22%3A%22NASDAQ%3ARP%22%7D%2C%7B%22description%22%3A%22GoDaddy%22%2C%22proName%22%3A%22NYSE%3AGDDY%22%7D%2C%7B%22description%22%3A%22Box%22%2C%22proName%22%3A%22NYSE%3ABOX%22%7D%2C%7B%22description%22%3A%22SolarWinds%22%2C%22proName%22%3A%22NYSE%3ASWI%22%7D%2C%7B%22description%22%3A%22SAILPOINT%20TECHNOLOGIES%22%2C%22proName%22%3A%22NYSE%3ASAIL%22%7D%2C%7B%22description%22%3A%22Eventbrite%22%2C%22proName%22%3A%22NYSE%3AEB%22%7D%2C%7B%22description%22%3A%22Expedia%22%2C%22proName%22%3A%22NASDAQ%3AEXPE%22%7D%2C%7B%22description%22%3A%22FireEye%22%2C%22proName%22%3A%22NASDAQ%3AFEYE%22%7D%2C%7B%22description%22%3A%22Blackbaud%22%2C%22proName%22%3A%22NASDAQ%3ABLKB%22%7D%2C%7B%22description%22%3A%22Black%20Knight%22%2C%22proName%22%3A%22NYSE%3ABKI%22%7D%2C%7B%22description%22%3A%22Shutterstock%22%2C%22proName%22%3A%22NYSE%3ASSTK%22%7D%2C%7B%22description%22%3A%22LogMein%22%2C%22proName%22%3A%22NASDAQ%3ALOGM%22%7D%2C%7B%22description%22%3A%22Bookings%22%2C%22proName%22%3A%22NASDAQ%3ABKNG%22%7D%2C%7B%22description%22%3A%22Check%20Point%20Software%22%2C%22proName%22%3A%22NASDAQ%3ACHKP%22%7D%2C%7B%22description%22%3A%22Nutanix%22%2C%22proName%22%3A%22NASDAQ%3ANTNX%22%7D%2C%7B%22description%22%3A%22Guidewire%20Software%22%2C%22proName%22%3A%22NYSE%3AGWRE%22%7D%2C%7B%22description%22%3A%22Ebay%22%2C%22proName%22%3A%22NASDAQ%3AEBAY%22%7D%2C%7B%22description%22%3A%22TripAdvisor%22%2C%22proName%22%3A%22NASDAQ%3ATRIP%22%7D%2C%7B%22description%22%3A%22Blue%20Apron%22%2C%22proName%22%3A%22NYSE%3AAPRN%22%7D%2C%7B%22description%22%3A%22Facebook%22%2C%22proName%22%3A%22NASDAQ%3AFB%22%7D%5D%2C%22colorTheme%22%3A%22dark%22%2C%22isTransparent%22%3Afalse%2C%22displayMode%22%3A%22regular%22%2C%22width%22%3A%22100%25%22%2C%22height%22%3A46%2C%22utm_source%22%3A%22techalertlive.com%22%2C%22utm_medium%22%3A%22widget%22%2C%22utm_campaign%22%3A%22ticker-tape%22%7D" style="box-sizing: border-box; height: 46px; width: 100%;padding: 0;margin: 0;display:block;border:none;overflow:hidden;background:#dce6ee;"></iframe></div>';
}
add_shortcode('tradingview_stock_ticker', 'tradingview_stock_ticker_shortcode');


function change_wpseo_metadesc( $meta_desc ) { 
    global $wp;
	$current_url = home_url(add_query_arg(array(), $wp->request));
	$link_array = explode('/', $current_url);
	$currpage = end($link_array);
	if(isset($currpage) && $currpage == 'lost-password'){
		$meta_desc = 'Forgot your password, confirm you have received a reset password link.';
	}
	if(isset($currpage) && $currpage == 'resources'){
		$meta_desc = 'Download trending, insightful and informative resources like White Papers, eBooks, Infographics for free.';
		
		if(isset($_GET['rtype']) && $_GET['rtype'] == 'white-paper'){
			$meta_desc = 'Browse through a vast array of sales, marketing, technology, SMB, business White Papers published by top firms and uncover newer solutions for your venture.';
		}
		if(isset($_GET['rtype']) && $_GET['rtype'] == 'ebook'){
			$meta_desc = 'We bring you well-researched eBooks and eGuides from industry experts and leading research organizations.';
		}
		if(isset($_GET['rtype']) && $_GET['rtype'] == 'infographic'){
			$meta_desc = 'Find exclusive infographics around topics like growth, profits, business, and more. Sign in now to download for free.';
		}
	}
	
	return $meta_desc; 
};
add_filter( 'wpseo_metadesc', 'change_wpseo_metadesc', 10, 1 );

function change_wpseo_title($title) {
	global $wp;
	$current_url = home_url(add_query_arg(array(), $wp->request));
	$link_array = explode('/', $current_url);
	$currpage = end($link_array);
	if(isset($currpage) && $currpage == 'lost-password'){
		$title = 'Forgot Password Page | '.get_bloginfo('name');
	}
	if(isset($currpage) && $currpage == 'resources'){
		$title = 'Trending Resources | '.get_bloginfo('name');
		
		if(isset($_GET['rtype']) && $_GET['rtype'] == 'white-paper'){
			$title = 'Business White Papers | '.get_bloginfo('name');
		}
		if(isset($_GET['rtype']) && $_GET['rtype'] == 'ebook'){
			$title = 'eBooks | '.get_bloginfo('name');
		}
		if(isset($_GET['rtype']) && $_GET['rtype'] == 'infographic'){
			$title = 'Free Infographics on Business | '.get_bloginfo('name');
		}
	}
	
	return $title;
}
add_filter( 'wpseo_title', 'change_wpseo_title', 10, 1 );


add_shortcode('image_courtesy_shortcode', 'image_courtesy');

function image_courtesy() {

    $post_id = url_to_postid(get_permalink());


    
    //$image_courtesy123 = (get_post_meta($post_id, '_image_courtesy_name', true) != '') ? get_post_meta($post_id, '_image_courtesy_name', true) : 'source';
    //$image_courtesy_url = (get_post_meta($post_id, '_image_courtesy_url', true) != '') ? get_post_meta($post_id, '_image_courtesy_url', true) : home_url();


    $image_courtesy123 = (get_post_meta($post_id, '_image_courtesy_name', true) != '') ? get_post_meta($post_id, '_image_courtesy_name', true) : '';
    $image_courtesy_url = (get_post_meta($post_id, '_image_courtesy_url', true) != '') ? get_post_meta($post_id, '_image_courtesy_url', true) : home_url();

    if(get_post_meta($post_id, '_image_courtesy_name', true)){
    return "Image Courtesy: " . "<a href='$image_courtesy_url' target='_blank'>" . $image_courtesy123 . '</a>';
    }
    else{
        return "";
    }

}

/* Sponsored By - Custom Field Code */

// A callback function to add a custom field to our "presenters" taxonomy
function sponsoredby_taxonomy_custom_fields($tag) {
    // Check for existing taxonomy meta for the term you're editing
    $t_id = $tag->term_id; // Get the ID of the term you're editing
    $term_meta = get_option("taxonomy_term_$t_id"); // Do the check
    ?>

    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="client_url"><?php _e('Client Privacy Policy URL'); ?></label>
        </th>
        <td>
            <input type="text" name="term_meta[client_url]" id="term_meta[client_url]" value="<?php echo $term_meta['client_url'] ? $term_meta['client_url'] : ''; ?>"><br />

        </td>
    </tr>

    <?php
}

// A callback function to save our extra taxonomy field(s)
function save_taxonomy_custom_fields($term_id) {
    if (isset($_POST['term_meta'])) {
        $t_id = $term_id;
        $term_meta = get_option("taxonomy_term_$t_id");
        $cat_keys = array_keys($_POST['term_meta']);
        foreach ($cat_keys as $key) {
            if (isset($_POST['term_meta'][$key])) {
                $term_meta[$key] = $_POST['term_meta'][$key];
            }
        }
        //save the option array
        update_option("taxonomy_term_$t_id", $term_meta);
    }
}

// Add the fields to the "presenters" taxonomy, using our callback function
add_action('sponsored_by_edit_form_fields', 'sponsoredby_taxonomy_custom_fields', 10, 2);

// Save the changes made on the "presenters" taxonomy, using our callback function
add_action('edited_sponsored_by', 'save_taxonomy_custom_fields', 10, 2);

?>