<?php
	function wpdocs_theme_slug_widgets_init() {
		register_sidebar( array(
			'name'          => __( 'Single page AD', 'newzmania' ),
			'id'            => 'singlepage-banner',
			'description'   => __( 'Widgets in this area will be shown on all posts and pages content area.', 'newzmania' ),
			'before_widget' => '<div class="tr-ad">',
			'after_widget'  => '</div>',
			'before_title'  => '',
			'after_title'   => '',
		) );
		register_sidebar( array(
			'name'          => __( 'Default Sidebar', 'newzmania' ),
			'id'            => 'sidebar-right',
			'description'   => __( 'Widgets in this area will be shown on all posts and pages right content area.', 'newzmania' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		) );
	}
	add_action( 'widgets_init', 'wpdocs_theme_slug_widgets_init' );
	
	
	
class display_cpt_posts_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
		  
		// Base ID of your widget
		'display_cpt_posts_widget', 
		  
		// Widget name will appear in UI
		__('Display CPT Posts', 'display_cpt_posts'), 
		  
		// Widget description
		array( 'description' => __( 'Displays custom post-type posts.', 'display_cpt_posts' ), ) 
		);
	}
	  
	// Creating widget front-end  
	public function widget( $args, $instance ) {

		$title = apply_filters( 'widget_title', $instance['title'] );
		$post_type = apply_filters( 'post_type', $instance['post_type'] );
		$post_number = intval(apply_filters( 'post_number', $instance['post_number'] ));
		$order_by = intval(apply_filters( 'order_by', $instance['order_by'] ));
		  
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		
		// This is where you run the code and display the output
		if($order_by == 'views'){
			$args_ = array(
				'post_type'     => $post_type, //your post type
				'post_status' => 'publish',
				'posts_per_page' => $post_number,
				'meta_key'      => 'views', //the metakey previously defined
				'orderby'       => 'meta_value_num',
				'order'         => 'DESC'
			);
		}else{
			$args_ = array(  
				'post_type' => $post_type,
				'post_status' => 'publish',
				'orderby' => 'date',
				'order' => 'DESC',
				'posts_per_page' => $post_number, 
			);
		}

		$args_loop = new WP_Query( $args_ ); 

		?>
		<style>
		.tr-post .catagory{
			display: inline-block;
			width: 100%;
		}
		.medium-post-list .tr-post .catagory a,
		.medium-post-list .catagory span{
			float:left;
			margin-right:15px;
		}
		.view-counter{			
			background: rgba(216,93,12,.8);
			padding: 2px 6px;
			position: absolute;
			top: 0px;
			right: 0px;
			color: #ffffff;
			min-width: 50px;
			text-align: center;
		}
		</style>
		<?php
			$tr_widget_title_id = str_replace(' ', '', $title);

		?>
		<div class="tr-section tr-widget" id="<?php echo $tr_widget_title_id; ?>">
		<?php
		
		if($args_loop->have_posts()){
			
			if ( ! empty( $title ) )
			echo '<div class="widget-title"><span>' . $title . '</span></div>';
		
		}
		
		echo '<ul class="medium-post-list">';
		
		while ( $args_loop->have_posts() ) : $args_loop->the_post();
		
		?>
			<li class="tr-post">
			
				<?php if($post_type == 'resources'){ ?>
				<h2 class="entry-title">
					<a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
				</h2>
				
				<?php
				
				$categories = get_the_category( get_the_ID() );//$post->ID
				if(!empty($categories)){
					
					$cats_string = '';
					foreach($categories as $category){
						
						$category_link = get_category_link( $category->term_id );
						$cats_string .= '<a href="'.$category_link.'">'.$category->cat_name.'</a> ';
						
					}
				?>
				
				<div class="catagory"><?php echo $cats_string; ?></div>
				
				<?php } ?>
					
				<?php } ?>
			
				<div class="entry-header">
				
					<div class="entry-thumbnail">
					
						<a href="<?php echo get_the_permalink(); ?>">
						
							<?php if (has_post_thumbnail( get_the_ID() ) ){ ?>
							
							<img class="img-fluid" src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'small-rectangle'); ?>" alt="Image">
							
							<?php }else{ ?>
							
							<img class="img-fluid" src="<?php echo get_template_directory_uri().'/assets/images/placeholder-320x169.jpg'; ?>" alt="Image">
							
							<?php } ?>
							
						</a>
						
						<?php
						
						$views = get_post_meta( get_the_ID(), 'views', true );
						
						if(!empty($views)){
							
							echo '<span class="view-counter"><i class="fa fa-eye"></i> '.$views.'</span>';
							
						}
						
						?>
						
					</div>
					
				</div>
				
				<div class="post-content">
					
					<?php if($post_type != 'resources'){ ?>
					
					<?php
					$categories = get_the_category( get_the_ID() );//$post->ID
					if(!empty($categories)){
						
						$cats_string = '';
						foreach($categories as $category){
							
							$category_link = get_category_link( $category->term_id );
							$cats_string .= '<a href="'.$category_link.'">'.$category->cat_name.'</a> ';
							
						}
					?>
					
					<div class="catagory"><?php echo $cats_string; ?></div>
					
					<?php } ?>
					
					<h2 class="entry-title">
						<a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
					</h2>
					<?php } ?>
				</div>
				
			</li>
		<?php

		endwhile;
		echo '</ul>';
		wp_reset_postdata(); 

		echo '</div>';

		echo $args['after_widget'];
		
	}
			  
	// Widget Backend 
	public function form( $instance ) {
		
		if ( isset( $instance[ 'title' ] ) ) {
		$title = $instance[ 'title' ];
		}
		else {
		$title = __( 'New title', 'display_cpt_posts' );
		}
		// Widget admin form
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php
		if ( isset( $instance[ 'post_type' ] ) ) {
		$post_type = $instance[ 'post_type' ];
		}
		else {
		$post_type = __( 'post', 'display_cpt_posts' );
		}
		// Widget admin form
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'post_type' ); ?>"><?php _e( 'Post Type:' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'post_type' ); ?>" name="<?php echo $this->get_field_name( 'post_type' ); ?>" type="text" value="<?php echo esc_attr( $post_type ); ?>" />
		</p>
		<?php if ( isset( $instance[ 'post_number' ] ) ) {
		$post_number = $instance[ 'post_number' ];
		}
		else {
		$post_number = __( '5', 'display_cpt_posts' );
		}
		// Widget admin form
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'post_number' ); ?>"><?php _e( 'No. of Posts:' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'post_number' ); ?>" name="<?php echo $this->get_field_name( 'post_number' ); ?>" type="text" value="<?php echo esc_attr( $post_number ); ?>" />
		</p>
		<?php if ( isset( $instance[ 'order_by' ] ) ) {
		$order_by = $instance[ 'order_by' ];
		}
		else {
		$order_by = __( 'views', 'display_cpt_posts' );
		}
		// Widget admin form
		?>
		<p>
		<label for="<?php echo $this->get_field_id( 'order_by' ); ?>"><?php _e( 'Order By' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'order_by' ); ?>" name="<?php echo $this->get_field_name( 'order_by' ); ?>" type="text" value="<?php echo esc_attr( $order_by ); ?>" />
		</p>
		<?php
		
	}
		  
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['post_type'] = ( ! empty( $new_instance['post_type'] ) ) ? strip_tags( $new_instance['post_type'] ) : 'post';
		$instance['post_number'] = ( ! empty( $new_instance['post_number'] ) ) ? strip_tags( $new_instance['post_number'] ) : '5';
		$instance['order_by'] = ( ! empty( $new_instance['order_by'] ) ) ? strip_tags( $new_instance['order_by'] ) : 'views';
		return $instance;
	}
	 
	// Class display_cpt_posts_widget ends here
} 
 
// Register and load the widget
function wpb_load_widget() {
    register_widget( 'display_cpt_posts_widget' );
}
add_action( 'widgets_init', 'wpb_load_widget' );