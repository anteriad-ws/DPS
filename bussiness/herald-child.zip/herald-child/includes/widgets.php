<?php
function register_newzmania_widgets() {
    register_sidebar(array(
        'name' => __('Footer-1', 'newzmania'),
        'id' => 'footer-1',
        'description' => __('Widgets in this area will be shown on footer area 1', 'newzmania'),
        'before_widget' => '<div class="widget widget-menu-2">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => __('Footer-2', 'newzmania'),
        'id' => 'footer-2',
        'description' => __('Widgets in this area will be shown on footer area 2', 'newzmania'),
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => __('Footer-3', 'newzmania'),
        'id' => 'footer-3',
        'description' => __('Widgets in this area will be shown on footer area 3', 'newzmania'),
        'before_widget' => '<div class="widget widget-menu-3">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => __('Footer-4', 'newzmania'),
        'id' => 'footer-4',
        'description' => __('Widgets in this area will be shown on footer area 4', 'newzmania'),
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	register_sidebar(array(
        'name' => __('Footer-bottom', 'newzmania'),
        'id' => 'footer-bottom',
        'description' => __('Widgets in this area will be shown on footer Bottom area', 'newzmania'),
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '',
        'after_title' => '',
    ));
}
add_action('widgets_init', 'register_newzmania_widgets');
?>
