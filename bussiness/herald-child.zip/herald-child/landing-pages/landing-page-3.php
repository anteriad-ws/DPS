<?php
/* Template Name: Landing Page with bottom form
 * Template Post Type: resources
 *
*/
?>

<?php get_header('HSlandingPage-3'); ?>
<style>
.form-container{
	background-color:#f5f5f5;
	padding:60px;
	margin-top:60px;
}
body .fm-form .type_gdpr_compliance_checkbox{
	max-width:100%;
	width:100%;
}
body .fm-form .wdform-field:not([type=type_hidden]){
	padding:20px 30px;
}
input[type="text"], input[type="search"], input[type="email"], input[type="url"], input[type="tel"], input[type="number"], input[type="date"], input[type="password"], select, textarea, .herald-single-sticky, td, th, table, .mks_author_widget .mks_autor_link_wrap a, .widget .meks-instagram-follow-link a, .mks_read_more a, .herald-read-more{
	background:transparent;
	border:none;
	border-bottom: 1px solid #ccc !important;
}
.fm-header-bg{
	padding:30px;
}
.fm-form .button-submit{
	padding:10px 20px;
	background:#32abda;
	cursor:pointer;
}
</style>
<div class="body-container-wrapper">
    <div class="body-container container-fluid">
		<div class="row">
			<?php the_content(); ?>
		</div>
    </div><!--end body -->
	
	<?php
	$download_resource_id = get_post_meta($post->ID, 'sdm_description', true);

	$pdf_tracker = get_post_meta($post->ID, 'thankyoupage-pdftracker', true);

	$current_user = wp_get_current_user();
	$job_title = get_user_meta($current_user->ID, 'user_registration_job_title', true);
	$company_name = get_user_meta($current_user->ID, 'user_registration_company_name', true);
	$website_url = get_user_meta($current_user->ID, 'user_registration_website_url', true);
	$phone_number = get_user_meta($current_user->ID, 'user_registration_phone_number', true);


	$categories = get_the_terms($post->ID, 'resource_types');
	$category = array_pop($categories);
	?>

    <div class="form-container container-fluid">
		<div class="container">
			<div class="row">
				<div class="form_container">
					<span style="display: none;" id="get_resource_id"><?php echo $post->ID . '-' . $download_resource_id; ?></span>
					<span style="display: none;" id="get_resource_title"><?php echo $post->post_title; ?></span>

					<?php
					//If a Landing Page has this variable 'thankyoupage-pdftracker' set to true the thank you page should open with a PDF Tracker
					if($pdf_tracker === 'true') {
					?>
						<span style="display: none;" id="set_pdf_tracker">true</span>
					<?php } ?>
					<span style="display: none;" id="get_user_name"><?php echo $current_user->user_login; ?></span>
					<span style="display: none;" id="get_user_email"><?php echo $current_user->user_email; ?></span>
					<span style="display: none;" id="get_user_company"><?php echo $company_name; ?></span>
					<span style="display: none;" id="get_user_job_title"><?php echo $job_title; ?></span>
					<span style="display: none;" id="get_user_website_url"><?php echo $website_url; ?></span>
					<span style="display: none;" id="get_user_phone_number"><?php echo $phone_number; ?></span>
					<?php
					$form_id = get_post_meta( get_the_ID(), 'form_id', true );
					if(empty($form_id)){$form_id = 2;}
					?>
					<?php echo do_shortcode("[Form id='$form_id']"); ?>
				</div>
			</div>
		</div>
    </div><!--end form -->
</div><!--end body wrapper -->

<?php get_footer('HSlandingPage-3'); ?>