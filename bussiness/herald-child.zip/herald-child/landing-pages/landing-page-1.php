<?php
/* Template Name: Landing Page with popup form
 * Template Post Type: resources
 *
*/
?>

<?php get_header('HSlandingPage'); ?>

<div class="body-container-wrapper">
    <div class="body-container container-fluid">

		<?php the_content(); ?>

    </div><!--end body -->
</div><!--end body wrapper -->

<?php get_footer('HSlandingPage'); ?>