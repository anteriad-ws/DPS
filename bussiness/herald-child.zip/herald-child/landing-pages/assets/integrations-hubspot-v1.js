/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 18:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// You wouldn't believe it, but IE11 does not support Object.assign(), so this
// is our non-polyfill replacement.
var assign=function assign(obj1){for(var _len=arguments.length,objs=Array(1<_len?_len-1:0),_key=1;_key<_len;_key++)objs[_key-1]=arguments[_key];if(Object.assign)return Object.assign.apply(Object,[obj1].concat(objs));for(var i=0;i<objs.length;i++)assignOne(obj1,objs[i]);return obj1},assignOne=function assignOne(obj1,obj2){for(var k in obj2)obj2.hasOwnProperty(k)&&(obj1[k]=obj2[k]);return obj1};/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (assign);

/***/ }),

/***/ 23:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "bind": () => (/* binding */ bind),
/* harmony export */   "unbind": () => (/* binding */ unbind),
/* harmony export */   "rebind": () => (/* binding */ rebind),
/* harmony export */   "trigger": () => (/* binding */ trigger),
/* harmony export */   "once": () => (/* binding */ once),
/* harmony export */   "initNamespace": () => (/* binding */ initNamespace),
/* harmony export */   "bindNamed": () => (/* binding */ bindNamed),
/* harmony export */   "unbindNamed": () => (/* binding */ unbindNamed),
/* harmony export */   "unbindAllInNamespace": () => (/* binding */ unbindAllInNamespace),
/* harmony export */   "bindify": () => (/* binding */ bindify),
/* harmony export */   "Bindings": () => (/* binding */ Bindings)
/* harmony export */ });
/* harmony import */ var wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
function _toConsumableArray(arr){return _arrayWithoutHoles(arr)||_iterableToArray(arr)||_unsupportedIterableToArray(arr)||_nonIterableSpread()}function _nonIterableSpread(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(o,minLen){if(o){if("string"==typeof o)return _arrayLikeToArray(o,minLen);var n=Object.prototype.toString.call(o).slice(8,-1);return"Object"===n&&o.constructor&&(n=o.constructor.name),"Map"===n||"Set"===n?Array.from(o):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?_arrayLikeToArray(o,minLen):void 0}}function _iterableToArray(iter){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(iter))return Array.from(iter)}function _arrayWithoutHoles(arr){if(Array.isArray(arr))return _arrayLikeToArray(arr)}function _arrayLikeToArray(arr,len){(null==len||len>arr.length)&&(len=arr.length);for(var i=0,arr2=Array(len);i<len;i++)arr2[i]=arr[i];return arr2}var aps=Array.prototype.slice;var bind=function bind(event,fn){var self=this;return self._bindings||(self._bindings={}),self._bindings[event]||(self._bindings[event]=[]),self._bindings[event].push(fn),function(){self.unbind(event,fn)}};var unbind=function unbind(event,fn){if(!this._bindings)return this;if(!this._bindings[event])return this;for(var boundFn,bindings=[],i=0;i<this._bindings[event].length;i++)boundFn=this._bindings[event][i],boundFn!==fn&&bindings.push(boundFn);this._bindings[event]=bindings};var rebind=function rebind(event,fn){return this.unbind(event,fn),this.bind(event,fn),{event:event,fn:fn}};var trigger=function trigger(event){for(var _len=arguments.length,args=Array(1<_len?_len-1:0),_key=1;_key<_len;_key++)args[_key-1]=arguments[_key];return this._bindings&&null!=this._bindings.all&&triggerImpl.apply(this,["all",event].concat(args)),triggerImpl.apply(this,[event].concat(args))};var triggerImpl=function triggerImpl(event){if(!this._bindings)return this;if(!this._bindings[event])return this;for(var unbinds,fn,args=aps.call(arguments,1),bindings=_toConsumableArray(this._bindings[event]),i=0;i<bindings.length;i++){fn=bindings[i];try{var ret=fn.apply(this,args);// special return value will unbind when triggered
ret===this.unbind&&(null==unbinds&&(unbinds=[]),unbinds.push({event:event,fn:fn}))}catch(e){if(this._throwTriggerErrors)throw e;else wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.error&&wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.error(e)}}if(unbinds)for(var _unbind,_i=0;_i<unbinds.length;_i++)_unbind=unbinds[_i],this.unbind(_unbind.event,_unbind.fn);return this};var once=function once(event,fn){var wrappedFn=function wrappedFn(){return fn.apply(this,aps.call(arguments,0)),unbind};return bind(event,wrappedFn)};var initNamespace=function initNamespace(ctx,namespace){null==ctx._namedBindings&&(ctx._namedBindings={}),null==ctx._namedBindings[namespace]&&(ctx._namedBindings[namespace]={})};var getNamedBinding=function getNamedBinding(ctx,namespace,fnKey){return initNamespace(ctx,namespace),ctx._namedBindings[namespace][fnKey]},setNamedBinding=function setNamedBinding(ctx,namespace,fnKey,event,fn){initNamespace(ctx,namespace),ctx._namedBindings[namespace][fnKey]={event:event,fn:fn}};var bindNamed=function bindNamed(namespace,fnKey,event,fn){return this.unbindNamed(namespace,fnKey),setNamedBinding(this,namespace,fnKey,event,fn),this.bind(event,fn),function(){this.unbindNamed(namespace,fnKey)}};var unbindNamed=function unbindNamed(namespace,fnKey){initNamespace(this,namespace);var entry=getNamedBinding(this,namespace,fnKey);if(entry){var event=entry.event,fn=entry.fn;this.unbind(event,fn)}var namedBindings=this._namedBindings;return delete namedBindings[namespace][fnKey],isEmpty(namedBindings[namespace])&&delete namedBindings[namespace],this};var unbindAllInNamespace=function unbindAllInNamespace(namespace){var bindings=this._namedBindings&&this._namedBindings[namespace];if(null==bindings)return this;for(var fnKey in bindings)bindings.hasOwnProperty(fnKey)&&this.unbindNamed(namespace,fnKey)};var isEmpty=function isEmpty(obj){for(var k in obj)if(obj.hasOwnProperty(k))return!1;return!0};var bindify=function bindify(prototype){return prototype.bind=bind,prototype.unbind=unbind,prototype.on=bind,prototype.off=unbind,prototype.rebind=rebind,prototype.trigger=trigger,prototype.bindNamed=bindNamed,prototype.unbindNamed=unbindNamed,prototype.unbindAllInNamespace=unbindAllInNamespace,prototype};// If you don't want to mix in state with an existing object, you can use this
// as a proxy, for example:
//
// var bindings = new Bindings();
// bindings.bind('hello', function(name) {
//   console.log('hi', name);
//   return bindings.unbind;
// });
// bindings.trigger('hello', 'Max');
var Bindings=function Bindings(){};bindify(Bindings.prototype);

/***/ }),

/***/ 21:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "globalBind": () => (/* binding */ globalBind),
/* harmony export */   "globalOn": () => (/* binding */ globalOn),
/* harmony export */   "globalOff": () => (/* binding */ globalOff),
/* harmony export */   "globalRebind": () => (/* binding */ globalRebind),
/* harmony export */   "globalTrigger": () => (/* binding */ globalTrigger),
/* harmony export */   "globalUnbind": () => (/* binding */ globalUnbind)
/* harmony export */ });
/* harmony import */ var wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var utilities_wbindable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22);
(0,utilities_wbindable_js__WEBPACK_IMPORTED_MODULE_1__.makeWbindable)(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);var globalBind=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.bind.bind(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);var globalOn=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.on.bind(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);var globalOff=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.off.bind(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);var globalRebind=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.rebind.bind(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);var globalTrigger=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.trigger.bind(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);var globalUnbind=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.unbind.bind(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default);

/***/ }),

/***/ 44:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getLocalStorage": () => (/* binding */ getLocalStorage),
/* harmony export */   "removeLocalStorage": () => (/* binding */ removeLocalStorage),
/* harmony export */   "setLocalStorage": () => (/* binding */ setLocalStorage),
/* harmony export */   "updateLocalStorage": () => (/* binding */ updateLocalStorage)
/* harmony export */ });
/* harmony import */ var wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/*
 * This module is designed as a simpler version of our old localStorage
 * utility.  To reduce potential bundle size, it doesn't make use of Obj
 * utilities or wlog, and doesn't return early based on browser detection.
 *
 * To avoid multiple tab bugs, it does not try to do any kind of commit
 * debouncing. Every call to `set` involves JSON.serialize() and every call to
 * `get` involves JSON.parse(). Therefore, if you are performing many
 * operations, you should cache an intermediate value. The
 * updateLocalStorage function is also provided for doing many updates
 * with a single parse and serialize call.
 *
 * If you are working with localStorage on something that requires lots of
 * updates, you should use a separate namespace. That way there is less to
 * deserialize and serialize on each read and write.
 */var throwAsync=function throwAsync(e){setTimeout(function(){throw e},0)},OBJ_PROP="_namespacedLocalStorage",localStorageWorks=function localStorageWorks(ns){if(null!=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorageWorks)return wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorageWorks;try{// no-ops that test get, set, and remove. These may throw an exception
// in Private Browsing mode on iOS and Safari.
var currentVal=localStorage.getItem(ns);localStorage.removeItem(ns),localStorage.setItem(ns,currentVal),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorageWorks=!0}catch(e){wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorageWorks=!1}return wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorageWorks},getMemory=function getMemory(){return null==wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default[OBJ_PROP]&&(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default[OBJ_PROP]={}),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default[OBJ_PROP]};var getLocalStorage=function getLocalStorage(ns){if(!localStorageWorks())return getMemory()[ns]||{};if(localStorage[ns])try{return"null"===localStorage[ns]?{}:JSON.parse(localStorage[ns])}catch(e){throwAsync(e)}return{}};var removeLocalStorage=function removeLocalStorage(ns){if(!localStorageWorks())return void(getMemory()[ns]={});try{localStorage.removeItem(ns)}catch(e){throwAsync(e)}};var setLocalStorage=function setLocalStorage(ns,obj){if(!localStorageWorks())return null!=obj&&"object"==typeof obj&&(getMemory()[ns]=obj),obj;try{// We set W._localStorage for compatibility with the old localStorage util,
// which would otherwise overwrite any changes we make. :0
getMemory()[ns]=obj,localStorage[ns]=JSON.stringify(obj)}catch(e){throwAsync(e)}return obj};var updateLocalStorage=function updateLocalStorage(ns,fn){var obj=getLocalStorage(ns);// fn() may throw an exception. we catch and report because we don't want
// an exception after modifying in-place localStorage to get our local store
// out of sync.
try{fn(obj)}catch(e){throwAsync(e)}return setLocalStorage(ns,obj)};

/***/ }),

/***/ 36:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var pageLoaded=function pageLoaded(fn){var timeout=1<arguments.length&&arguments[1]!==void 0?arguments[1]:4e3,doc=2<arguments.length&&arguments[2]!==void 0?arguments[2]:document,win=3<arguments.length&&arguments[3]!==void 0?arguments[3]:window;if(/loaded|complete/.test(doc.readyState))setTimeout(fn,0);else{var unbind=function unbind(){win.removeEventListener("load",onPageLoad,!1)},onPageLoad=function onPageLoad(){clearTimeout(onLoadTimeout),unbind(),fn()};win.addEventListener("load",onPageLoad,!1);var onLoadTimeout=setTimeout(function(){unbind(),fn()},timeout)}};/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (pageLoaded);

/***/ }),

/***/ 28:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var poll=function poll(cond,fn){var interval=2<arguments.length&&arguments[2]!==void 0?arguments[2]:50,timeout=3<arguments.length&&arguments[3]!==void 0?arguments[3]:5e3,failFn=4<arguments.length?arguments[4]:void 0,pollTimeout=null,start=new Date().getTime(),pollFn=function pollFn(){return new Date().getTime()-start>timeout?void("function"==typeof failFn&&failFn()):void(cond()?fn():(clearTimeout(pollTimeout),pollTimeout=setTimeout(pollFn,interval)))};pollTimeout=setTimeout(pollFn,1)};/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (poll);

/***/ }),

/***/ 2:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* global globalThis */var root;try{root=self,root.self!==root&&typeof root.self!==void 0&&"undefined"!=typeof window&&(root=window)}catch(err){root="undefined"==typeof globalThis?window:globalThis}/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (root);

/***/ }),

/***/ 296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "countMetric": () => (/* binding */ countMetric),
/* harmony export */   "sendMetrics": () => (/* binding */ sendMetrics),
/* harmony export */   "sampleMetric": () => (/* binding */ sampleMetric),
/* harmony export */   "sendMetric": () => (/* binding */ sendMetric),
/* harmony export */   "_clearMetricsCache": () => (/* binding */ _clearMetricsCache)
/* harmony export */ });
/* harmony import */ var wistia_namespace__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var utilities_assign_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18);
/* harmony import */ var utilities_pageLoaded_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36);
/* harmony import */ var utilities_trackingConsentApi_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42);
/* harmony import */ var utilities_xhr_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25);
var _this=undefined;null==wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsCache&&(wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsCache={}),wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsPostFunction||(wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsPostFunction=utilities_xhr_js__WEBPACK_IMPORTED_MODULE_4__.xhrPost),null==wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsDebounceInterval&&(wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsDebounceInterval=500);var METRICS_CACHE=wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsCache;var countMetric=function countMetric(key){var val=1<arguments.length&&arguments[1]!==void 0?arguments[1]:1,extraData=2<arguments.length?arguments[2]:void 0;return sendMetric("count",key,val,extraData)};var sendMetrics=function sendMetrics(){if((0,utilities_trackingConsentApi_js__WEBPACK_IMPORTED_MODULE_3__.isVisitorTrackingEnabled)()){for(var url="https://".concat("pipedream.wistia.com","/mput?topic=metrics"),_len=arguments.length,messages=Array(_len),_key=0;_key<_len;_key++)messages[_key]=arguments[_key];return wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsPostFunction(url,messages.join("\n"))}};var sampleMetric=function sampleMetric(key,val,extraData){return sendMetric("sample",key,val,extraData)};var sendMetric=function sendMetric(type,key,val){var extraData=3<arguments.length&&arguments[3]!==void 0?arguments[3]:{};if((0,utilities_trackingConsentApi_js__WEBPACK_IMPORTED_MODULE_3__.isVisitorTrackingEnabled)())try{null==METRICS_CACHE.toMput&&(METRICS_CACHE.toMput=[]);var messageObj=(0,utilities_assign_js__WEBPACK_IMPORTED_MODULE_1__.default)({type:type,key:key,value:null==val?null:val},extraData),serialized=JSON.stringify(messageObj);METRICS_CACHE.toMput.push(serialized),clearTimeout(wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._msendTimeout),wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._msendTimeout=setTimeout(function(){(0,utilities_pageLoaded_js__WEBPACK_IMPORTED_MODULE_2__.default)(function(){sendMetrics.apply(_this,METRICS_CACHE.toMput),METRICS_CACHE.toMput=[]})},wistia_namespace__WEBPACK_IMPORTED_MODULE_0__.default._simpleMetricsDebounceInterval)}catch(e){console.error(e.message),console.error(e.stack)}};// only used in testing to clear the cache
var _clearMetricsCache=function _clearMetricsCache(){METRICS_CACHE.toMput=[]};

/***/ }),

/***/ 42:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "migrateLegacyVisitorTracking": () => (/* binding */ migrateLegacyVisitorTracking),
/* harmony export */   "consent": () => (/* binding */ consent),
/* harmony export */   "setVisitorTrackingEnabled": () => (/* binding */ setVisitorTrackingEnabled),
/* harmony export */   "isVisitorTrackingEnabled": () => (/* binding */ isVisitorTrackingEnabled)
/* harmony export */ });
/* harmony import */ var wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var utilities_globalBindAndTrigger_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);
/* harmony import */ var utilities_wistiaLocalStorage_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(43);
function _toConsumableArray(arr){return _arrayWithoutHoles(arr)||_iterableToArray(arr)||_unsupportedIterableToArray(arr)||_nonIterableSpread()}function _nonIterableSpread(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(o,minLen){if(o){if("string"==typeof o)return _arrayLikeToArray(o,minLen);var n=Object.prototype.toString.call(o).slice(8,-1);return"Object"===n&&o.constructor&&(n=o.constructor.name),"Map"===n||"Set"===n?Array.from(o):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?_arrayLikeToArray(o,minLen):void 0}}function _iterableToArray(iter){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(iter))return Array.from(iter)}function _arrayWithoutHoles(arr){if(Array.isArray(arr))return _arrayLikeToArray(arr)}function _arrayLikeToArray(arr,len){(null==len||len>arr.length)&&(len=arr.length);for(var i=0,arr2=Array(len);i<len;i++)arr2[i]=arr[i];return arr2}var migrateLegacyVisitorTracking=function migrateLegacyVisitorTracking(){var legacyIsEnabled=(0,utilities_wistiaLocalStorage_js__WEBPACK_IMPORTED_MODULE_2__.getWistiaLocalStorage)().visitorTrackingEnabled;null!=legacyIsEnabled&&((0,utilities_wistiaLocalStorage_js__WEBPACK_IMPORTED_MODULE_2__.updateWistiaLocalStorage)(function(ls){return delete ls.visitorTrackingEnabled}),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking={},wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking[wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTrackingDomain]={isEnabled:legacyIsEnabled,updatedAt:Date.now()},(0,utilities_wistiaLocalStorage_js__WEBPACK_IMPORTED_MODULE_2__.updateWistiaLocalStorage)(function(ls){return ls.visitorTracking=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking}))};wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTrackingDomain||(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTrackingDomain=location.hostname||""),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking||(migrateLegacyVisitorTracking(),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking=(0,utilities_wistiaLocalStorage_js__WEBPACK_IMPORTED_MODULE_2__.getWistiaLocalStorage)().visitorTracking||{});var consent=function consent(val){return null==val?isVisitorTrackingEnabled():setVisitorTrackingEnabled(val)};wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.consent=consent;var setVisitorTrackingEnabled=function setVisitorTrackingEnabled(val){var domain=1<arguments.length&&arguments[1]!==void 0?arguments[1]:wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTrackingDomain;"default"===val?delete wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking[domain]:wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking[domain]={isEnabled:"true"==="".concat(val),updatedAt:Date.now()},(0,utilities_wistiaLocalStorage_js__WEBPACK_IMPORTED_MODULE_2__.updateWistiaLocalStorage)(function(obj){return obj.visitorTracking=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking}),(0,utilities_globalBindAndTrigger_js__WEBPACK_IMPORTED_MODULE_1__.globalTrigger)("visitortrackingchange",val)};var isCurrentDomainOrAnyParentDomainsEnabled=function isCurrentDomainOrAnyParentDomainsEnabled(){if(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTrackingDomain)for(var domainParts=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTrackingDomain.split(".");0<domainParts.length;){var entry=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking[domainParts.join(".")],enabledVal=entry&&entry.isEnabled;if(null!=enabledVal)return enabledVal;domainParts.shift()}// returns undefined instead of false as a result so that we can have
// different behavior if it has not been set.
};var isVisitorTrackingEnabled=function isVisitorTrackingEnabled(){if("boolean"==typeof wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking)// Legacy. We previously persisted this data as a boolean
return wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking;if(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._visitorTracking){// _visitorTracking has been set. Let's check the value for the current
// domain. And if that's set, we return.
var isEnabledVal=isCurrentDomainOrAnyParentDomainsEnabled();if(null!=isEnabledVal)return!!isEnabledVal}var apis=[];if(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.api&&wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.api.all)try{apis.push.apply(apis,_toConsumableArray(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.api.all()))}catch(e){// If W.api.all() is called before W._data is setup, this will throw
// an exception. That's okay--it just means there are effectively no
// video embeds yet.
}if(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.channel&&wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.channel.all)try{apis.push.apply(apis,_toConsumableArray(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.channel.all()))}catch(e){// If W.api.all() is called before W._data is setup, this will throw
// an exception. That's okay--it just means there are effectively no
// channel embeds yet.
}// By default, if any videos have privacy mode enabled, then we disable
// visitor tracking for all videos on the page. In practice, we would only
// see this occur if videos from multiple accounts--with different privacy
// mode settings--appear on the same page.
var isPrivacyModeEnabled=apis.some(function(api){var data=api._mediaData||api._galleryData||{};return!0===data.privacyMode});return!isPrivacyModeEnabled};

/***/ }),

/***/ 22:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "makeWbindable": () => (/* binding */ makeWbindable),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23);
// This is an adaptation on top of bindify that is intended to provide both
// legacy functionality (returning `this` instead of an "unbind" function) and
// and "specialBind" functionality, which is what we use for special
// "composite" bindings like "crosstime" and "betweentimes".
//
// If you're setting up on/off/trigger for any new things, you should use
// bindify directly instead.
wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.bindable||(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.bindable={bind:function bind(event,callback){return this.specialBind&&!0===this.specialBind.apply(this,arguments)?this:callback?(utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.bind.call(this,event,callback),this):void(wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.warn&&wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.warn(this.constructor.name,"bind","falsey value passed in as callback:",callback))},// unbind the matching callback and event for this video
unbind:function unbind(event,callback){return this.specialUnbind&&!0===this.specialUnbind.apply(this,arguments)?this:(callback?utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.unbind.call(this,event,callback):this._bindings&&(this._bindings[event]=[]),this._bindings&&this._bindings[event]&&!this._bindings[event].length&&(this._bindings[event]=null,delete this._bindings[event]),this)},on:function on(event,fn){var specialBindResult=this.specialBind&&this.specialBind.apply(this,arguments);return"function"==typeof specialBindResult?specialBindResult:utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.bind.call(this,event,fn)},off:function off(event,fn){var specialUnbindResult=this.specialUnbind&&this.specialUnbind.apply(this,arguments);return"function"==typeof specialUnbindResult?specialUnbindResult:utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.unbind.call(this,event,fn)},rebind:function rebind(event,callback){return this.unbind(event,callback),this.bind(event,callback),this},// fire an event trigger on the video. for play/pause/ended callbacks.
trigger:function trigger(event){for(var _bindify$trigger,_len=arguments.length,args=Array(1<_len?_len-1:0),_key=1;_key<_len;_key++)args[_key-1]=arguments[_key];return(_bindify$trigger=utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.trigger).call.apply(_bindify$trigger,[this,event].concat(args)),this},bindNamed:function bindNamed(){return utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.bindNamed.apply(this,arguments)},unbindNamed:function unbindNamed(){return utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.unbindNamed.apply(this,arguments)},unbindAllInNamespace:function unbindAllInNamespace(){return utilities_bindify_js__WEBPACK_IMPORTED_MODULE_1__.unbindAllInNamespace.apply(this,arguments)}});var makeWbindable=function makeWbindable(obj){for(var k in wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.bindable){var v=wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.bindable[k];obj[k]||(obj[k]=v)}};/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default.bindable);

/***/ }),

/***/ 43:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getWistiaLocalStorage": () => (/* binding */ getWistiaLocalStorage),
/* harmony export */   "removeWistiaLocalStorage": () => (/* binding */ removeWistiaLocalStorage),
/* harmony export */   "setWistiaLocalStorage": () => (/* binding */ setWistiaLocalStorage),
/* harmony export */   "updateWistiaLocalStorage": () => (/* binding */ updateWistiaLocalStorage)
/* harmony export */ });
/* harmony import */ var wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var utilities_namespacedLocalStorage_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44);
// This localStorage utility can be used in situations where we don't need to
// do very frequent updates or reads. If frequent updates or reads are
// expected, you should use namespacedLocalStorage.js with its own namespace,
// since the entire namespace is deserialized and serialized on read and write
// respectively.
var WISTIA_NAMESPACE="wistia";var getWistiaLocalStorage=function getWistiaLocalStorage(){return (0,utilities_namespacedLocalStorage_js__WEBPACK_IMPORTED_MODULE_1__.getLocalStorage)(WISTIA_NAMESPACE)};var removeWistiaLocalStorage=function removeWistiaLocalStorage(){return wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorage=(0,utilities_namespacedLocalStorage_js__WEBPACK_IMPORTED_MODULE_1__.removeLocalStorage)(WISTIA_NAMESPACE),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorage};var setWistiaLocalStorage=function setWistiaLocalStorage(obj){return wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorage=(0,utilities_namespacedLocalStorage_js__WEBPACK_IMPORTED_MODULE_1__.setLocalStorage)(WISTIA_NAMESPACE,obj),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorage};var updateWistiaLocalStorage=function updateWistiaLocalStorage(fn){return wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorage=(0,utilities_namespacedLocalStorage_js__WEBPACK_IMPORTED_MODULE_1__.updateLocalStorage)(WISTIA_NAMESPACE,fn),wistia_namespace_js__WEBPACK_IMPORTED_MODULE_0__.default._localStorage};

/***/ }),

/***/ 25:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "xhr": () => (/* binding */ xhr),
/* harmony export */   "xhrGet": () => (/* binding */ xhrGet),
/* harmony export */   "xhrPost": () => (/* binding */ xhrPost),
/* harmony export */   "xhrJsonPost": () => (/* binding */ xhrJsonPost)
/* harmony export */ });
/* harmony import */ var utilities_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18);
/* harmony import */ var promiscuous__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26);
/* harmony import */ var promiscuous__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(promiscuous__WEBPACK_IMPORTED_MODULE_1__);
var DONE=4;var xhr=function xhr(type,url,data){var headers=3<arguments.length&&arguments[3]!==void 0?arguments[3]:{},options=4<arguments.length&&arguments[4]!==void 0?arguments[4]:{};return new (promiscuous__WEBPACK_IMPORTED_MODULE_1___default())(function(resolve,reject){var XhrClass=options.XMLHttpRequest||XMLHttpRequest,xhr=new XhrClass;options.afterConstructor&&options.afterConstructor(xhr);var onReadyStateChange=function onReadyStateChange(){if(!(xhr.readyState<DONE))// 200-300 = success, 304 = Not Modified
if(!(null!=xhr.status&&(200<=xhr.status&&300>xhr.status||304==xhr.status))){var badStatusError=new Error("".concat(type," ").concat(url," - Got an unsuccessful status code: ").concat(xhr.status,". ").concat(xhr.statusText));badStatusError.status=xhr.status,console.error(badStatusError.message),reject(badStatusError)}else if(xhr.response&&"string"!=typeof xhr.response)// The browser has modified the response to a non-String type; handle
// it downstream.
resolve({data:xhr.response,status:xhr.status,statusText:xhr.statusText,xhr:xhr});else if("json"===options.dataType)// We're getting a string response but have asked for dataType='json';
// parse it ourselves.
try{var responseJson=JSON.parse(xhr.responseText);resolve({data:responseJson,status:xhr.status,statusText:xhr.statusText,xhr:xhr})}catch(e){var badParseError=new Error("".concat(type," ").concat(url," - Error parsing response text: ").concat(xhr.responseText,"."));console.error(badParseError.message),reject(badParseError)}else// This is a simple non-JSON string response.
resolve({data:xhr.responseText,status:xhr.status,statusText:xhr.statusText,xhr:xhr})};try{xhr.addEventListener("readystatechange",onReadyStateChange,!1)}catch(e){console.error(e.message),console.error(e.stack)}var onError=function onError(){var error=new Error("XHR error");error.status=xhr.status,error.xhr=xhr,reject(error)};xhr.addEventListener("error",onError,!1);var onTimeout=function onTimeout(e){var error=new Error("XHR timeout");error.status=xhr.status,error.message=e&&e.message,error.xhr=xhr,reject(e)};if(xhr.addEventListener("timeout",onTimeout,!1),xhr.open(type,url,!0),options.withCredentials&&(xhr.withCredentials=!0),options.timeout&&(xhr.timeout=options.timeout),null!=options.dataType&&(xhr.responseType=options.dataType),"POST"!==type||headers["content-type"]||xhr.setRequestHeader("content-type","application/x-www-form-urlencoded"),headers)for(var name in headers)headers.hasOwnProperty(name)&&xhr.setRequestHeader(name.toLowerCase(),headers[name]);xhr.send(data),options.afterSend&&options.afterSend(xhr)})};var xhrGet=function xhrGet(url,headers,options){return xhr("GET",url,null,headers,options)};var xhrPost=function xhrPost(url,data,headers,options){return xhr("POST",url,data,headers,options)};var xhrJsonPost=function xhrJsonPost(url,data,headers,options){return headers=(0,utilities_assign_js__WEBPACK_IMPORTED_MODULE_0__.default)({},headers,{"content-type":"application/json"}),xhr("POST",url,JSON.stringify(data),headers,options)};

/***/ }),

/***/ 1:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var utilities_root__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
null==utilities_root__WEBPACK_IMPORTED_MODULE_0__.default.Wistia&&(utilities_root__WEBPACK_IMPORTED_MODULE_0__.default.Wistia={});var W=utilities_root__WEBPACK_IMPORTED_MODULE_0__.default.Wistia;null==W._initializers&&(W._initializers={}),null==W._destructors&&(W._destructors={}),null==W.mixin&&(W.mixin=function(klass,obj){for(var k in obj)obj.hasOwnProperty(k)&&(klass[k]=obj[k])});/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (utilities_root__WEBPACK_IMPORTED_MODULE_0__.default.Wistia);

/***/ }),

/***/ 26:
/***/ ((module) => {

/**@license MIT-promiscuous-©Ruben Verborgh*/(function(func,obj){// Type checking utility function
function is(type,item){return(typeof item)[0]==type}// Creates a promise, calling callback(resolve, reject), ignoring other parameters.
function Promise(callback,handler){return handler=function pendingHandler(resolved,rejected,value,queue,then,i){// Case 1) handle a .then(resolved, rejected) call
if(queue=pendingHandler.q,resolved!=is)return Promise(function(resolve,reject){queue.push({p:this,r:resolve,j:reject,1:resolved,0:rejected})});// Case 2) handle a resolve or reject call
// (`resolved` === `is` acts as a sentinel)
// The actual function signature is
// .re[ject|solve](<is>, success, value)
// Check if the value is a promise and try to obtain its `then` method
if(value&&is(func,value)|is(obj,value))try{then=value.then}catch(reason){rejected=0,value=reason}// If the value is a promise, take over its state
if(is(func,then)){var valueHandler=function valueHandler(resolved){return function(value){then&&(then=0,pendingHandler(is,resolved,value))}};try{then.call(value,valueHandler(1),rejected=valueHandler(0))}catch(reason){rejected(reason)}}// The value is not a promise; handle resolve/reject
else for(handler=function handler(Resolved,Rejected){// If the Resolved or Rejected parameter is not a function,
// return the original promise (now stored in the `callback` variable)
return is(func,Resolved=rejected?Resolved:Rejected)?Promise(function(resolve,reject){finalize(this,resolve,reject,value,Resolved)}):callback;// Otherwise, return a finalized promise, transforming the value with the function
},i=0;i<queue.length;)then=queue[i++],is(func,resolved=then[rejected])?// Otherwise, resolve/reject the promise with the result of the callback
finalize(then.p,then.r,then.j,value,resolved):(rejected?then.r:then.j)(value)},handler.q=[],callback.call(callback={then:function then(resolved,rejected){return handler(resolved,rejected)},catch:function _catch(rejected){return handler(0,rejected)}},function(value){handler(is,1,value)},function(reason){handler(is,0,reason)}),callback}// Finalizes the promise by resolving/rejecting it with the transformed value
function finalize(promise,resolve,reject,value,transform){var fn=function fn(){try{// Transform the value through and check whether it's a promise
value=transform(value),transform=value&&is(obj,value)|is(func,value)&&value.then,is(func,transform)?value==promise?reject(TypeError()):// Take over the promise's state
transform.call(value,resolve,reject):resolve(value)}catch(error){reject(error)}};// Don't polyfill setImmediate, but use it if it's available.
window.setImmediate?window.setImmediate(fn):setTimeout(fn,0)}// Export the main module
function ResolvedPromise(value){return Promise(function(resolve){resolve(value)})}// Creates a rejected promise
// If Promise is defined globally when this runs, just use that.
return window.Promise?void(module.exports=window.Promise):void(// Creates a resolved promise
// Transforms an array of promises into a promise for an array
// Returns a promise that resolves or rejects as soon as one promise in the array does
module.exports=Promise,Promise.resolve=ResolvedPromise,Promise.reject=function(reason){return Promise(function(resolve,reject){reject(reason)})},Promise.all=function(promises){return Promise(function(resolve,reject,count,values){// Array of collected values
// Resolve immediately if there are no promises
// Transform all elements (`map` is shorter than `forEach`)
values=[],count=promises.length||resolve(values),promises.map(function(promise,index){ResolvedPromise(promise).then(// Store the value and resolve if it was the last
function(value){values[index]=value,--count||resolve(values)},// Reject if one element fails
reject)})})},Promise.race=function(promises){return Promise(function(resolve,reject){// Register to all promises in the array
promises.map(function(promise){ResolvedPromise(promise).then(resolve,reject)})})})})("f","o");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
(function(){var countMetric,es,initHubspotIntegration,originalReady,poll,s,setForeignData;return poll=__webpack_require__(28).poll,countMetric=__webpack_require__(296).countMetric,countMetric("legacy/integrations-hubspot-v1",1,{href:window.location.href}),null==window._hsq&&(window._hsq=[]),setForeignData=function setForeignData(video,tracker){var pageName,pageUrl,ref;return pageUrl=document.location.href.split("?")[0],pageName=(null==(ref=document.getElementsByTagName("title")[0])?void 0:ref.innerHTML)||"",pageName=pageName.replace(/^[\n\s]+/,"").replace(/[\n\s]+$/,""),pageName=pageName.replace(/[^\x00-\x7F]/g,""),video.foreignData({hubspot_hutk:tracker.utk.visitor,wistia_visitor_key:video.visitorKey(),page_url:pageUrl,page_name:pageName,canonical_url:tracker.canonicalUrl,page_id:tracker.pageId,content_type:tracker.contentType})},initHubspotIntegration=function initHubspotIntegration(){return wistiaEmbeds.onFind(function(video){return video.ready(function(){var ref;return(null==(ref=video._mediaData.integrations)?void 0:ref.hubspot)?void 0:poll(function(){return video.visitorKey()},function(){return video instanceof Wistia.PlaylistIframeAPI||window._hsq.push(function(tracker){return setForeignData(video,tracker)}),video instanceof Wistia.PublicApi?Wistia.Metrics.videoCount(video,"player/integrations-hubspot-v1/init-on-api-embed"):video instanceof Wistia.PlaylistIframeAPI?Wistia.Metrics.count("player/integrations-hubspot-v1/init-on-iframe-playlist",1,{href:location.href,referrer:document.referrer,hashedId:video.hashedId()}):Wistia.Metrics.count("player/integrations-hubspot-v1/init-on-iframe-embed",1,{href:location.href,referrer:document.referrer,hashedId:video.hashedId()})})})})},null==window.wistiaEmbeds?(null==window.wistiaEmbedShepherdReady?window.wistiaEmbedShepherdReady=initHubspotIntegration:(originalReady=window.wistiaEmbedShepherdReady,window.wistiaEmbedShepherdReady=function(){return originalReady(),initHubspotIntegration()}),es=document.createElement("script"),es.type="text/javascript",es.async=!0,es.src="//fast.wistia.com/assets/external/embed_shepherd-v1.js",s=document.getElementsByTagName("script")[0],s.parentNode.insertBefore(es,s)):initHubspotIntegration()})();
})();

/******/ })()
;