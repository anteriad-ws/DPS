<?php
/* Template Name: Landing Page with right side form
 * Template Post Type: resources
 *
*/
?>

<?php get_header('HSlandingPage-2'); ?>

<div class="body-container-wrapper">
    <div class="body-container container" style="padding-top:40px;">
		<div class="row">
			<?php the_content(); ?>
		</div>
    </div><!--end body -->
</div><!--end body wrapper -->

<?php get_footer('HSlandingPage-2'); ?>