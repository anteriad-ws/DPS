<div class="footer-container-wrapper">
	<div class="footer-container container-fluid">
		<div class="row-fluid-wrapper row-depth-1 row-number-1 ">
			<div class="row-fluid ">
				<div class="span12 widget-span widget-type-cell " style="" data-widget-type="cell" data-x="0" data-w="12">
					<div class="row-fluid-wrapper row-depth-1 row-number-3 ">
						<div class="row-fluid ">
							<div class="span12 widget-span widget-type-global_group " style="" data-widget-type="global_group" data-x="0" data-w="12">
								<div class="" data-global-widget-path="generated_global_groups/4428359302.html">
									<div class="row-fluid-wrapper row-depth-1 row-number-1 ">
										<div class="row-fluid ">
											<div class="span12 widget-span widget-type-raw_html " style="" data-widget-type="raw_html" data-x="0" data-w="12">
												<div class="cell-wrapper layout-widget-wrapper">
													<span id="hs_cos_wrapper_module_147674200098349839" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_raw_html" style="" data-hs-cos-general-type="widget" data-hs-cos-type="raw_html">
														<footer id="hsg-footer--lp" class="hsg-footer">
															<div class="hsg-footer__layout">
																<section class="hsg-footer__copyright">
																	<p style="font-size:18px;">Copyright © 2022 Business Innovations, Inc.</p>
																	<ul style="font-weight:600;font-size:18px;">
																		<li><a href="/">Legal Stuff</a></li>
																		<li><a href="/privacy-policy/">Privacy Policy</a></li>
																	</ul>
																</section>
															</div>
														</footer>
													</span>
												</div><!--end layout-widget-wrapper -->
											</div><!--end widget-span -->
										</div><!--end row-->
									</div><!--end row-wrapper -->
								</div>
							</div><!--end widget-span -->
						</div><!--end row-->
					</div><!--end row-wrapper -->
				</div><!--end widget-span -->
			</div><!--end row-->
		</div><!--end row-wrapper -->
	</div><!--end footer -->
</div><!--end footer wrapper -->

<style>
	#lpForm_popup{
		display:none;
		pointer-events: all;
		overflow-x: hidden;
		overflow-y: hidden;
		position: fixed;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		background-color: rgba(45,62,80,0.79);
		-webkit-transform: translate3d(0, 0, 0);
		transform: translate3d(0, 0, 0);
		width: 100%;
		margin: auto;
		z-index: 100000001;
	}
	#lpForm_popup .form_container .fm-header-title{
		color: #33475b;
		font-size: 24px;
		line-height: 24px;
		font-weight: 700;
		margin:5px 0;
	}
	.fm-form .wdform-label{
		font-size:14px;
		font-weight:600;
	}
	#lpForm_popup .form_container .button-submit {
		text-align: center;
		border-radius: 3px;
		transition: 0.3s ease-in-out;
		display: inline-block;
		text-decoration: none;
		line-height: 24px;
		background-color: #ff7a59;
		color: #fff;
		border: 1px solid #ff7a59;
		padding: 14.5px 22.22px;
		font-size: 15px;
		min-width: 137px;
		-webkit-appearance: none;
		appearance: none;
		font-weight: 600;
	}
	#lpForm_popup .form_container .button-submit:hover {
		background-color: #ffbcac;
		color: #fff;
		border: 1px solid #ffbcac;
	}
	#lpForm_popup .form_container .fm-header{
		text-align:center;
		display:block;
		width:100%;
	}
	#lpForm_popup .form_container .fm-header-bg{
		padding:0px 0px 30px;
	}
	#lpForm_popup .form_container{
		padding:40px 20px;
		margin:50px auto;
		max-width:710px;
		background-color:#ffffff;
		border-radius:3px;
		max-height: 88%;
		overflow-y: scroll;
	}
	@media (min-width:768px){
		body #lpForm_popup .form_container{
			padding:60px 80px;
		}
		body #lpForm_popup .form_container .fm-header-title{
			font-size: 32px;
		}
	}
	

</style>
			
<?php wp_footer(); ?>
<?php
	$form_id = get_post_meta( get_the_ID(), 'form_id', true );
	if(empty($form_id)){$form_id = 2;}
?>
<script>

var fm_form_id = '<?php echo $form_id; ?>';
jQuery( document ).ready(function() {
	console.log('form id :'+fm_form_id);
	 jQuery('.email-validator').find('input').addClass('validate_email');
     
     var result = jQuery('#get_resource_id').html().split('-');
     var resource_id = result[0];
     var download_id = result[1];
     
     jQuery('form').find('.resource-id').val(resource_id);
     jQuery('form').find('.resource-title').val(jQuery('#get_resource_title').html());
     
     jQuery('form').find('.fm_name input').val(jQuery('#get_user_name').html());
     jQuery('form').find('.fm_first_name input').val(jQuery('#get_user_firstname').html());
     jQuery('form').find('.fm_last_name input').val(jQuery('#get_user_lastname').html());
     jQuery('form').find('.fm_business_email input').val(jQuery('#get_user_email').html());
     jQuery('form').find('.fm_company_name input').val(jQuery('#get_user_company').html());
     jQuery('form').find('.fm_website_url input').val(jQuery('#get_user_website_url').html());
     jQuery('form').find('.fm_job_title input').val(jQuery('#get_user_job_title').html());
     
     var r_url = jQuery('#fm_ajax_redirect_url'+fm_form_id).attr('data-ajax_redirect_url');
     if(jQuery('#set_pdf_tracker').length > 0) {
          jQuery('#fm_ajax_redirect_url'+fm_form_id).attr('data-ajax_redirect_url',r_url+download_id+'&r_id='+resource_id+'&pdftracking=true');
     }
     else{
          jQuery('#fm_ajax_redirect_url'+fm_form_id).attr('data-ajax_redirect_url',r_url+download_id+'&r_id='+resource_id);
     }
	
	jQuery( ".vc_toggle" ).each(function( index ) {
		$holder = jQuery( this ).find('.vc_toggle_title .vc_toggle_icon').detach();
		jQuery( this ).find('.vc_toggle_title').prepend($holder);
	});
	
	jQuery('.download_button').on('click', function(){
		display_popup();
	});
	
	jQuery('#lpForm_popup').on('click', function(e){
		if (e.target !== this)
		return;

		hide_popup();
	});

});

function popup_form(){
	display_popup();
}

function display_popup(){
	jQuery('#lpForm_popup').show();
}
function hide_popup(){
	jQuery('#lpForm_popup').hide();
}
</script>

<?php

if($_SESSION['typ_redirect'] == 'true') {

?>
	<script type="text/javascript">
		toastr["error"]("Please submit the form to access the resource.")

		toastr.options = {
		  "closeButton": false,
		  "debug": false,
		  "newestOnTop": false,
		  "progressBar": false,
		  "positionClass": "toast-bottom-right",
		  "preventDuplicates": false,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		}
    </script>
	
<?php

    unset($_SESSION['typ_redirect']);
	
}

?>

</body>
</html>