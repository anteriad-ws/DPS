<?php

/*
  This is Herald Child Theme functions file
  You can use it to modify specific features and styling of Herald Theme
 */

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/email-testing.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/mp-settings.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/sendgrid-controller.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/init-postTypes-Taxonomies.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/menu-walkers.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/widgets.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/shortcodes.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/widget-sidebars.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/thumbnails.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/custom-functions.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/sendgrid.php';
//require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'includes/newsletter-crons.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'includes/email-preview.php';

add_action('after_setup_theme', 'herald_child_theme_setup', 99);

function herald_child_theme_setup() {
    add_action('wp_enqueue_scripts', 'herald_child_load_scripts');
}

function herald_child_load_scripts() {

    $version = filemtime(__FILE__) . rand(10, 100);

    wp_register_style('herald_child_load_scripts', trailingslashit(get_stylesheet_directory_uri()) . 'style.css', false, HERALD_THEME_VERSION, 'screen');
    wp_enqueue_style('herald_child_load_scripts');

    wp_enqueue_style('herald-child-custom-css', trailingslashit(get_stylesheet_directory_uri()) . '/css/custom-styles.css', array(), $version, false);

   // wp_enqueue_style('toastr', '//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css');
    wp_enqueue_style('jquery-chosen', 'https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css');

    //wp_enqueue_script('toastr', '//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css');

    wp_enqueue_script('jquery-cookie', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js');
    wp_enqueue_script('jquery-chosen', 'https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js');

    //wp_enqueue_script('customjs', get_stylesheet_directory_uri() . '/js/script.js', array('jquery'), $version + 3);
    //wp_enqueue_script('generaljs', get_stylesheet_directory_uri() . '/js/general.js', array('jquery'), $version + 3);
    //wp_enqueue_script('landing_pagejs', get_stylesheet_directory_uri() . '/js/landing_page.js', array('jquery'), $version + 3);
    //wp_enqueue_script('register_subscribejs', get_stylesheet_directory_uri() . '/js/register_subscribe.js', array('jquery'), $version + 3);
    //wp_localize_script('customjs', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
	wp_enqueue_script('customjs', get_stylesheet_directory_uri() . '/js/custom.js', '1.15');
	
	

    wp_enqueue_style('toastr', '//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css');
    wp_enqueue_script('toastr', '//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js');
}

if (!function_exists('mytheme_register_nav_menu')) {

    function mytheme_register_nav_menu() {
        register_nav_menus(array(
            'header_HSlandingPage_2' => __('Header HSlandingPage_2 Menu', 'herald-child'),
            'footer_HSlandingPage_2' => __('Footer HSlandingPage_2 Menu', 'herald-child'),
        ));
    }

    add_action('after_setup_theme', 'mytheme_register_nav_menu', 0);
}

//Herald

function hide_menu() {



// Use this for specific user role. Change site_admin part accordingly
    if (current_user_can('editor')) {
        remove_menu_page('themes.php'); // Appearance
        remove_menu_page('options-general.php'); //Settings
        remove_menu_page('edit-comments.php');
        remove_menu_page('edit.php?post_type=cookielawinfo');
        remove_menu_page('profile.php');
        remove_menu_page('tools.php');
        remove_menu_page('herald_options');
        remove_menu_page('manage_fm');
        remove_menu_page('wpseo_workouts');
        remove_menu_page('envato-market');
    }
}

add_action('admin_head', 'hide_menu');

function login_with_email_address($username) {

    $user = get_user_by_email($username);

    if (!empty($user->user_login))
        $username = $user->user_login;

    return $username;
}

add_action('wp_authenticate', 'login_with_email_address');

function check_attempted_login($user, $username, $password) {

    if (get_transient('attempted_login')) {

        $datas = get_transient('attempted_login');




        if ($datas['tried'] >= 3) {

            $until = get_option('_transient_timeout_' . 'attempted_login');

            $time = time_to_go($until);




            return new WP_Error('too_many_tried', sprintf(__('<strong>ERROR</strong>: You have reached authentication limit, you will be able to try again in %1$s.'), $time));
        }
    }




    return $user;
}

add_filter('authenticate', 'check_attempted_login', 30, 3);

function login_failed($username) {

    if (get_transient('attempted_login')) {

        $datas = get_transient('attempted_login');

        $datas['tried'] ++;




        if ($datas['tried'] <= 3)
            set_transient('attempted_login', $datas, 300);
    } else {

        $datas = array(
            'tried' => 1
        );

        set_transient('attempted_login', $datas, 300);
    }
}

add_action('wp_login_failed', 'login_failed', 10, 1);

function time_to_go($timestamp) {




    // converting the mysql timestamp to php time 

    $periods = array(
        "second",
        "minute",
        "hour",
        "day",
        "week",
        "month",
        "year"
    );

    $lengths = array(
        "60",
        "60",
        "24",
        "7",
        "4.35",
        "12"
    );

    $current_timestamp = time();

    $difference = abs($current_timestamp - $timestamp);

    for ($i = 0; $difference >= $lengths[$i] && $i < count($lengths) - 1; $i ++) {

        $difference /= $lengths[$i];
    }

    $difference = round($difference);

    if (isset($difference)) {

        if ($difference != 1)
            $periods[$i] .= "s";

        $output = "$difference $periods[$i]";

        return $output;
    }
}

function remove_post_type_page_from_search() {
    global $wp_post_types;
    $wp_post_types['sdm_downloads']->exclude_from_search = true;
    $wp_post_types['page']->exclude_from_search = true;
}

add_action('init', 'remove_post_type_page_from_search');


/*add_action('template_redirect', function() {
    if (is_user_logged_in() || !is_page()) {
        return;
    }

    $restricted = array(16); // all your restricted pages

    if (in_array(get_queried_object_id(), $restricted)) {
        global $wp;
        wp_redirect(site_url('sign-in?') . 'redirect_to=' . home_url($wp->request));
        exit();
    }
});*/

// function wp_maintenance_mode() {

//     if (!current_user_can('edit_themes') || !is_user_logged_in()) {

//         $html = '<!doctype html>

// <head>

// <title>Site Under Maintenance</title>

// <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

// <body style="width:100%;max-width:100%;padding:0;margin:0">

// <iframe name="myframe" src="https://learningtechedu.com/maintenance-page/" style="width:100%; height:100vh;padding: 0px;"></iframe>

// </body>

// </html>';




//         echo $html;

//         wp_die();
//     }
// }

// add_action('get_header', 'wp_maintenance_mode');

add_action('init', 'prevent_wp_login');

function prevent_wp_login() {
    // WP tracks the current page - global the variable to access it
    global $pagenow;
    // Check if a $_GET['action'] is set, and if so, load it into $action variable
    $action = (isset($_GET['action'])) ? $_GET['action'] : '';
    // Check if we're on the login page, and ensure the action is not 'logout'
    if( $pagenow == 'wp-login.php' && ( ! $action || ( $action && ! in_array($action, array('logout', 'lostpassword', 'rp', 'resetpass'))))) {
       
        $page = 'https://thebusinessinnovations.com/sign-in/';
       
        wp_redirect($page);
        // Stop execution to prevent the page loading for any reason
        exit();
    }
}
function exclude_category($query) {
    if ($query->is_home() && $query->is_main_query()) {
//$query->set('cat', '-1 -1897 -9527');
$query->set('cat', '-1 -8798 -8796 -8799');
}
return $query;
}
add_filter('pre_get_posts', 'exclude_category');

function custom_tag_query($query) {
    // Check if it is the main query and a tag archive page
    if ($query->is_main_query() && is_tag()) {
        // Modify the query to include only posts from a specific category and post type
        $query->set('post_type', 'post'); // Replace with your desired post type
    }
}

// Hook the custom_tag_query function into the pre_get_posts action
add_action('pre_get_posts', 'custom_tag_query');

function remove_quick_edit( $actions ) {
    unset($actions['inline hide-if-no-js']);
    return $actions;
}
 
add_filter('page_row_actions','remove_quick_edit',10,1);
add_filter('post_row_actions','remove_quick_edit',10,1);


// Redirect users to the home page after logout
add_action('wp_logout', 'auto_redirect_after_logout');
function auto_redirect_after_logout(){
    //wp_safe_redirect( home_url() );
	wp_safe_redirect(site_url('sign-in'));
    exit();
}

