<?php do_action('herald_before_end_content'); ?>

	</div>

	<?php if( herald_get_option('scroll_to_top') ) : ?>
		<a href="javascript:void(0)" id="back-top" class="herald-goto-top"><i class="fa fa-angle-up"></i></a>
	<?php endif; ?>


<?php wp_footer(); ?>

</body>
</html>