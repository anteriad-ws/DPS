<?php
/* Template Name: Landing Page 1 - 2 Columns, Right-side form
 * Template Post Type: resources
 *  */
get_header();
global $content_width;

$content_width = 1068;
$download_resource_id = get_post_meta($post->ID, 'sdm_description', true);

$pdf_tracker = get_post_meta($post->ID, 'thankyoupage-pdftracker', true);

$current_user = wp_get_current_user();
$job_title = get_user_meta($current_user->ID, 'user_registration_job_title', true);
$company_name = get_user_meta($current_user->ID, 'user_registration_company_name', true);


$categories = get_the_terms($post->ID, 'resource_types');
$category = array_pop($categories);

$privacy_policy = get_post_meta(get_the_ID(), 'privacy_policy', true);

$primary_sponsor = get_post_meta($post->ID, '_yoast_wpseo_primary_sponsored_by', true);

if(empty($primary_sponsor)) {
    $sponsored_by_arr = get_the_terms($post->ID, 'sponsored_by');
    $primary_sponsor = $sponsored_by_arr[0]->term_id;
}

$sponsored_by = get_term( $primary_sponsor );

$sponsored_by_custom_field = get_option("taxonomy_term_{$primary_sponsor}");
$sponsored_url = $sponsored_by_custom_field['client_url'];
$sponsored_name = $sponsored_by->name;

$sponsored_url_new = $sponsored_by->presenter_id;
?> 

<style>
.fm-form-container.fm-theme1 .fm-form button{
	background-color: #ff7500;
	color: #FFF;
	padding: 5px 10px;
	font-size: 1.4rem;
	text-transform: uppercase;
	line-height: 2.8rem;
	min-width: 40px;
	height: 40px;
	border-radius: 2px;
	-webkit-transition: all .2s ease;
    transition: all .2s ease;
    -webkit-appearance: none;
}
.fm-form-container.fm-theme1 .fm-form .button-submit .fm-submit-loading.spinner{
	width:5px;
}
.fm-form-container.fm-theme1 .fm-form .button-submit .fm-submit-loading.spinner:before{
	top:6px;
}
</style>
<div class="herald-section container">
    <article id="post-<?php the_ID(); ?>" <?php post_class('herald-single'); ?>>
		<div class="row">
			<!-- START -  Row 2-->
			<div class="col-lg-7 col-md-7 col-mod-single col-mod-main">
				<?php get_template_part('template-parts/single/head'); ?>
				<div class="herald-post-thumbnail herald-post-thumbnail-single">
					<img src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'medium_large')) ?>" alt="<?php the_title_attribute() ?>" /> 
				</div>
				<?php// get_template_part('template-parts/single/content'); ?>
				<?php the_content(); ?>
				<div class="Sponsored_name"><?php echo "Sponsored by: <b>" . $sponsored_name. "</b>" ?></div>
			</div>
			<div class=" col-lg-5 col-md-5 herald-sidebar-right">
				<div class="inner-col2" style="border: 1px solid #777a72;padding: 20px 40px 0 40px;">
					<p style="font-size: 12px;" class="fastpass-info alert alert-info">
						<i class="fa fa-info-circle"  data-toggle="tooltip" data-placement="top" title="" data-original-title="The Fastpass test helps you check for accessibility compliance requirements and issues on the landing page."></i>
						&nbsp; This page is FastPass tested and is compliant with Microsoft Accessibility features.
					</p>
				
					<h4 id="lp-form-head" style='font-weight: bold;font-size: 1.5rem;margin-left: 8px;'>Get Exclusive Access to the <?php echo $category->name; ?></h4>
					<div id="lp-form-msg" style="display: none" class="alert alert-success"></div>
					<span style="display: none;" id="get_resource_id"><?php echo $post->ID . '-' . $download_resource_id; ?></span>
					<span style="display: none;" id="get_resource_title"><?php echo $post->post_title; ?></span>
					
					<?php
					//If a Landing Page has this variable 'thankyoupage-pdftracker' set to true the thank you page should open with a PDF Tracker
					if($pdf_tracker === 'true') {
					?>
					<span style="display: none;" id="set_pdf_tracker">true</span>
					<?php } ?>
					<span style="display: none;" id="get_user_name"><?php echo $current_user->user_login; ?></span>
					<span style="display: none;" id="get_user_email"><?php echo $current_user->user_email; ?></span>
					<span style="display: none;" id="get_user_company"><?php echo $company_name; ?></span>
					<span style="display: none;" id="get_user_job_title"><?php echo $job_title; ?></span>
					<?php echo do_shortcode('[Form id="2"]'); ?>
					<?php if (!empty($sponsored_url)) { ?>
                            <span class="checkbox-div" id="privacy_policy" ><input type="checkbox" required="required">

                                        By downloading this publication, you understand and agree that you are providing your personal information to Anteriad, LLC, and Anteriad may share your personal information with <?php echo $sponsored_name; ?>, pursuant to Anteriad's <a href="https://anteriad.com/privacy-policy/" target="_blank"> Privacy Policy</a>. Furthermore, <?php echo $sponsored_name; ?> may use your personal information to provide you with marketing materials and contact you regarding its services, pursuant to <a href="<?php echo $sponsored_url; ?>" target="_blank"> Privacy Statement</a>.

                                        <div style="display:none; color:red" id="agree_chk_error">
										Accept the terms to proceed.
                                        </div>


                                    <?php } else if (!empty($privacy_policy)) { ?>
                                        <span class="checkbox-div" id="privacy_policy" ><input type="checkbox"><?php echo $privacy_policy; ?> 

                                            <div style="display:none; color:red" id="agree_chk_error">
											Accept the terms to proceed.
                                            </div>


                                        <?php } else { ?>

                                            <span class="checkbox-div" id="privacy_policy" ><input type="checkbox">

                                                By downloading this publication, you understand and agree that you are providing your personal information to Anteriad, LLC, and Anteriad may share your personal information with our clients, pursuant to Anteriad's <a href="https://anteriad.com/privacy-policy/" target="_blank"> Privacy Policy</a>.

                                                <div style="display:none; color:red" id="agree_chk_error">
												Accept the terms to proceed.
                                                </div>

                                            <?php } ?>

                                        <?php  ?>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</article>
</div>
<?php
if($_SESSION['typ_redirect'] == 'true') {
    ?>
<script type="text/javascript">
    toastr["error"]("Please submit the form to access the resource.")

    toastr.options = {
      "closeButton": false,
      "debug": false,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-bottom-right",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": "300",
      "hideDuration": "1000",
      "timeOut": "5000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
    </script>
<?php
    unset($_SESSION['typ_redirect']);
}
get_footer();