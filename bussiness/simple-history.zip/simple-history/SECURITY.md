# Security

## Reporting Security Issues

**Please do not report security vulnerabilities through public GitHub issues.**

Instead, please report them directly to the author of the plugin at [par.thernstrom@gmail.com](mailto:par.thernstrom@gmail.com).
